# 香港實時到站（巴士・小巴・港鐵・輕鐵）

一個以 **Kotlin + Jetpack Compose** 編寫的 Android App，整合香港特區政府「資料一線通」及各營辦商的官方開放數據，
提供巴士、專線小巴、港鐵重鐵與輕鐵的即時到站資訊，並以「紅黃綠燈號」顯示起點站／中途站／終點站的不同狀態。

---

## 一、主要功能

### 即時到站
| 營辦商 | 即時到站資料來源 | 更新頻率 |
|---|---|---|
| 九巴／龍運 | `data.etabus.gov.hk/v1/transport/kmb/stop-eta/{stop}` | 約 1 分鐘 |
| 城巴 | `rt.data.gov.hk/v2/transport/citybus/eta/CTB/{stop}/{route}` | 約 1 分鐘 |
| 新大嶼山巴士 | `rt.data.gov.hk/v2/transport/nlb/stop.php?action=estimatedArrivals` | 約 1 分鐘 |
| 專線小巴 | `data.etagmb.gov.hk/eta/route-stop/{route}/{seq}/{stop}` | 約 1 分鐘 |
| 港鐵重鐵 | `rt.data.gov.hk/v1/transport/mtr/getSchedule.php?line=&sta=` | 約 10 秒 |
| 輕鐵 | `rt.data.gov.hk/v1/transport/mtr/lrt/getSchedule?station_id=` | 約 10 秒 |
| 港鐵巴士 | `rt.data.gov.hk/v1/transport/mtr/bus/getSchedule`（POST，帶 routeName）⚠️ | 約 1 分鐘 |

> ⚠️ **港鐵巴士的端點路徑尚未經官方文件證實。**
> data.gov.hk 的資料集頁面只提供數據字典與規格文件連結，沒有列出可引用的端點網址；
> 程式碼裡的路徑是依重鐵／輕鐵的命名規則推測的。
> 這也是為什麼**務必先跑 Verify APIs**（見第三章）——它會實測四個候選端點，
> 直接告訴你哪一個可用。若推測有誤，查詢會靜默落空、退回「推算」，使用者看不出異常。

### 全自動每日更新（WorkManager）
每日預設於 **04:00（香港時間）** 於背景自動執行，重新開機後亦會自動重新排程：

1. 下載運輸署「公共交通路線及收費資料」（CSV），重建巴士與小巴的路線／車站目錄
2. 下載九巴、城巴、新大嶼山巴士、專線小巴的即時路線與車站資料
3. 下載港鐵重鐵、輕鐵的官方 CSV 路線與車站資料；
   港鐵巴士則取運輸署目錄中 `COMPANY_CODE＝LRTFEEDER` 的路線、車站與去回程站序，
   並逐條呼叫政府即時 API 建立「站序 → busStopId」對照表
4. 下載運輸署「公共交通服務班次資料」（GTFS），建立班次時間表
5. 比對快照，計算當日的路線與車站變動
6. 抓取天文台天氣警告，推算受影響路線與恢復時間

### 當日變動（六類）
- **新增**：當日新增的路線與車站
- **取消**：當日取消的路線與車站
- **修改**：改名、改起訖點、改票價、改行車時間、改站名、移位（>30 米）
- **臨時改道**：運輸署特別交通消息中偵測到的改道／站序變動
- **天氣影響**：受天氣警告影響的路線、班次時間表與恢復時間
- **已回復正常**：偵測到「恢復／重開／復常」後，以**實際**時間覆寫推算

變動有三個來源，介面會標示：
- `路線資料比對`（每日快照指紋比對）
- `運輸署更新記錄`（官方 Delta CSV 的 Add／Update／Delete）
- `運輸署特別交通消息`（XML 即時消息，關鍵字分類）

### 天氣影響
- 顯示生效中的天文台警告與級別（一／三／八／九／十號信號、黃／紅／黑雨等）
- 列出受影響路線數目、正常班次與受影響班次間距
- 三段式恢復時間表（30／60／120 分鐘），並在偵測到官方「恢復」消息後以實際時間取代推算

### 巴士與小巴時間燈號
燈號會依車站角色改變，並在所有巴士與小巴車站顯示。

**起點站**
- 距開出 **2–5 分鐘** → 黃燈閃爍「本班車即將開出」
- 距開出 **≤1 分鐘** → 紅燈「本班車開出中」
- 其後 → 顯示下一班車時間

**中途站**
- 距到站 **≤1 分鐘** → 紅燈閃爍「本班車即將到站」
- 到站後 60 秒內 → 灰燈「本班車離站中」
- 其後 → 顯示下一班車時間

**終點站**
- 距到達 **≤1 分鐘** → 紅燈閃爍「本班車已到達終點站，請所有乘客落車。」

燈號閃爍可在「設定」關閉（關閉後只以顏色顯示）。
設定頁面路徑：設定 → 啟用燈號閃爍。

---

## 二、用 GitHub 打包 APK

專案已內建 GitHub Actions，只要上傳到 GitHub 即可自動編譯 APK。

### 步驟 1：建立倉庫並上傳
1. 到 https://github.com/new 建立新倉庫（例如 `hk-transit-eta`），**不要**勾選初始化 README
2. 在本專案資料夾執行：

```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/<你的帳號>/hk-transit-eta.git
git push -u origin main
```

> 若不想用指令，也可以在 GitHub 倉庫頁面按 **Add file → Upload files**，
> 把整個專案資料夾的內容（**必須包含 `.github/` 與 `gradle/`**）拖進去提交。

### 步驟 2：執行自動打包
1. 進入倉庫的 **Actions** 分頁（首次需按 **I understand my workflows, go ahead and enable them**）
2. 左側選 **Build APK**
3. 按 **Run workflow → Run workflow**

推到 `main`／`master` 分支也會自動觸發。

約 8–15 分鐘後，於該次執行紀錄下方的 **Artifacts** 下載：
- `hk-transit-eta-debug`：可直接安裝到手機的 Debug APK（已完成 debug 簽章）
- `hk-transit-eta-release`：Release APK

> workflow 會自行安裝 JDK 17 與 Android SDK；Gradle 8.2 由內建的 Gradle Wrapper 自動下載。

### 步驟 3（選用）：產生正式簽署 APK
1. 產生 keystore：
```bash
keytool -genkey -v -keystore hk-transit.jks -keyalg RSA -keysize 2048 -validity 10000 -alias hktransit
base64 -i hk-transit.jks > keystore.txt
```
2. 到 **Settings → Secrets and variables → Actions → New repository secret**，新增四個secret：
   - `KEYSTORE_BASE64`（貼上 keystore.txt 內容）
   - `KEYSTORE_PASSWORD`
   - `KEY_ALIAS`
   - `KEY_PASSWORD`
3. 執行 **Build Signed APK** workflow

---

## 三、GitHub 後端（本專案的資料供應方式）

### 架構

```
政府開放資料 ──► GitHub Actions（每日）──► 倉庫 data/ ──► App
                  build_dataset.py          （含快照）      raw.githubusercontent.com
                                                                    │
即時到站（ETA）──────────────────────────────────────────────────► 仍直連政府 API
```

### 為什麼這樣設計

| 項目 | 放 GitHub 的理由 |
|---|---|
| 路線／車站目錄 | 裝置不必在手機上解析數 MB 的 CSV（舊做法在慢速網絡常逾時） |
| 每日變動 | 需要「昨日的快照」才能比對；放 git 不會因清除資料、重裝或換機而遺失 |
| 港鐵巴士 busStopId 對照表 | 須逐條路線呼叫政府 API；在 CI 做可省裝置流量，失敗也能從 log 直接看見 |
| **即時到站 ETA** | **不放**：每 10 秒至 1 分鐘就變動，放進靜態檔只會得到過期資料 |

### 設定步驟（重要）

1. 在 `app/build.gradle.kts` 把三個值改成你自己的倉庫：

```kotlin
buildConfigField("String", "DATASET_OWNER",  "\"你的 GitHub 帳號\"")
buildConfigField("String", "DATASET_REPO",   "\"hk-transit-eta\"")
buildConfigField("String", "DATASET_BRANCH", "\"main\"")
```

2. 推送後執行 **Build Dataset** workflow 產生 `data/`（約 3–8 分鐘）

3. 之後 App 就會從 GitHub 下載資料集。每日香港時間 04:00 自動重建。

> 若 `DATASET_OWNER` 維持預設值 `YOUR_GITHUB_USERNAME`，App 會判定未設定，
> 自動退回「直接下載政府資料」的舊路徑——所以沒設定也不會不能用，只是少了上述好處。

### 產出的檔案

| 檔案 | 內容 |
|---|---|
| `manifest.json` | 版本、各檔筆數、NLB 路線號→routeId 對應 |
| `routes.json` / `stops.json` | 路線與車站主檔 |
| `route_stops.json` | 路線—車站關係，壓成 `[路線索引, 車站索引, 站序]` 三元組 |
| `mtr_bus_map.json` | 港鐵巴士「站序 → busStopId」對照表 |
| `changes.json` | 當日變動（比對昨日快照）＋運輸署交通消息 |
| `weather.json` | 天文台警告 |
| `snapshots/` | 今日指紋，供明日比對（**不要手動刪除**，否則變動偵測會重新開始） |

---

## 四、用 GitHub 驗證真實 API（強烈建議先做）

本專案開發時所在環境無法對外連線，所有 API 假設都只能靠官方文件推斷。
專案內建 **Verify APIs** workflow，可在 GitHub 的 runner（有公網）上
實際呼叫各政府資料來源，把真實回傳結構印出來。

### 執行方式
Actions → **Verify APIs** → **Run workflow**（可勾選 `quick` 只做連線測試）。
每週一香港時間 02:00 也會自動執行一次，以便在政府 API 改版時及早發現。

### 結果在哪裡
- 該次執行頁面的 **Summary**（直接顯示整份報告）
- **Artifacts** → `api-verify-report` → `verify-report.md`

### 報告會回答哪些問題
**港鐵巴士（最需要驗證的部分）**
- **端點探測**：實測四個候選 URL（現用推測路徑、加 `.php`、v2、港鐵自有平台），
  直接告訴你哪一個可用。這是整份報告最重要的一節
- 端點是否為 POST、主體是否為 `{"language":"zh","routeName":"..."}`
- 頂層是否真有 `status` 欄位（`"1"`＝正常）
- `busStop` 陣列是否依站序排列（這是對照表的建立基礎）
- `busStopId` 的**實際格式**——官方文件未說明，本專案不猜測，直接記錄回傳值
- 每條路線能否唯一對應到某個方向；去／回程車站數相同的路線會列出來
  （這類路線會退回班次表推算並標示「推算」）

**其餘資料來源**（煙霧測試）：九巴、城巴、新大嶼山巴士、專線小巴、
港鐵重鐵、輕鐵、天文台、運輸署 CSV——確認能否連線、回傳格式是否如預期。

### 判讀重點
請看報告最後的「可建立對照表：N 條」：

| 結果 | 意義 | 處理方式 |
|---|---|---|
| 2.2 節顯示「程式碼使用的端點不可用」 | 端點路徑猜錯了 | 報告會列出可用 URL，改 `ApiConstants.MTR_BUS_SCHEDULE` |
| 2.2 節顯示「所有候選端點都失敗」 | 端點已改版或需其他參數 | 把報告給開發者，需重新查規格 |
| N 接近路線總數 | 假設成立，可直接使用 | — |
| N 為 0 或極低 | `routeName` 與運輸署 `ROUTE_NAMEC` 對不上 | 把報告給開發者，加一層路線號正規化比對 |
| 大量「方向無法唯一判定」 | 去回程車站數經常相同 | 需改用站名比對來分辨方向，而非只靠車站數 |

---

## 五、監控後台（GitHub Pages）

專案內建一個**數據源監控後台**：由 GitHub Actions 每 30 分鐘產生一次靜態網站，
透過 GitHub Pages 發佈，用手機或瀏覽器開啟即可查看。

### 啟用步驟
1. 到 **Settings → Pages → Source**，選 **GitHub Actions**
2. 到 **Actions → Dashboard → Run workflow**（也可等排程自動執行）
3. 完成後，網址會顯示在 Settings → Pages，通常是
   `https://<你的帳號>.github.io/<倉庫>/`

> 未啟用 Pages 的話，`deploy` 步驟會失敗並提示啟用，屬正常現象。

### 儀表板顯示什麼
| 區塊 | 內容 |
|---|---|
| 摘要卡片 | 資料源健康數、平均回應時間、港鐵巴士對照成功率、今日消息數、Delta 筆數、生效中警告 |
| 港鐵巴士對照表 | 逐條路線列出：去／回程站數、API 回傳站數、`status`、首個 `busStopId`，以及能否建立對照 |
| 資料源健康檢查 | 各來源的狀態、回應時間、筆數；失敗時直接顯示錯誤 |
| 運輸署官方更新記錄 | 六類 Delta 檔的 Add／Update／Delete 筆數 |
| 特別交通消息 | 改道／暫停／恢復分類統計，以及今日消息的節錄 |
| 天文台警告 | 生效中的警告代碼與名稱 |

對照成功率為 0 或偏低時，儀表板會直接顯示警示與可能原因。

### 重要界線：這是「資料源監控」，不是「App 內部監控」
手機上的資料庫**無法**從 GitHub 讀取，所以這不是 App 的後台，
而是獨立於 App、對**同一批政府 API** 做交叉驗證的儀表板。
用途是驗證本專案對各 API 的假設是否成立，並在政府 API 改版或故障時及早發現。

### 其他注意事項
- 每 30 分鐘重建一次；頁面本身每 5 分鐘自動重新載入
- GitHub 會在倉庫**連續 60 天沒有活動**時停用排程工作流程，
  屆時到 Actions 分頁手動觸發一次即可恢復
- 單一資料源故障**不會**讓工作流程失敗（故障會記錄在頁面上，這正是監控的價值）
- 除網頁外，同時產生 `data.json`，可供其他程式讀取

---

## 六、本機編譯

**Android Studio（最簡單）**：File → Open 直接開啟本專案，
Gradle Sync 後按 Run 即可；Android Studio 會自動下載 Gradle 與 SDK。

**指令列**：
```bash
# 1. 於專案根目錄建立 local.properties，指向你的 Android SDK
echo "sdk.dir=$HOME/Library/Android/sdk" > local.properties   # macOS
echo "sdk.dir=$HOME/Android/Sdk"        > local.properties     # Linux

# 2. 建置（Gradle 8.2，配合 AGP 8.2.2）
./gradlew assembleDebug
```

需求：JDK 17、Android SDK 34（compileSdk）、Gradle 8.2。
最低支援 **Android 8.0（API 26）**。

---

## 七、專案結構

```
app/src/main/java/hk/transit/eta/
├── core/
│   ├── di/AppContainer.kt          手寫 DI 容器
│   └── util/                       時間、CSV、XML 解析器
├── data/
│   ├── remote/                     Retrofit API 定義與網路層
│   ├── local/db/                   Room 資料庫（Entity / DAO / Database）
│   └── repository/                 目錄、即時到站、消息、天氣、班次
├── domain/
│   ├── SignalLightEngine.kt        燈號狀態機（核心）
│   ├── ChangeDetector.kt           每日變動比對
│   ├── WeatherImpactEngine.kt      天氣影響與恢復推算
│   ├── NewsClassifier.kt           交通消息分類
│   └── model/Models.kt             統一領域模型
├── worker/                         背景全自動更新與排程
└── ui/                             Compose 介面（首頁／到站／變動／天氣／設定）

tools/
├── build_dataset.py                後端資料集產生器（在 Actions 上跑）
└── verify_apis.py                  API 實測腳本（在 Actions 上跑）

data/                               由 Build Dataset workflow 產生並提交
.github/workflows/
├── build-dataset.yml               每日產生資料集並提交
├── verify-apis.yml                 每週實測各政府 API
├── build-apk.yml                   編譯 APK
└── release-apk.yml                 產生正式簽署 APK
```

---

## 八、疑難排解

| 情況 | 處理方式 |
|---|---|
| Actions 顯示 `SDK location not found` | 本專案不需 `local.properties`（CI 會自動設定 `ANDROID_HOME`）；本機編譯才要建立 |
| `Unsupported class file major version` | JDK 版本不符，請用 JDK 17 |
| Artifacts 內沒有 APK | 開該次執行的 log，捲到 `Build debug APK` 步驟看紅字；`Build release APK` 已設為失敗不中斷 |
| 安裝後搜尋沒有結果 | 首次啟動會自動同步一次，需時 1–3 分鐘；可到「設定 → 立即更新」手動觸發 |
| 小巴／輕鐵分頁空白 | 目錄尚未建立完成，等背景同步結束後重開 App |
| 港鐵巴士一直顯示「推算」 | 跑 **Verify APIs**，看報告的「可建立對照表：N 條」；若 N 偏低，代表 `routeName` 與 `ROUTE_NAMEC` 對不上 |
| 某個資料來源突然全部失效 | 跑 **Verify APIs** 確認是政府端改版還是本專案的問題；workflow 每週也會自動執行一次 |
| App 一直走「直接下載」而非後端資料集 | 檢查 `DATASET_OWNER` 是否仍是 `YOUR_GITHUB_USERNAME`；也確認 **Build Dataset** 已跑過、倉庫有 `data/manifest.json` |
| 今日變動一直是空的 | 後端需連續兩天成功產生資料集才有得比對；首次執行只會建立基準快照 |
| Build Dataset 推送失敗 | workflow 內建 3 次 rebase 重試；若仍失敗，通常是同時有兩次執行，稍後重跑即可 |

## 九、重要限制（請先閱讀）

1. **港鐵巴士的即時到站**：使用政府開放資料
   「港鐵巴士及接駁巴士實時到站時間」（`rt.data.gov.hk/v1/transport/mtr/bus/getSchedule`，
   資料由港鐵提供）。須注意兩點：
   - **端點路徑尚未經官方文件證實**（依重鐵／輕鐵命名規則推測），
     請以 Verify APIs 報告的端點探測結果為準。
   - 該 API 只接受 `routeName`，回傳的 `busStopId` 格式官方並未說明，
     因此本專案**不猜測格式**，而是在每日同步時呼叫一次 API、把回傳的車站清單
     依序記入對照表（`mtr_bus_stop_map`）。
   - API 不帶方向參數，故當同一路線編號的去／回程車站數相同時，
     無從判斷回傳的是哪個方向；這種情況一律不建立對照，該路線退回班次表推算並標示「推算」。
2. **臨時改道沒有結構化開放資料**：現時以運輸署「特別交通消息」XML 作關鍵字分類推導，
   屬啟發式判斷，可能有漏判或誤判；官方資料集頁亦明確寫明
   「關於公共交通路線的臨時改道安排，請查看相關公共交通服務營辦商網頁」。
3. **天氣對路線的影響沒有官方結構化資料**：影響等級、班次倍率與恢復時間表是依各營辦商
   一貫做法建立的規則推算，全部標示「推算」，並會在偵測到官方「恢復」消息後以實際時間覆寫。
4. **本專案未經實機驗證**：沙盒環境無法連線，所有程式碼僅經靜態檢查（括號、符號、資源、
   Room 實體登記與 DAO 介面），未實際編譯或對政府 API 發出請求。
   首次執行 GitHub Actions 時請開 log 確認。
5. 所有資料的知識產權分屬九巴、龍運、城巴、新大嶼山巴士、香港鐵路有限公司及香港天文台，
   使用前請遵守各自的開放數據授權條款。
