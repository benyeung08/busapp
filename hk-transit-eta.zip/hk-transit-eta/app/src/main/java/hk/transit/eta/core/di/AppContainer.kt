package hk.transit.eta.core.di

import android.content.Context
import hk.transit.eta.data.local.UserPreferences
import hk.transit.eta.data.local.db.AppDatabase
import hk.transit.eta.data.repository.CatalogueRepository
import hk.transit.eta.data.repository.DatasetRepository
import hk.transit.eta.data.repository.EtaRepository
import hk.transit.eta.data.repository.HeadwayRepository
import hk.transit.eta.data.repository.NewsRepository
import hk.transit.eta.data.repository.TdStaticRepository
import hk.transit.eta.data.repository.WeatherRepository

/**
 * 極簡手寫 DI 容器。
 * 不使用 Hilt 是為了讓背景 Worker 與介面共用同一批單例，且不需額外註解處理器設定。
 */
class AppContainer private constructor(context: Context) {

    /** Application context，供排程與系統服務使用。 */
    val appContext: Context = context.applicationContext

    val database: AppDatabase = AppDatabase.getInstance(context)
    val preferences: UserPreferences = UserPreferences(context)

    val tdStaticRepository: TdStaticRepository = TdStaticRepository()
    val datasetRepository: DatasetRepository = DatasetRepository(database, preferences)
    val catalogueRepository: CatalogueRepository =
        CatalogueRepository(database, preferences, datasetRepository)
    val etaRepository: EtaRepository = EtaRepository(database)
    val newsRepository: NewsRepository = NewsRepository(database, preferences)
    val weatherRepository: WeatherRepository = WeatherRepository(database, preferences)
    val headwayRepository: HeadwayRepository = HeadwayRepository(database, preferences)

    companion object {
        @Volatile
        private var INSTANCE: AppContainer? = null

        fun init(context: Context): AppContainer = INSTANCE ?: synchronized(this) {
            INSTANCE ?: AppContainer(context.applicationContext).also { INSTANCE = it }
        }

        fun get(context: Context): AppContainer =
            INSTANCE ?: init(context.applicationContext)
    }
}
