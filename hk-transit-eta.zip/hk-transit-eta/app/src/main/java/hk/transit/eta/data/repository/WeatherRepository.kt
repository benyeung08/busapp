package hk.transit.eta.data.repository

import hk.transit.eta.core.util.TimeUtil
import hk.transit.eta.data.local.UserPreferences
import hk.transit.eta.data.local.db.AppDatabase
import hk.transit.eta.data.local.db.DailyChangeEntity
import hk.transit.eta.data.local.db.HeadwayEntity
import hk.transit.eta.data.local.db.RouteEntity
import hk.transit.eta.data.local.db.SyncLogEntity
import hk.transit.eta.data.local.db.WeatherEventEntity
import hk.transit.eta.data.remote.NetworkClient
import hk.transit.eta.domain.WeatherImpactEngine
import hk.transit.eta.domain.model.Operator
import hk.transit.eta.domain.model.ServiceImpact
import hk.transit.eta.domain.model.WeatherEvent
import hk.transit.eta.domain.model.WeatherImpactSummary
import hk.transit.eta.domain.model.WeatherRouteImpact
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.time.Instant

/**
 * 天文台天氣警告 → 對公共交通的影響。
 *
 * 資料來源：
 *  - 天氣警告一覽   warnsum
 *  - 詳細警告資訊   warningInfo
 */
class WeatherRepository(
    private val database: AppDatabase,
    private val prefs: UserPreferences
) {

    private val hko = NetworkClient.hko()

    /** 一次同步：抓警告 → 推算影響 → 寫入今日變動。 */
    suspend fun sync(date: String = TimeUtil.today()): WeatherImpactSummary =
        withContext(Dispatchers.IO) {
            val events = fetchEvents(date)
            database.weatherEventDao().upsertAll(
                events.map { event ->
                    WeatherEventEntity(
                        key = event.key,
                        date = event.date,
                        warningCode = event.warningCode,
                        warningName = event.warningName,
                        actionCode = event.actionCode,
                        level = event.level,
                        issueTime = event.issueTime?.toEpochMilli(),
                        updateTime = event.updateTime?.toEpochMilli(),
                        cancelTime = event.cancelTime?.toEpochMilli(),
                        detail = event.detail
                    )
                }
            )
            database.syncLogDao().upsert(
                SyncLogEntity(
                    kind = KIND_WEATHER,
                    lastSyncAt = System.currentTimeMillis(),
                    itemCount = events.size,
                    success = true,
                    message = null
                )
            )
            prefs.lastWeatherSync = System.currentTimeMillis()

            val level = events.maxOfOrNull { it.level } ?: WeatherImpactEngine.LEVEL_NONE
            val summary = buildSummary(date, events, level)
            if (summary.affectedRoutes.isNotEmpty()) {
                val resumedRoutes = emptyMap<String, Instant>()
                val changes = WeatherImpactEngine.toDailyChanges(
                    date = date,
                    events = events,
                    impacts = summary.affectedRoutes,
                    resumedRoutes = resumedRoutes
                )
                insertChanges(changes)
            }
            summary
        }

    /**
     * 以運輸署消息中偵測到的「實際恢復時間」更新今日的天氣影響記錄。
     */
    suspend fun applyActualRecovery(date: String, resumedRoutes: Map<String, Instant>) {
        if (resumedRoutes.isEmpty()) return
        val rows = database.dailyChangeDao().weatherByDate(date)
        if (rows.isEmpty()) return
        val wildcard = resumedRoutes["*"]
        val updated = rows.mapNotNull { row ->
            val actual = resumedRoutes[row.routeNo?.uppercase()] ?: wildcard ?: return@mapNotNull null
            row.copy(resumedAt = actual.toEpochMilli())
        }
        if (updated.isNotEmpty()) database.dailyChangeDao().updateAll(updated)
    }

    suspend fun summaryOf(date: String = TimeUtil.today()): WeatherImpactSummary {
        val events = database.weatherEventDao().byDate(date).map { entity ->
            WeatherEvent(
                key = entity.key,
                date = entity.date,
                warningCode = entity.warningCode,
                warningName = entity.warningName,
                actionCode = entity.actionCode,
                level = entity.level,
                issueTime = TimeUtil.fromEpochMillis(entity.issueTime),
                updateTime = TimeUtil.fromEpochMillis(entity.updateTime),
                cancelTime = TimeUtil.fromEpochMillis(entity.cancelTime),
                detail = entity.detail
            )
        }
        val level = events.maxOfOrNull { it.level } ?: WeatherImpactEngine.LEVEL_NONE
        return buildSummary(date, events, level)
    }

    // ------------------------------------------------------------------

    private suspend fun fetchEvents(date: String): List<WeatherEvent> {
        val warnSum = try {
            hko.weather("warnsum", "tc")
        } catch (e: Exception) {
            return emptyList()
        }
        val details = try {
            hko.weather("warningInfo", "tc")
        } catch (e: Exception) {
            null
        }

        val detailContents = details
            ?.getAsJsonArray("details")
            ?.mapNotNull { it.asJsonObject }
            ?.associate { obj ->
                val code = obj.get("code")?.asString.orEmpty()
                val text = obj.getAsJsonArray("contents")
                    ?.mapNotNull { it.asString }
                    ?.joinToString("\n").orEmpty()
                code to text
            }.orEmpty()

        val events = mutableListOf<WeatherEvent>()
        for ((code, element) in warnSum.entrySet()) {
            if (!element.isJsonObject) continue
            val obj = element.asJsonObject
            val actionCode = obj.get("actionCode")?.asString.orEmpty()
            // CANCEL 代表警告已取消，不視為生效中
            if (actionCode.equals("CANCEL", ignoreCase = true)) continue
            val name = obj.get("name")?.asString ?: code
            val detailText = detailContents[code].orEmpty()
            val issue = TimeUtil.parseFlexible(obj.get("issueTime")?.asString)
            val update = TimeUtil.parseFlexible(obj.get("updateTime")?.asString)
            if (issue != null && TimeUtil.dateKey(issue) != date && update != null && TimeUtil.dateKey(update) != date) {
                continue
            }
            events += WeatherEvent(
                key = "$code|${issue?.toEpochMilli() ?: 0L}",
                date = date,
                warningCode = code,
                warningName = name,
                actionCode = actionCode,
                level = WeatherImpactEngine.severityOf(name, detailText),
                issueTime = issue,
                updateTime = update,
                cancelTime = null,
                detail = detailText.ifBlank { name }
            )
        }
        return events
    }

    private suspend fun buildSummary(
        date: String,
        events: List<WeatherEvent>,
        level: Int
    ): WeatherImpactSummary {
        if (level == WeatherImpactEngine.LEVEL_NONE) {
            return WeatherImpactSummary(date, emptyList(), emptyList(), emptyList(), 0, 0, false)
        }
        val routes = database.routeDao().search(
            q = "%",
            operatorCodes = Operator.visible.map { it.code },
            limit = MAX_ROUTES
        )
        val headwaysByRoute = routes.associateWith { route ->
            database.headwayDao().ofRouteNo(route.routeNo, route.operatorCode)
        }.mapKeys { it.key.routeKey }

        val impacts = WeatherImpactEngine.buildRouteImpacts(level, routes, headwaysByRoute)
        val affectedByOperator = impacts.groupBy { it.operator }.mapValues { it.value.size }
        val downgradeAt = events.maxByOrNull { it.level }?.cancelTime
        val stages = WeatherImpactEngine.recoveryStages(level, downgradeAt, affectedByOperator)

        val restored = database.dailyChangeDao().weatherByDate(date).count { it.resumedAt != null }
        return WeatherImpactSummary(
            date = date,
            activeEvents = events,
            affectedRoutes = impacts,
            recoveryStages = stages,
            affectedRouteCount = impacts.size,
            restoredRouteCount = restored,
            isEstimate = true
        )
    }

    private suspend fun insertChanges(changes: List<DailyChangeEntity>) {
        if (changes.isEmpty()) return
        val date = changes.first().date
        val existing = mutableSetOf<String>()
        changes.map { it.dedupKey }.chunked(900).forEach { chunk ->
            existing += database.dailyChangeDao().existing(date, chunk).map { it.dedupKey }
        }
        val newOnes = changes.filter { it.dedupKey !in existing }.distinctBy { it.dedupKey }
        if (newOnes.isNotEmpty()) database.dailyChangeDao().insertAll(newOnes)
    }

    companion object {
        const val KIND_WEATHER = "weather"
        /** 天氣影響可能涉及大量路線，為免寫入過多記錄，設上限。 */
        const val MAX_ROUTES = 4000
    }
}

/** 供 UI 直接使用的影響分組工具。 */
object WeatherImpactGrouping {
    fun byImpact(impacts: List<WeatherRouteImpact>): Map<ServiceImpact, List<WeatherRouteImpact>> =
        impacts.groupBy { it.impact }

    fun byOperator(impacts: List<WeatherRouteImpact>): Map<Operator, List<WeatherRouteImpact>> =
        impacts.groupBy { it.operator }
}

/** 供介面顯示：由 route 取得班次資料。 */
suspend fun headwayOf(database: AppDatabase, route: RouteEntity): List<HeadwayEntity> =
    database.headwayDao().ofRoute(route.routeKey)
        .ifEmpty { database.headwayDao().ofRouteNo(route.routeNo, route.operatorCode) }
