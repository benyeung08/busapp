package hk.transit.eta.data.repository

import hk.transit.eta.core.util.HKT
import hk.transit.eta.core.util.TimeUtil
import hk.transit.eta.data.local.db.AppDatabase
import hk.transit.eta.data.local.db.HeadwayEntity
import hk.transit.eta.data.local.db.RouteEntity
import hk.transit.eta.data.remote.ApiConstants
import hk.transit.eta.data.remote.MtrBusRequest
import hk.transit.eta.data.remote.NetworkClient
import hk.transit.eta.domain.SignalLightEngine
import hk.transit.eta.domain.model.EtaEntry
import hk.transit.eta.domain.model.EtaSource
import hk.transit.eta.domain.model.Operator
import hk.transit.eta.domain.model.StopEtaBoard
import hk.transit.eta.domain.model.StopRole
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import java.time.Instant
import java.time.temporal.ChronoUnit

/**
 * 即時到站查詢。
 *
 * 各營辦商均使用官方開放資料：
 *  - 九巴／龍運   data.etabus.gov.hk/v1/transport/kmb/stop-eta/{stop_id}
 *  - 城巴         rt.data.gov.hk/v2/transport/citybus/eta/CTB/{stop_id}/{route}
 *  - 新大嶼山巴士 rt.data.gov.hk/v2/transport/nlb/stop.php （需 routeId）
 *  - 專線小巴     data.etagmb.gov.hk/stop-eta/{stop_id}
 *  - 港鐵重鐵     rt.data.gov.hk/v1/transport/mtr/getSchedule.php
 *  - 輕鐵         rt.data.gov.hk/v1/transport/mtr/lrt/getSchedule
 *  - 港鐵巴士     rt.data.gov.hk/v1/transport/mtr/bus/getSchedule （POST）
 *
 * 若官方資料暫時沒有回應（例如該路線已暫停），才退回班次表推算並標示「推算」。
 */
class EtaRepository(private val database: AppDatabase) {

    private val kmb = NetworkClient.kmb()
    private val ctb = NetworkClient.ctb()
    private val nlb = NetworkClient.nlb()
    private val gmbApi = NetworkClient.gmb()
    private val mtr = NetworkClient.mtr()

    /** 單一車站最多同時查詢的路線數，避免過度請求。 */
    private val maxRoutesPerStop = 15

    suspend fun fetchBoard(stopKey: String): List<StopEtaBoard> = withContext(Dispatchers.IO) {
        val operator = Operator.fromCode(stopKey.substringBefore("|"))
            ?: return@withContext emptyList()
        // 純目錄命名空間（運輸署收費資料）沒有即時到站來源
        if (operator.directoryOnly) return@withContext emptyList()
        val stopId = stopKey.substringAfter("|")
        val now = Instant.now()

        val boards = when (operator) {
            Operator.KMB -> boardKmb(stopId, now)
            Operator.CTB -> boardCtb(stopId, now)
            Operator.NLB -> boardNlb(stopId, now)
            Operator.GMB -> boardGmb(stopId, now)
            Operator.MTR_HR -> boardHeavyRail(stopId, now)
            Operator.MTR_LR -> boardLightRail(stopId, now)
            // 港鐵巴士以官方即時 API 為主；若暫時查不到，才退回班次表推算
            Operator.MTR_BUS -> boardMtrBus(stopKey, stopId, now)
                .ifEmpty { boardFromSchedule(stopKey, Operator.MTR_BUS, now) }
            else -> emptyList()
        }
        boards.sortedWith(compareBy({ it.stopRole.ordinal }, { it.routeNo }))
    }

    // ==================================================================
    // 九巴／龍運
    // ==================================================================

    private suspend fun boardKmb(stopId: String, now: Instant): List<StopEtaBoard> {
        val response = try {
            kmb.stopEta(stopId)
        } catch (e: Exception) {
            return emptyList()
        }
        val data = response.data.orEmpty()
        if (data.isEmpty()) return emptyList()

        val grouped = data.groupBy { RouteKeys.route(Operator.KMB, it.route, it.dir, it.serviceType) }
        val totals = stopCounts(grouped.keys)

        return grouped.mapNotNull { (routeKey, list) ->
            // 全部 ETA 屬同一車站，seq 相同；站序資料必須來自我們的目錄
            val stopSeq = list.minOfOrNull { it.seq } ?: 1
            val totalStops = totals[routeKey] ?: 0
            val routeNo = list.first().route
            val entries = list.mapNotNull { dto ->
                val eta = TimeUtil.parseFlexible(dto.eta) ?: return@mapNotNull null
                EtaEntry(
                    routeKey = routeKey,
                    routeNo = routeNo,
                    operator = Operator.KMB,
                    bound = dto.dir,
                    serviceType = dto.serviceType,
                    stopSeq = stopSeq,
                    eta = eta,
                    minutes = SignalLightEngine.minutesBetween(now, eta),
                    destTc = dto.destTc,
                    destEn = dto.destEn,
                    remarkTc = dto.rmkTc?.takeIf { it.isNotBlank() },
                    source = EtaSource.REALTIME
                )
            }.sortedBy { it.eta }
            if (entries.isEmpty()) return@mapNotNull null
            StopEtaBoard(
                routeKey = routeKey,
                routeNo = routeNo,
                operator = Operator.KMB,
                bound = list.first().dir,
                destTc = list.first().destTc,
                stopSeq = stopSeq,
                totalStops = totalStops,
                stopRole = SignalLightEngine.resolveStopRole(stopSeq, totalStops),
                entries = entries,
                hasRealtime = true,
                fetchedAt = now
            )
        }
    }

    // ==================================================================
    // 城巴
    // ==================================================================

    private suspend fun boardCtb(stopId: String, now: Instant): List<StopEtaBoard> = coroutineScope {
        // 以站序資料找出停靠此站的路線；若目錄尚未建立，則無可查詢的目標
        val routeStops = database.routeStopDao().ofStop(RouteKeys.stop(Operator.CTB, stopId))
        val routeKeys = routeStops.map { it.routeKey }.distinct().take(maxRoutesPerStop)
        if (routeKeys.isEmpty()) return@coroutineScope emptyList()

        val totals = stopCounts(routeKeys)

        routeKeys.map { routeKey ->
            async {
                val routeNo = RouteKeys.routeNoOf(routeKey) ?: return@async null
                val dto = try {
                    ctb.eta(ApiConstants.CTB_COMPANY_ID, stopId, routeNo).data
                } catch (e: Exception) {
                    return@async null
                }
                val filtered = dto.orEmpty().filter { it.stop == stopId }
                if (filtered.isEmpty()) return@async null
                val stopSeq = filtered.minOfOrNull { it.seq } ?: 1
                val totalStops = totals[routeKey] ?: 0
                val entries = filtered.mapNotNull { item ->
                    val eta = TimeUtil.parseFlexible(item.eta) ?: return@mapNotNull null
                    EtaEntry(
                        routeKey = routeKey,
                        routeNo = routeNo,
                        operator = Operator.CTB,
                        bound = item.dir,
                        serviceType = 1,
                        stopSeq = stopSeq,
                        eta = eta,
                        minutes = SignalLightEngine.minutesBetween(now, eta),
                        destTc = item.destTc,
                        destEn = item.destEn,
                        remarkTc = item.rmkTc?.takeIf { it.isNotBlank() },
                        source = EtaSource.REALTIME
                    )
                }.sortedBy { it.eta }
                if (entries.isEmpty()) return@async null
                StopEtaBoard(
                    routeKey = routeKey,
                    routeNo = routeNo,
                    operator = Operator.CTB,
                    bound = filtered.first().dir,
                    destTc = filtered.first().destTc,
                    stopSeq = stopSeq,
                    totalStops = totalStops,
                    stopRole = SignalLightEngine.resolveStopRole(stopSeq, totalStops),
                    entries = entries,
                    hasRealtime = true,
                    fetchedAt = now
                )
            }
        }.mapNotNull { it.await() }
    }

    // ==================================================================
    // 新大嶼山巴士
    // ==================================================================

    private suspend fun boardNlb(stopId: String, now: Instant): List<StopEtaBoard> = coroutineScope {
        // 必須以 operatorCode 在 SQL 端過濾，否則取回的前 N 筆幾乎全是九巴
        val routes = database.routeDao().byOperators(listOf(Operator.NLB.code))
        if (routes.isEmpty()) return@coroutineScope emptyList()

        val totals = stopCounts(routes.map { it.routeKey }.distinct())

        routes.take(maxRoutesPerStop).map { route ->
            async {
                // NLB API 需要數字 routeId；companyCode 存放的就是它。
                // 若誤存成 "NLB" 字串，所有路線都會被略過（這是先前的錯誤）。
                val routeId = route.companyCode.toIntOrNull()?.toString()
                    ?: return@async null
                val dto = try {
                    nlb.eta(routeId = routeId, stopId = stopId).estimatedArrivals
                } catch (e: Exception) {
                    return@async null
                }
                val list = dto.orEmpty()
                if (list.isEmpty()) return@async null

                val stopSeq = database.routeStopDao().ofRoute(route.routeKey)
                    .firstOrNull { it.stopId == stopId }?.stopSeq ?: 1
                val totalStops = totals[route.routeKey] ?: 0

                val entries = list.mapNotNull { item ->
                    val eta = TimeUtil.parseFlexible(item.eta) ?: return@mapNotNull null
                    EtaEntry(
                        routeKey = route.routeKey,
                        routeNo = route.routeNo,
                        operator = Operator.NLB,
                        bound = route.bound,
                        serviceType = 1,
                        stopSeq = stopSeq,
                        eta = eta,
                        minutes = SignalLightEngine.minutesBetween(now, eta),
                        destTc = route.destTc,
                        destEn = route.destEn,
                        remarkTc = item.remarkC?.takeIf { it.isNotBlank() },
                        source = if (item.isScheduled == "Y") EtaSource.SCHEDULE else EtaSource.REALTIME
                    )
                }.sortedBy { it.eta }
                if (entries.isEmpty()) return@async null
                StopEtaBoard(
                    routeKey = route.routeKey,
                    routeNo = route.routeNo,
                    operator = Operator.NLB,
                    bound = route.bound,
                    destTc = route.destTc,
                    stopSeq = stopSeq,
                    totalStops = totalStops,
                    stopRole = SignalLightEngine.resolveStopRole(stopSeq, totalStops),
                    entries = entries,
                    hasRealtime = true,
                    fetchedAt = now
                )
            }
        }.mapNotNull { it.await() }
    }

    // ==================================================================
    // 專線小巴
    // ==================================================================

    private suspend fun boardGmb(stopId: String, now: Instant): List<StopEtaBoard> {
        val response = try {
            gmbApi.stopEta(stopId)
        } catch (e: Exception) {
            return emptyList()
        }
        val data = response.data.orEmpty()
        if (data.isEmpty()) return emptyList()

        // GMB ETA 以 route_id 識別路線，而 route_id 存放在 companyCode
        val gmbRoutes = database.routeDao().byOperators(listOf(Operator.GMB.code))
        val routeIdToEntity = gmbRoutes.groupBy { it.companyCode }

        return data.mapNotNull { dto ->
            val routeId = dto.routeId ?: return@mapNotNull null
            // 同一 route_id 可能有去程／回程兩列，依 route_seq 選出正確的一列
            val routeSeq = dto.routeSeq ?: 1
            val entity = routeIdToEntity[routeId]?.firstOrNull { it.serviceType == routeSeq }
                ?: routeIdToEntity[routeId]?.firstOrNull()
                ?: return@mapNotNull null
            val bound = if (routeSeq == 1) "O" else "I"
            val routeKey = RouteKeys.route(Operator.GMB, entity.routeNo, bound, routeSeq)
            val stopSeq = dto.stopSeq ?: 1
            val totalStops = database.routeStopDao().countOfRoute(routeKey)
            val items = dto.eta.orEmpty()
            val entries = if (dto.enabled == false) emptyList() else items.mapNotNull { item ->
                val eta = TimeUtil.parseFlexible(item.timestamp) ?: return@mapNotNull null
                EtaEntry(
                    routeKey = routeKey,
                    routeNo = entity.routeNo,
                    operator = Operator.GMB,
                    bound = bound,
                    serviceType = routeSeq,
                    stopSeq = stopSeq,
                    eta = eta,
                    minutes = SignalLightEngine.minutesBetween(now, eta),
                    destTc = entity.destTc,
                    destEn = entity.destEn,
                    remarkTc = item.remarksTc?.takeIf { it.isNotBlank() }
                        ?: dto.remarksTc?.takeIf { it.isNotBlank() },
                    source = EtaSource.REALTIME
                )
            }.sortedBy { it.eta }
            if (entries.isEmpty()) return@mapNotNull null
            StopEtaBoard(
                routeKey = routeKey,
                routeNo = entity.routeNo,
                operator = Operator.GMB,
                bound = bound,
                destTc = entity.destTc,
                stopSeq = stopSeq,
                totalStops = totalStops,
                stopRole = SignalLightEngine.resolveStopRole(stopSeq, totalStops),
                entries = entries,
                hasRealtime = true,
                fetchedAt = now
            )
        }
    }

    // ==================================================================
    // 港鐵重鐵
    // ==================================================================

    private suspend fun boardHeavyRail(stationCode: String, now: Instant): List<StopEtaBoard> {
        val linesForStation = database.routeStopDao()
            .ofStop(RouteKeys.stop(Operator.MTR_HR, stationCode))
            .map { it.routeKey }
            .distinct()
        val candidates = linesForStation.ifEmpty {
            // 目錄尚未建立時，逐條試官方支援的十條線
            ApiConstants.MTR_HEAVY_RAIL_LINES.keys.map {
                RouteKeys.route(Operator.MTR_HR, it, "UP", 1)
            }
        }

        val nameByCode = database.stopDao().byOperator(Operator.MTR_HR.code)
            .associate { it.stopId to it.nameTc }

        return candidates.mapNotNull { routeKey ->
            val line = RouteKeys.routeNoOf(routeKey) ?: return@mapNotNull null
            val json = try {
                mtr.heavyRailSchedule(line = line, sta = stationCode)
            } catch (e: Exception) {
                return@mapNotNull null
            }
            val dataObject = json.getAsJsonObject("data") ?: return@mapNotNull null
            val stationObject = dataObject.entrySet()
                .firstOrNull { it.key.equals("$line-$stationCode", ignoreCase = true) }
                ?.value?.takeIf { it.isJsonObject }?.asJsonObject ?: return@mapNotNull null

            val stopSeq = database.routeStopDao().ofRoute(routeKey)
                .firstOrNull { it.stopId == stationCode }?.stopSeq ?: 1
            val totalStops = database.routeStopDao().countOfRoute(routeKey)

            val entries = mutableListOf<EtaEntry>()
            for (direction in listOf("UP", "DOWN")) {
                val array = stationObject.getAsJsonArray(direction) ?: continue
                for (element in array) {
                    if (!element.isJsonObject) continue
                    val item = element.asJsonObject
                    if (item.get("valid")?.asString?.equals("Y", ignoreCase = true) != true) continue
                    // ttnt = 尚餘分鐘數；官方可能給數字或字串，兩者都要處理
                    val ttnt = item.get("ttnt")?.let { readInt(it) } ?: continue
                    val eta = now.plus(ttnt.toLong(), ChronoUnit.MINUTES)
                    val destCode = item.get("dest")?.asString.orEmpty()
                    entries += EtaEntry(
                        routeKey = routeKey,
                        routeNo = ApiConstants.MTR_HEAVY_RAIL_LINES[line] ?: line,
                        operator = Operator.MTR_HR,
                        bound = direction,
                        serviceType = 1,
                        stopSeq = stopSeq,
                        eta = eta,
                        minutes = ttnt,
                        destTc = nameByCode[destCode] ?: destCode,
                        destEn = destCode,
                        remarkTc = item.get("plat")?.asString?.let { "月台 $it" },
                        source = EtaSource.REALTIME,
                        platform = item.get("plat")?.asString
                    )
                }
            }
            if (entries.isEmpty()) return@mapNotNull null
            StopEtaBoard(
                routeKey = routeKey,
                routeNo = ApiConstants.MTR_HEAVY_RAIL_LINES[line] ?: line,
                operator = Operator.MTR_HR,
                bound = entries.first().bound,
                destTc = entries.first().destTc,
                stopSeq = stopSeq,
                totalStops = totalStops,
                stopRole = SignalLightEngine.resolveStopRole(stopSeq, totalStops),
                entries = entries.sortedBy { it.eta },
                hasRealtime = true,
                fetchedAt = now
            )
        }
    }

    // ==================================================================
    // 輕鐵
    // ==================================================================

    private suspend fun boardLightRail(stationId: String, now: Instant): List<StopEtaBoard> {
        val response = try {
            mtr.lightRailSchedule(stationId)
        } catch (e: Exception) {
            return emptyList()
        }
        // status 非 0 代表官方沒有可提供的班次資料
        if ((response.status ?: 0) != 0) return emptyList()

        val platforms = response.platformList.orEmpty()
        if (platforms.isEmpty()) return emptyList()

        val stopKey = RouteKeys.stop(Operator.MTR_LR, stationId)
        val routeKeys = database.routeStopDao().ofStop(stopKey).map { it.routeKey }.distinct()

        return platforms.mapNotNull { platform ->
            val trains = platform.routeList.orEmpty()
            if (trains.isEmpty()) return@mapNotNull null
            val first = trains.first()
            val routeNo = first.routeNo?.takeIf { it.isNotBlank() } ?: return@mapNotNull null
            val routeKey = routeKeys.firstOrNull { RouteKeys.routeNoOf(it) == routeNo }
                ?: RouteKeys.route(Operator.MTR_LR, routeNo, "1", 1)
            val stopSeq = database.routeStopDao().ofRoute(routeKey)
                .firstOrNull { it.stopId == stationId }?.stopSeq ?: 1
            val totalStops = database.routeStopDao().countOfRoute(routeKey)

            val entries = trains.mapNotNull { train ->
                // 官方會回傳「即將抵站」等文字，必須視為 0 分鐘而非無資料
                val minutes = extractMinutes(train.timeCh) ?: extractMinutes(train.timeEn)
                val eta = minutes?.let { now.plus(it.toLong(), ChronoUnit.MINUTES) }
                EtaEntry(
                    routeKey = routeKey,
                    routeNo = routeNo,
                    operator = Operator.MTR_LR,
                    bound = train.arrivalDeparture ?: "A",
                    serviceType = 1,
                    stopSeq = stopSeq,
                    eta = eta,
                    minutes = minutes,
                    destTc = train.destCh.orEmpty(),
                    destEn = train.destEn.orEmpty(),
                    remarkTc = buildString {
                        platform.platformId?.let { append("月台 $it") }
                        train.trainLength?.let { if (it > 1) append(if (isNotEmpty()) "・$it 卡" else "$it 卡") }
                    }.takeIf { it.isNotBlank() },
                    source = if (eta == null) EtaSource.NONE else EtaSource.REALTIME,
                    trainLength = train.trainLength,
                    platform = platform.platformId?.toString()
                )
            }
            if (entries.none { it.eta != null }) return@mapNotNull null
            StopEtaBoard(
                routeKey = routeKey,
                routeNo = routeNo,
                operator = Operator.MTR_LR,
                bound = entries.first().bound,
                destTc = entries.first().destTc,
                stopSeq = stopSeq,
                totalStops = totalStops,
                stopRole = SignalLightEngine.resolveStopRole(stopSeq, totalStops),
                entries = entries.sortedWith(nullsLastComparator()),
                hasRealtime = true,
                fetchedAt = now
            )
        }
    }

    // ==================================================================
    // 港鐵巴士／接駁巴士（官方 POST API）
    // ==================================================================

    private suspend fun boardMtrBus(
        stopKey: String,
        stopId: String,
        now: Instant
    ): List<StopEtaBoard> = coroutineScope {
        // 找出此車站位於哪些港鐵巴士路線上，以及各自的站序
        val atStop = database.routeStopDao().ofStop(stopKey).take(maxRoutesPerStop)
        if (atStop.isEmpty()) return@coroutineScope emptyList()

        val routeKeys = atStop.map { it.routeKey }.distinct()

        // 一次取回對照表、站數與路線主檔，避免在迴圈內逐條查詢（N+1）
        val maps = database.mtrBusStopMapDao().ofRoutes(routeKeys).groupBy { it.routeKey }
        val totals = stopCounts(routeKeys)
        val routes = database.routeDao().getByKeys(routeKeys).associateBy { it.routeKey }

        // 每條路線呼叫一次政府 API，並行處理
        routeKeys.map { routeKey ->
            async {
                val route = routes[routeKey] ?: return@async emptyList()
                val seqToId = maps[routeKey]?.associate { it.stopSeq to it.busStopId }
                    ?: return@async emptyList()
                val routeName = maps[routeKey]?.firstOrNull()?.routeName
                    ?: return@async emptyList()

                val dto = try {
                    mtr.busSchedule(MtrBusRequest(routeName = routeName))
                } catch (e: Exception) {
                    return@async emptyList()
                }
                // status 非 "1" 代表本次回應不可信，視為查無資料
                if (dto.status != null && dto.status != "1") return@async emptyList()
                val apiStops = dto.busStop.orEmpty()
                if (apiStops.isEmpty()) return@async emptyList()

                val totalStops = totals[routeKey] ?: 0
                atStop.filter { it.routeKey == routeKey }.mapNotNull { rs ->
                    val busStopId = seqToId[rs.stopSeq] ?: return@mapNotNull null
                    val apiStop = apiStops.firstOrNull { it.busStopId == busStopId }
                        ?: return@mapNotNull null

                    val entries = apiStop.bus.orEmpty().mapNotNull { bus ->
                        // arrivalTimeInSecond 目前是官方佔位值，故以 departureTimeInSecond 為準
                        val seconds = bus.departureTimeInSecond?.toLongOrNull()
                            ?: bus.arrivalTimeInSecond?.toLongOrNull()
                            ?: return@mapNotNull null
                        if (seconds < 0) return@mapNotNull null
                        val eta = now.plusSeconds(seconds)
                        EtaEntry(
                            routeKey = routeKey,
                            routeNo = route.routeNo,
                            operator = Operator.MTR_BUS,
                            bound = route.bound,
                            serviceType = route.serviceType,
                            stopSeq = rs.stopSeq,
                            eta = eta,
                            minutes = SignalLightEngine.minutesBetween(now, eta),
                            destTc = route.destTc,
                            destEn = route.destEn,
                            remarkTc = bus.departureTimeText?.takeIf { it.isNotBlank() }
                                ?: bus.arrivalTimeText?.takeIf { it.isNotBlank() },
                            // isScheduled = "1" 表示依班次表推算，非實時位置
                            source = if (bus.isScheduled == "1") EtaSource.SCHEDULE else EtaSource.REALTIME
                        )
                    }.sortedBy { it.eta }
                    if (entries.isEmpty()) return@mapNotNull null

                    StopEtaBoard(
                        routeKey = routeKey,
                        routeNo = route.routeNo,
                        operator = Operator.MTR_BUS,
                        bound = route.bound,
                        destTc = route.destTc,
                        stopSeq = rs.stopSeq,
                        totalStops = totalStops,
                        stopRole = SignalLightEngine.resolveStopRole(rs.stopSeq, totalStops),
                        entries = entries,
                        hasRealtime = true,
                        fetchedAt = now
                    )
                }
            }
        }.awaitAll().flatten()
    }

    // ==================================================================
    // 由班次表推算（官方暫無資料時的後備方案）
    // ==================================================================

    private suspend fun boardFromSchedule(
        stopKey: String,
        operator: Operator,
        now: Instant
    ): List<StopEtaBoard> {
        val routeKeys = database.routeStopDao().ofStop(stopKey).map { it.routeKey }.distinct()
            .take(maxRoutesPerStop)
        if (routeKeys.isEmpty()) return emptyList()
        val headways = database.headwayDao().all().groupBy { it.routeKey }

        return routeKeys.mapNotNull { routeKey ->
            val stops = database.routeStopDao().ofRoute(routeKey)
            val stopSeq = stops.firstOrNull { it.stopKey == stopKey }?.stopSeq ?: return@mapNotNull null
            val route = database.routeDao().get(routeKey) ?: return@mapNotNull null
            val entries = extrapolate(
                headways = headways[routeKey]
                    ?: database.headwayDao().ofRouteNo(route.routeNo, operator.code),
                now = now,
                route = route,
                operator = operator,
                routeKey = routeKey,
                stopSeq = stopSeq
            )
            StopEtaBoard(
                routeKey = routeKey,
                routeNo = route.routeNo,
                operator = operator,
                bound = route.bound,
                destTc = route.destTc,
                stopSeq = stopSeq,
                totalStops = stops.size,
                stopRole = SignalLightEngine.resolveStopRole(stopSeq, stops.size),
                entries = entries,
                hasRealtime = false,
                fetchedAt = now
            )
        }
    }

    /**
     * 依班次表（GTFS frequencies）由現在時間往後推算最多三班車。
     *
     * GTFS 允許以 24:00 之後的時間表示翌日服務（例如 25:30:00），
     * 因此起訖時間一律先轉成「從當日 00:00 起算的秒數」再比較，
     * 否則跨午夜的班次會被誤判為「不在服務時段」。
     */
    private fun extrapolate(
        headways: List<HeadwayEntity>,
        now: Instant,
        route: RouteEntity,
        operator: Operator,
        routeKey: String,
        stopSeq: Int
    ): List<EtaEntry> {
        if (headways.isEmpty()) return emptyList()
        val nowSeconds = now.atZone(HKT).toLocalTime().toSecondOfDay()
        val out = mutableListOf<EtaEntry>()
        headways.sortedBy { parseGtfsSeconds(it.startTime) }.forEach { slot ->
            val start = parseGtfsSeconds(slot.startTime) ?: return@forEach
            val end = parseGtfsSeconds(slot.endTime) ?: return@forEach
            // 跨午夜：結束時間小於開始時間代表結束於翌日
            val endAdj = if (end <= start) end + SECONDS_PER_DAY else end
            val nowAdj = if (nowSeconds < start) nowSeconds + SECONDS_PER_DAY else nowSeconds
            if (nowAdj < start || nowAdj >= endAdj) return@forEach

            val headway = slot.headwaySecs.coerceAtLeast(MIN_HEADWAY_SECS)
            val elapsed = nowAdj - start
            var offset = headway - (elapsed % headway)
            repeat(3) {
                val eta = now.plusSeconds(offset)
                out += EtaEntry(
                    routeKey = routeKey,
                    routeNo = route.routeNo,
                    operator = operator,
                    bound = route.bound,
                    serviceType = 1,
                    stopSeq = stopSeq,
                    eta = eta,
                    minutes = SignalLightEngine.minutesBetween(now, eta),
                    destTc = route.destTc,
                    destEn = route.destEn,
                    remarkTc = "按班次表推算，每 ${headway / 60} 分鐘一班",
                    source = EtaSource.SCHEDULE
                )
                offset += headway
            }
        }
        return out.sortedBy { it.eta }.take(3)
    }

    /** 解析 GTFS 時間（HH:mm:ss，可超過 24 小時）成自當日 00:00 起算的秒數。 */
    private fun parseGtfsSeconds(raw: String): Int? {
        val parts = raw.trim().split(":")
        if (parts.size < 2) return null
        val h = parts[0].trim().toIntOrNull() ?: return null
        val m = parts[1].trim().toIntOrNull() ?: return null
        val s = parts.getOrNull(2)?.trim()?.toIntOrNull() ?: 0
        return h * 3600 + m * 60 + s
    }

    /**
     * 從「2 分鐘」／「Arriving」等官方文字取出分鐘數。
     * 「即將抵站」等沒有數字的文字視為 0 分鐘（即將進站），而非無資料。
     */
    private fun extractMinutes(text: String?): Int? {
        if (text.isNullOrBlank()) return null
        val digits = Regex("\\d+").find(text)?.value?.toIntOrNull()
        if (digits != null) return digits
        val t = text.trim()
        val isArriving = ARRIVING_TEXTS.any { t.contains(it, ignoreCase = true) }
        return if (isArriving) 0 else null
    }

    /** 一次取得多條路線的車站總數。 */
    private suspend fun stopCounts(routeKeys: Collection<String>): Map<String, Int> {
        if (routeKeys.isEmpty()) return emptyMap()
        return database.routeStopDao().countOfRoutes(routeKeys).associate { it.routeKey to it.count }
    }

    private fun nullsLastComparator(): Comparator<EtaEntry> = compareBy(nullsLast()) { it.eta }

    /**
     * 安全地從 JsonElement 讀取整數。
     *
     * 官方 API 有時回傳 `"ttnt": "3"`（字串）、有時回傳 `"ttnt": 3`（數字），
     * 直接 `asInt` 在其中一種情況會拋出例外；此函式兩者都支援。
     */
    private fun readInt(element: com.google.gson.JsonElement): Int? {
        if (element.isJsonNull) return null
        return try {
            element.asString.trim().toIntOrNull()
        } catch (e: Exception) {
            null
        }
    }

    /** 供介面顯示：由 board 推導角色文字。 */
    fun roleText(role: StopRole): String = role.labelTc

    companion object {
        const val SECONDS_PER_DAY = 24 * 60 * 60
        const val MIN_HEADWAY_SECS = 60

        private val ARRIVING_TEXTS = listOf(
            "即將抵站", "即將到站", "即將進站", "即将抵站",
            "arriving", "arrive", "now", "due"
        )
    }
}
