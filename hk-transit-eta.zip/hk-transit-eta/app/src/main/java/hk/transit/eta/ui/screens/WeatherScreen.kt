package hk.transit.eta.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import hk.transit.eta.R
import hk.transit.eta.core.util.TimeUtil
import hk.transit.eta.domain.WeatherImpactEngine
import hk.transit.eta.domain.model.RecoveryStage
import hk.transit.eta.domain.model.ServiceImpact
import hk.transit.eta.domain.model.WeatherEvent
import hk.transit.eta.domain.model.WeatherRouteImpact
import hk.transit.eta.ui.viewmodel.WeatherViewModel

/**
 * 天氣對服務的影響：
 *  - 生效中的警告
 *  - 受影響路線與班次時間表
 *  - 推算／實際恢復時間表與路線數量
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WeatherScreen(
    viewModel: WeatherViewModel,
    modifier: Modifier = Modifier
) {
    val summary by viewModel.summary.collectAsState()
    val loading by viewModel.loading.collectAsState()

    Scaffold(
        modifier = modifier,
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.weather_title)) },
                actions = {
                    IconButton(onClick = viewModel::refresh, enabled = !loading) {
                        Icon(Icons.Default.Refresh, contentDescription = stringResource(R.string.action_refresh))
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (summary == null || (summary?.activeEvents.isNullOrEmpty())) {
                item {
                    Text(
                        text = stringResource(R.string.weather_none),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                return@LazyColumn
            }

            val data = summary!!
            item {
                Text(
                    text = stringResource(R.string.weather_affected_routes, data.affectedRouteCount),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
            items(data.activeEvents, key = { it.key }) { event ->
                WeatherEventCard(event)
            }
            item {
                Text(
                    text = stringResource(R.string.weather_recovery_title),
                    style = MaterialTheme.typography.titleSmall,
                    modifier = Modifier.padding(top = 6.dp)
                )
            }
            items(data.recoveryStages, key = { it.stage }) { stage ->
                RecoveryStageCard(stage)
            }
            item {
                Text(
                    text = "受影響路線與班次時間表（${data.affectedRoutes.size} 條）",
                    style = MaterialTheme.typography.titleSmall,
                    modifier = Modifier.padding(top = 6.dp)
                )
            }
            items(data.affectedRoutes.take(200), key = { it.routeKey + it.bound }) { impact ->
                WeatherRouteCard(impact)
            }
            item {
                Text(
                    text = stringResource(R.string.disclaimer_estimate),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun WeatherEventCard(event: WeatherEvent) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                text = "⚠ ${event.warningName}",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = when (event.level) {
                    WeatherImpactEngine.LEVEL_HIGH -> "級別：嚴重"
                    WeatherImpactEngine.LEVEL_MEDIUM -> "級別：中度"
                    else -> "級別：輕微"
                },
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            event.issueTime?.let {
                Text(
                    text = "發出時間：${TimeUtil.formatDateTime(it)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (event.detail.isNotBlank()) {
                Text(
                    text = event.detail,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun RecoveryStageCard(stage: RecoveryStage) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                text = "階段 ${stage.stage}・警告後 ${stage.minutesAfterDowngrade} 分鐘（${stage.routeCount} 條路線）",
                style = MaterialTheme.typography.titleSmall
            )
            Text(
                text = stage.description,
                style = MaterialTheme.typography.bodySmall
            )
            stage.actualAt?.let {
                Text(
                    text = stringResource(R.string.weather_recovery_actual, TimeUtil.formatDateTime(it)),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary
                )
            } ?: stage.estimatedAt?.let {
                Text(
                    text = stringResource(R.string.weather_recovery_estimate, TimeUtil.formatDateTime(it)),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun WeatherRouteCard(impact: WeatherRouteImpact) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                color = when (impact.impact) {
                    ServiceImpact.SUSPENDED -> MaterialTheme.colorScheme.errorContainer
                    ServiceImpact.PARTIAL_SUSPENDED -> MaterialTheme.colorScheme.tertiaryContainer
                    else -> MaterialTheme.colorScheme.secondaryContainer
                },
                shape = MaterialTheme.shapes.small
            ) {
                Text(
                    text = impact.routeNo,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
            }
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 10.dp)
            ) {
                Text("往${impact.destTc}", style = MaterialTheme.typography.bodyMedium)
                Text(
                    impact.impact.labelTc,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                impact.normalHeadwayMinutes?.let {
                    Text(
                        text = stringResource(R.string.weather_headway_normal, it),
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                impact.affectedHeadwayMinutes?.let {
                    Text(
                        text = stringResource(R.string.weather_headway_affected, it),
                        style = MaterialTheme.typography.bodySmall
                    )
                } ?: Text(
                    text = "受影響班次時間表：暫停",
                    style = MaterialTheme.typography.bodySmall
                )
                if (impact.isEstimate) {
                    Text(
                        text = stringResource(R.string.signal_estimated_badge),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}
