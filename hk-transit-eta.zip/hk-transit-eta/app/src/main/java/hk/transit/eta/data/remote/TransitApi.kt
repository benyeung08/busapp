package hk.transit.eta.data.remote

import com.google.gson.JsonObject
import com.google.gson.annotations.SerializedName
import hk.transit.eta.data.remote.dto.*
import okhttp3.ResponseBody
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query

/** 政府 API 的統一外層（generated_timestamp + data）。 */
data class DataListResponse<T>(
    @SerializedName("generated_timestamp") val generatedTimestamp: String? = null,
    // 可空：Gson 不會套用 Kotlin 預設值，缺少欄位時會是 null
    @SerializedName("data") val data: List<T>? = null
)

/** GMB「路線列表」外層：按分區分組，或指定分區時的純清單。 */
data class GmbRouteListingResponse(
    @SerializedName("generated_timestamp") val generatedTimestamp: String? = null,
    @SerializedName("data") val data: JsonObject? = null
)

data class GmbRegionalRoutesDto(
    @SerializedName("routes") val routes: List<String> = emptyList(),
    @SerializedName("data_timestamp") val dataTimestamp: String? = null
)

data class GmbRouteDetailWrapper(
    @SerializedName("generated_timestamp") val generatedTimestamp: String? = null,
    @SerializedName("data") val data: GmbRouteDetailDto? = null
)

data class GmbStopWrapper(
    @SerializedName("generated_timestamp") val generatedTimestamp: String? = null,
    @SerializedName("data") val data: List<GmbStopDto>? = null
)

data class GmbRouteStopWrapper(
    @SerializedName("generated_timestamp") val generatedTimestamp: String? = null,
    @SerializedName("data") val data: List<GmbRouteStopDto>? = null
)

data class GmbEtaWrapper(
    @SerializedName("generated_timestamp") val generatedTimestamp: String? = null,
    @SerializedName("data") val data: List<GmbEtaDto>? = null
)

data class GmbLastUpdateWrapper(
    @SerializedName("generated_timestamp") val generatedTimestamp: String? = null,
    @SerializedName("data") val data: String? = null
)

// =====================================================================
// 九巴／龍運
// =====================================================================
interface KmbService {
    @GET(ApiConstants.KMB_ROUTE)
    suspend fun routes(): DataListResponse<KmbRouteDto>

    @GET(ApiConstants.KMB_STOP)
    suspend fun stops(): DataListResponse<KmbStopDto>

    @GET(ApiConstants.KMB_ROUTE_STOP)
    suspend fun routeStops(): DataListResponse<KmbRouteStopDto>

    @GET(ApiConstants.KMB_STOP_ETA)
    suspend fun stopEta(@Path("stop_id") stopId: String): DataListResponse<KmbEtaDto>

    @GET(ApiConstants.KMB_ETA)
    suspend fun eta(
        @Path("stop_id") stopId: String,
        @Path("route") route: String,
        @Path("service_type") serviceType: Int
    ): DataListResponse<KmbEtaDto>
}

// =====================================================================
// 城巴
// =====================================================================
interface CtbService {
    @GET(ApiConstants.CTB_ROUTE)
    suspend fun routes(@Path("company_id") companyId: String): DataListResponse<CtbRouteDto>

    @GET(ApiConstants.CTB_STOP)
    suspend fun stop(@Path("stop_id") stopId: String): DataListResponse<CtbStopDto>

    /** 不帶 stop_id，一次取回城巴全部車站。 */
    @GET(ApiConstants.CTB_STOP_LIST)
    suspend fun allStops(): DataListResponse<CtbStopDto>

    @GET(ApiConstants.CTB_ROUTE_STOP)
    suspend fun routeStops(
        @Path("company_id") companyId: String,
        @Path("route") route: String,
        @Path("direction") direction: String
    ): DataListResponse<CtbRouteStopDto>

    @GET(ApiConstants.CTB_ETA)
    suspend fun eta(
        @Path("company_id") companyId: String,
        @Path("stop_id") stopId: String,
        @Path("route") route: String
    ): DataListResponse<CtbEtaDto>
}

// =====================================================================
// 新大嶼山巴士
// =====================================================================
interface NlbService {
    @GET(ApiConstants.NLB_ROUTE_LIST)
    suspend fun routes(@Query("action") action: String = "list"): NlbRouteListDto

    @GET(ApiConstants.NLB_STOP_LIST)
    suspend fun stops(
        @Query("action") action: String = "list",
        @Query("routeId") routeId: String
    ): NlbStopListDto

    @GET(ApiConstants.NLB_ETA)
    suspend fun eta(
        @Query("action") action: String = "estimatedArrivals",
        @Query("routeId") routeId: String,
        @Query("stopId") stopId: String,
        @Query("language") language: String = ApiConstants.LANGUAGE_ZH
    ): NlbEtaDto
}

// =====================================================================
// 專線小巴
// =====================================================================
interface GmbService {
    @GET(ApiConstants.GMB_ROUTE_ALL)
    suspend fun allRoutes(): GmbRouteListingResponse

    @GET(ApiConstants.GMB_ROUTE_DETAIL)
    suspend fun routeDetail(
        @Path("region") region: String,
        @Path("route_code") routeCode: String
    ): GmbRouteDetailWrapper

    @GET(ApiConstants.GMB_STOP)
    suspend fun stop(@Path("stop_id") stopId: String): GmbStopWrapper

    @GET(ApiConstants.GMB_ROUTE_STOP)
    suspend fun routeStops(
        @Path("route_id") routeId: String,
        @Path("route_seq") routeSeq: Int
    ): GmbRouteStopWrapper

    @GET(ApiConstants.GMB_STOP_ETA)
    suspend fun stopEta(@Path("stop_id") stopId: String): GmbEtaWrapper

    @GET(ApiConstants.GMB_ETA)
    suspend fun eta(
        @Path("route_id") routeId: String,
        @Path("route_seq") routeSeq: Int,
        @Path("stop_seq") stopSeq: Int
    ): GmbEtaWrapper

    @GET(ApiConstants.GMB_LAST_UPDATE_ROUTE)
    suspend fun lastUpdateRoute(): GmbLastUpdateWrapper

    @GET(ApiConstants.GMB_LAST_UPDATE_STOP)
    suspend fun lastUpdateStop(): GmbLastUpdateWrapper
}

// =====================================================================
// 港鐵重鐵／輕鐵／港鐵巴士
// =====================================================================
interface MtrService {
    /** 重鐵：回傳動態結構，故以 JsonObject 處理。 */
    @GET(ApiConstants.MTR_SCHEDULE)
    suspend fun heavyRailSchedule(
        @Query("line") line: String,
        @Query("sta") sta: String,
        @Query("lang") lang: String = ApiConstants.LANG_TC
    ): JsonObject

    /**
     * 輕鐵：以 station_id 查詢。
     *
     * 回傳 JsonObject 而非固定 DTO：官方回應的 `platform_list` 有時位於頂層、
     * 有時包在 `data` 下再以車站鍵分組，固定 DTO 只會命中其中一種結構。
     */
    @GET(ApiConstants.MTR_LR_SCHEDULE)
    suspend fun lightRailSchedule(@Query("station_id") stationId: String): JsonObject

    /**
     * 港鐵巴士／接駁巴士：官方規格為 **POST**，
     * 主體為 {"language":"zh","routeName":"K12"}，回應為固定結構。
     */
    @POST(ApiConstants.MTR_BUS_SCHEDULE)
    suspend fun busSchedule(@Body body: MtrBusRequest): MtrBusScheduleDto
}

/** 港鐵巴士 API 的請求主體。 */
data class MtrBusRequest(
    @SerializedName("language") val language: String = ApiConstants.LANGUAGE_ZH,
    @SerializedName("routeName") val routeName: String
)

// =====================================================================
// 天文台
// =====================================================================
interface HkoService {
    @GET(ApiConstants.HKO_WEATHER)
    suspend fun weather(
        @Query("dataType") dataType: String,
        @Query("lang") lang: String = "tc"
    ): JsonObject
}

// =====================================================================
// 靜態檔案（CSV / XML）：直接取原始字串
// =====================================================================
interface StaticFileService {
    @GET
    suspend fun raw(@retrofit2.http.Url url: String): ResponseBody
}

// =====================================================================
// GitHub 後端資料集
// =====================================================================

/**
 * 由 GitHub Actions 產生、放在倉庫 `data/` 目錄的預處理資料集。
 *
 * 所有方法都接受完整網址（@Url），因為倉庫擁有者與名稱是建置時設定的
 * （見 BuildConfig.DATASET_*），無法寫死在註解裡。
 */
interface DatasetService {

    @GET
    suspend fun manifest(@retrofit2.http.Url url: String): DatasetManifestDto

    @GET
    suspend fun routes(@retrofit2.http.Url url: String): List<DatasetRouteDto>

    @GET
    suspend fun stops(@retrofit2.http.Url url: String): List<DatasetStopDto>

    /** 回傳 `[路線索引, 車站索引, 站序]` 三元組陣列（體積考量）。 */
    @GET
    suspend fun routeStops(@retrofit2.http.Url url: String): List<List<Int>>

    @GET
    suspend fun mtrBusMap(@retrofit2.http.Url url: String): List<DatasetMtrBusMapDto>

    @GET
    suspend fun changes(@retrofit2.http.Url url: String): List<DatasetChangeDto>

    @GET
    suspend fun weather(@retrofit2.http.Url url: String): DatasetWeatherDto
}
