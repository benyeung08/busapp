package hk.transit.eta.data.remote

import hk.transit.eta.BuildConfig

/**
 * 全部資料來源的端點定義。
 *
 * 資料來源（均為香港特區政府「資料一線通」或營辦商官方開放資料）：
 *  - 九巴／龍運   data.etabus.gov.hk
 *  - 城巴         rt.data.gov.hk/v2/transport/citybus
 *  - 新大嶼山巴士 rt.data.gov.hk/v2/transport/nlb
 *  - 專線小巴     data.etagmb.gov.hk
 *  - 港鐵重鐵     rt.data.gov.hk/v1/transport/mtr/getSchedule.php
 *  - 輕鐵         rt.data.gov.hk/v1/transport/mtr/lrt/getSchedule
 *  - 港鐵巴士     rt.data.gov.hk/v1/transport/mtr/bus/getSchedule
 *  - 天文台       data.weather.gov.hk
 *  - 運輸署靜態檔 static.data.gov.hk/td
 *  - 運輸署消息   www.td.gov.hk/.../trafficnews.xml
 */
object ApiConstants {

    // ---------- 即時到站 API 基礎網址 ----------
    val KMB_BASE: String get() = BuildConfig.KMB_BASE
    val CTB_BASE: String get() = BuildConfig.CTB_BASE
    val NLB_BASE: String get() = BuildConfig.CTB_BASE      // NLB 與城巴同屬 rt.data.gov.hk
    val GMB_BASE: String get() = BuildConfig.GMB_BASE
    val MTR_BASE: String get() = BuildConfig.MTR_BASE
    val HKO_BASE: String get() = BuildConfig.HKO_BASE
    val TD_STATIC_BASE: String get() = BuildConfig.TD_STATIC_BASE
    val TD_NEWS_BASE: String get() = BuildConfig.TD_NEWS_BASE
    val MTR_OPEN_BASE: String get() = BuildConfig.MTR_OPEN_BASE

    // ---------- 九巴／龍運 ----------
    const val KMB_ROUTE = "v1/transport/kmb/route/"
    const val KMB_STOP = "v1/transport/kmb/stop/"
    const val KMB_ROUTE_STOP = "v1/transport/kmb/route-stop/"
    const val KMB_STOP_ETA = "v1/transport/kmb/stop-eta/{stop_id}"
    const val KMB_ETA = "v1/transport/kmb/eta/{stop_id}/{route}/{service_type}"

    // ---------- 城巴 ----------
    const val CTB_ROUTE = "v2/transport/citybus/route/{company_id}"
    const val CTB_STOP = "v2/transport/citybus/stop/{stop_id}"
    /** 不填 stop_id 即回傳城巴全部車站（約二千個），每日只需一次。 */
    const val CTB_STOP_LIST = "v2/transport/citybus/stop"
    const val CTB_ROUTE_STOP = "v2/transport/citybus/route-stop/{company_id}/{route}/{direction}"
    const val CTB_ETA = "v2/transport/citybus/eta/{company_id}/{stop_id}/{route}"

    // ---------- 新大嶼山巴士 ----------
    const val NLB_ROUTE_LIST = "v2/transport/nlb/route.php"
    const val NLB_STOP_LIST = "v2/transport/nlb/stop.php"
    const val NLB_ETA = "v2/transport/nlb/stop.php"

    // ---------- 專線小巴 ----------
    const val GMB_ROUTE_ALL = "route"
    const val GMB_ROUTE_REGION = "route/{region}"
    const val GMB_ROUTE_DETAIL = "route/{region}/{route_code}"
    const val GMB_STOP = "stop/{stop_id}"
    const val GMB_ROUTE_STOP = "route-stop/{route_id}/{route_seq}"
    const val GMB_STOP_ETA = "stop-eta/{stop_id}"
    const val GMB_ETA = "eta/route-stop/{route_id}/{route_seq}/{stop_seq}"
    const val GMB_LAST_UPDATE_ROUTE = "last-update/route"
    const val GMB_LAST_UPDATE_STOP = "last-update/stop"

    // ---------- 港鐵重鐵／輕鐵／港鐵巴士 ----------
    const val MTR_SCHEDULE = "v1/transport/mtr/getSchedule.php"
    const val MTR_LR_SCHEDULE = "v1/transport/mtr/lrt/getSchedule"
    /**
     * 港鐵巴士／接駁巴士實時到站。
     *
     * 資料集「港鐵巴士及接駁巴士實時到站時間」由港鐵公司提供資料、
     * 於政府「資料一線通」平台（data.gov.hk）發布，呼叫端點位於政府網域 rt.data.gov.hk。
     *
     * ⚠️ 重要：此端點的**路徑未經官方文件直接證實**。
     * data.gov.hk 的資料集頁面只提供數據字典與規格文件的連結，並未列出可引用的端點網址；
     * 此處的路徑是依重鐵（getSchedule.php）與輕鐵（lrt/getSchedule）的命名規則推測而來。
     *
     * 若路徑有誤，查詢會靜默落空並退回班次表推算，使用者完全看不出異常。
     * 因此請務必執行 `.github/workflows/verify-apis.yml`（Actions → Verify APIs），
     * 由 runner 實測各候選端點；報告會直接指出哪一個 URL 可用。
     *
     * 官方數據字典標示此端點為 **POST**，
     * 主體為 {"language":"zh","routeName":"K12"}；使用 GET 可能得到 400。
     */
    const val MTR_BUS_SCHEDULE = "v1/transport/mtr/bus/getSchedule"

    // ---------- 港鐵靜態 CSV ----------
    const val MTR_LINES_STATIONS_CSV = "mtr_lines_and_stations.csv"
    const val MTR_LR_ROUTES_STOPS_CSV = "light_rail_routes_and_stops.csv"
    // 港鐵巴士不再使用 opendata.mtr.com.hk 的 mtr_bus_routes.csv / mtr_bus_stops.csv：
    // 那兩份檔只有路線與車站清單，沒有去回程站序，不足以支撐燈號所需的站序判斷。
    // 改由運輸署「路線及收費資料」（含 ROUTE_SEQ 與 STOP_SEQ）提供目錄，
    // 即時到站則用下方的 MTR_BUS_SCHEDULE。

    // ---------- 天文台 ----------
    const val HKO_WEATHER = "weather.php"

    // ---------- 運輸署靜態資料 ----------
    private const val RF = "routes-and-fares/"
    const val TD_ROUTE_BUS = "${RF}ROUTE_BUS.csv"
    const val TD_ROUTE_BUS_DELTA = "${RF}ROUTE_BUS_DELTA.csv"
    const val TD_RSTOP_BUS = "${RF}RSTOP_BUS.csv"
    const val TD_RSTOP_BUS_DELTA = "${RF}RSTOP_BUS_DELTA.csv"
    const val TD_STOP_BUS = "${RF}STOP_BUS.csv"
    const val TD_STOP_BUS_DELTA = "${RF}STOP_BUS_DELTA.csv"
    const val TD_ROUTE_GMB = "${RF}ROUTE_GMB.csv"
    const val TD_ROUTE_GMB_DELTA = "${RF}ROUTE_GMB_DELTA.csv"
    const val TD_RSTOP_GMB = "${RF}RSTOP_GMB.csv"
    const val TD_RSTOP_GMB_DELTA = "${RF}RSTOP_GMB_DELTA.csv"
    const val TD_STOP_GMB = "${RF}STOP_GMB.csv"
    const val TD_STOP_GMB_DELTA = "${RF}STOP_GMB_DELTA.csv"

    /** 班次時間表（GTFS 格式，每兩星期更新） */
    private const val HW = "pt-headway-tc/"
    const val TD_HEADWAY_ROUTES = "${HW}routes.txt"
    const val TD_HEADWAY_STOPS = "${HW}stops.txt"
    const val TD_HEADWAY_TRIPS = "${HW}trips.txt"
    const val TD_HEADWAY_FREQUENCIES = "${HW}frequencies.txt"
    const val TD_HEADWAY_CALENDAR = "${HW}calendar.txt"
    const val TD_HEADWAY_AGENCY = "${HW}agency.txt"

    // ---------- 運輸署特別交通消息（即時、XML） ----------
    const val TD_NEWS_TC = "tc/special_news/trafficnews.xml"
    const val TD_NEWS_EN = "en/special_news/trafficnews.xml"

    // ---------- 常數 ----------
    const val CTB_COMPANY_ID = "CTB"
    const val LANG_TC = "TC"
    const val LANGUAGE_ZH = "zh"

    // 港鐵巴士的 routeName 不再寫死成常數清單：
    // 路線會隨時間增減，寫死的清單只會日漸過時。
    // 現改由運輸署目錄中 COMPANY_CODE ＝ LRTFEEDER 的路線動態取得，
    // 每日同步時逐條呼叫 API，失敗的路線自然被略過。

    /** GMB 三大分區 */
    val GMB_REGIONS = listOf("HKI", "KLN", "NT")

    /**
     * 港鐵路線代碼 → 中文名稱（重鐵）。
     * Next Train API 只接受路線代碼，故需這份對照表。
     */
    val MTR_HEAVY_RAIL_LINES = mapOf(
        "AEL" to "機場快綫",
        "TCL" to "東涌綫",
        "TML" to "屯馬綫",
        "TKL" to "將軍澳綫",
        "EAL" to "東鐵綫",
        "SIL" to "南港島綫",
        "TWL" to "荃灣綫",
        "ISL" to "港島綫",
        "KTL" to "觀塘綫",
        "DRL" to "迪士尼綫"
    )
}
