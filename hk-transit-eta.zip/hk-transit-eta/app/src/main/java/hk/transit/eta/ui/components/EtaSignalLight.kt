package hk.transit.eta.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import hk.transit.eta.R
import hk.transit.eta.domain.SignalColour
import hk.transit.eta.domain.SignalLight
import hk.transit.eta.domain.SignalPhase
import hk.transit.eta.domain.model.StopRole
import hk.transit.eta.ui.theme.SignalAmber
import hk.transit.eta.ui.theme.SignalGreen
import hk.transit.eta.ui.theme.SignalRed

/**
 * 巴士與小巴車站的「時間燈號」。
 *
 * 起點站：2–5 分鐘閃爍「本班車即將開出」→ ≤1 分鐘「本班車開出中」→ 顯示下一班時間
 * 中途站：≤1 分鐘閃爍「本班車即將到站」→「本班車離站中」→ 顯示下一班時間
 * 終點站：≤1 分鐘閃爍「本班車已到達終點站，請所有乘客落車。」
 */
@Composable
fun EtaSignalLight(
    signal: SignalLight,
    role: StopRole,
    flashEnabled: Boolean,
    modifier: Modifier = Modifier
) {
    val shouldFlash = signal.flash && flashEnabled
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically
    ) {
        TrafficLights(colour = signal.colour, flash = shouldFlash)
        Spacer(Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            SignalHeadline(signal = signal, role = role, flash = shouldFlash)
            if (signal.nextMinutes != null && signal.phase != SignalPhase.TERMINUS_ARRIVED) {
                Text(
                    text = stringResource(R.string.next_departure_minutes, signal.nextMinutes),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun TrafficLights(colour: SignalColour, flash: Boolean) {
    val infinite = rememberInfiniteTransition(label = "signal")
    val alpha by infinite.animateFloat(
        initialValue = 1f,
        targetValue = 0.25f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 600, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "signalAlpha"
    )
    Column(
        verticalArrangement = Arrangement.spacedBy(6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Lamp(SignalRed, active = colour == SignalColour.RED, flash = flash, alpha = alpha)
        Lamp(SignalAmber, active = colour == SignalColour.AMBER, flash = flash, alpha = alpha)
        Lamp(SignalGreen, active = colour == SignalColour.GREEN, flash = flash, alpha = alpha)
    }
}

@Composable
private fun Lamp(colour: Color, active: Boolean, flash: Boolean, alpha: Float) {
    val base = if (active) colour else colour.copy(alpha = 0.18f)
    val modifier = Modifier
        .size(22.dp)
        .then(if (active && flash) Modifier.alpha(alpha) else Modifier)
        .background(color = base, shape = CircleShape)
    Spacer(modifier = modifier)
}

@Composable
private fun SignalHeadline(signal: SignalLight, role: StopRole, flash: Boolean) {
    val headline = signalHeadlineText(signal, role)
    Text(
        text = headline,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
        color = when (signal.colour) {
            SignalColour.RED -> SignalRed
            SignalColour.AMBER -> SignalAmber
            SignalColour.GREEN -> SignalGreen
            SignalColour.GREY -> MaterialTheme.colorScheme.onSurfaceVariant
        }
    )
}

@Composable
fun signalHeadlineText(signal: SignalLight, role: StopRole): String = when (signal.phase) {
    SignalPhase.ORIGIN_PREPARE -> stringResource(R.string.signal_origin_prepare)
    SignalPhase.ORIGIN_DEPARTING -> stringResource(R.string.signal_origin_departing)
    SignalPhase.STOP_ARRIVING -> stringResource(R.string.signal_stop_arriving)
    SignalPhase.STOP_DEPARTED -> stringResource(R.string.signal_stop_departed)
    SignalPhase.TERMINUS_ARRIVED -> stringResource(R.string.signal_terminus_arrived)
    SignalPhase.NO_SERVICE -> stringResource(R.string.signal_no_service)
    SignalPhase.SERVICE_ENDED -> stringResource(R.string.signal_service_ended)
    SignalPhase.DATA_UNAVAILABLE -> stringResource(R.string.signal_data_unavailable)
    SignalPhase.SCHEDULED -> scheduledHeadline(signal.minutes, role)
}

@Composable
private fun scheduledHeadline(minutes: Int?, role: StopRole): String {
    val m = minutes ?: 0
    return when (role) {
        StopRole.ORIGIN -> if (m <= 0) stringResource(R.string.signal_origin_prepare)
        else stringResource(R.string.signal_origin_scheduled, m)
        StopRole.TERMINUS -> if (m <= 0) stringResource(R.string.signal_terminus_arrived)
        else stringResource(R.string.signal_terminus_scheduled, m)
        StopRole.INTERMEDIATE -> if (m <= 0) stringResource(R.string.signal_stop_arriving)
        else stringResource(R.string.signal_stop_scheduled, m)
    }
}

/** 車站角色標籤（起點站／中途站／終點站）。 */
@Composable
fun StopRoleBadge(role: StopRole, stopSeq: Int, totalStops: Int) {
    Surface(
        color = when (role) {
            StopRole.ORIGIN -> SignalGreen.copy(alpha = 0.14f)
            StopRole.TERMINUS -> SignalRed.copy(alpha = 0.14f)
            StopRole.INTERMEDIATE -> MaterialTheme.colorScheme.surfaceVariant
        },
        shape = MaterialTheme.shapes.small
    ) {
        Text(
            text = "${stringResource(labelOf(role))}・${
                stringResource(R.string.label_stop_seq, stopSeq, totalStops)
            }",
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
            style = MaterialTheme.typography.labelMedium,
            color = when (role) {
                StopRole.ORIGIN -> SignalGreen
                StopRole.TERMINUS -> SignalRed
                StopRole.INTERMEDIATE -> MaterialTheme.colorScheme.onSurfaceVariant
            }
        )
    }
}

@Composable
private fun labelOf(role: StopRole) = when (role) {
    StopRole.ORIGIN -> R.string.label_origin
    StopRole.INTERMEDIATE -> R.string.label_intermediate
    StopRole.TERMINUS -> R.string.label_terminus
}

/** 資料來源標籤：即時 / 推算。 */
@Composable
fun SourceBadge(isEstimate: Boolean) {
    Surface(
        color = if (isEstimate) SignalAmber.copy(alpha = 0.14f) else SignalGreen.copy(alpha = 0.14f),
        shape = MaterialTheme.shapes.small
    ) {
        Text(
            text = stringResource(
                if (isEstimate) R.string.signal_estimated_badge else R.string.signal_realtime_badge
            ),
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
            style = MaterialTheme.typography.labelMedium,
            color = if (isEstimate) SignalAmber else SignalGreen
        )
    }
}

/** 供預覽與列表使用的簡化狀態列。 */
@Composable
fun SignalSummaryLine(signal: SignalLight, role: StopRole) {
    Column {
        Text(
            text = signalHeadlineText(signal, role),
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.SemiBold
        )
        Spacer(Modifier.height(2.dp))
    }
}
