package hk.transit.eta.domain

import hk.transit.eta.core.util.TimeUtil
import hk.transit.eta.data.local.db.DailyChangeEntity
import hk.transit.eta.data.local.db.HeadwayEntity
import hk.transit.eta.data.local.db.RouteEntity
import hk.transit.eta.domain.model.ChangeScope
import hk.transit.eta.domain.model.ChangeSource
import hk.transit.eta.domain.model.ChangeType
import hk.transit.eta.domain.model.Operator
import hk.transit.eta.domain.model.RecoveryStage
import hk.transit.eta.domain.model.ServiceImpact
import hk.transit.eta.domain.model.WeatherEvent
import hk.transit.eta.domain.model.WeatherRouteImpact
import java.time.Instant
import java.time.temporal.ChronoUnit
import kotlin.math.roundToInt

/**
 * 天氣對服務的影響推算引擎。
 *
 * ⚠️ 重要：天文台與運輸署並未提供「某條路線因天氣暫停」的結構化開放數據。
 * 本引擎是根據各營辦商一貫做法（八號信號／黑色暴雨下的安排）建立的規則表，
 * 所有推算結果在介面上均會標示「推算」，並會在偵測到運輸署／營辦商
 * 發出「恢復正常」消息後，以實際時間覆寫。
 */
object WeatherImpactEngine {

    const val LEVEL_NONE = 0
    const val LEVEL_LOW = 1      // 一號／三號信號、黃色暴雨、雷暴
    const val LEVEL_MEDIUM = 2   // 八號信號、紅色暴雨、山泥傾瀉
    const val LEVEL_HIGH = 3     // 九號／十號信號、黑色暴雨

    /** 由警告名稱／內容推算嚴重級別。 */
    fun severityOf(name: String, detail: String = ""): Int {
        val text = "$name $detail"
        return when {
            text.contains("十號") || text.contains("颶風") -> LEVEL_HIGH
            text.contains("九號") -> LEVEL_HIGH
            text.contains("黑色暴雨") -> LEVEL_HIGH
            text.contains("八號") -> LEVEL_MEDIUM
            text.contains("紅色暴雨") -> LEVEL_MEDIUM
            text.contains("山泥傾瀉") -> LEVEL_MEDIUM
            text.contains("水浸") -> LEVEL_MEDIUM
            text.contains("三號") -> LEVEL_LOW
            text.contains("一號") -> LEVEL_LOW
            text.contains("黃色暴雨") -> LEVEL_LOW
            text.contains("雷暴") -> LEVEL_LOW
            text.contains("強烈季候風") -> LEVEL_LOW
            else -> LEVEL_LOW
        }
    }

    /** 依營辦商與警告級別推算服務影響。 */
    fun impactFor(operator: Operator, level: Int): ServiceImpact = when (level) {
        LEVEL_NONE -> ServiceImpact.NORMAL
        LEVEL_LOW -> when (operator) {
            Operator.MTR_LR -> ServiceImpact.LIMITED
            else -> ServiceImpact.NORMAL
        }
        LEVEL_MEDIUM -> when (operator) {
            Operator.KMB, Operator.CTB, Operator.NLB, Operator.MTR_BUS -> ServiceImpact.LIMITED
            Operator.GMB -> ServiceImpact.PARTIAL_SUSPENDED
            Operator.MTR_HR -> ServiceImpact.LIMITED
            Operator.MTR_LR -> ServiceImpact.SUSPENDED
        }
        LEVEL_HIGH -> when (operator) {
            Operator.KMB, Operator.CTB, Operator.NLB, Operator.GMB,
            Operator.MTR_BUS, Operator.MTR_LR -> ServiceImpact.SUSPENDED
            Operator.MTR_HR -> ServiceImpact.LIMITED
        }
        else -> ServiceImpact.NORMAL
    }

    /** 受影響時的班次間距倍率。 */
    fun headwayMultiplier(level: Int): Double = when (level) {
        LEVEL_NONE -> 1.0
        LEVEL_LOW -> 1.0
        LEVEL_MEDIUM -> 1.6
        LEVEL_HIGH -> 2.5
        else -> 1.0
    }

    fun affectedHeadway(normalMinutes: Int?, level: Int): Int? {
        if (normalMinutes == null) return null
        if (impactSuspended(level)) return null
        return (normalMinutes * headwayMultiplier(level)).roundToInt().coerceAtLeast(1)
    }

    private fun impactSuspended(level: Int) = level >= LEVEL_HIGH

    /** 依據班次表（GTFS frequencies）計算正常班次間距（分鐘）。 */
    fun normalHeadwayMinutes(headways: List<HeadwayEntity>): Int? {
        if (headways.isEmpty()) return null
        val secs = headways.minOf { it.headwaySecs }
        return (secs / 60).coerceAtLeast(1)
    }

    /**
     * 對全域路線計算天氣影響，產出 WeatherRouteImpact 列表。
     * @param level 目前最高警告級別
     * @param headwaysByRoute 由班次表取得的正常班次間距
     */
    fun buildRouteImpacts(
        level: Int,
        routes: List<RouteEntity>,
        headwaysByRoute: Map<String, List<HeadwayEntity>>
    ): List<WeatherRouteImpact> {
        if (level == LEVEL_NONE) return emptyList()
        return routes.mapNotNull { route ->
            val operator = Operator.fromCode(route.operatorCode) ?: return@mapNotNull null
            val impact = impactFor(operator, level)
            if (impact == ServiceImpact.NORMAL) return@mapNotNull null
            val normal = normalHeadwayMinutes(headwaysByRoute[route.routeKey].orEmpty())
            WeatherRouteImpact(
                routeKey = route.routeKey,
                routeNo = route.routeNo,
                operator = operator,
                bound = route.bound,
                destTc = route.destTc,
                impact = impact,
                normalHeadwayMinutes = normal,
                affectedHeadwayMinutes = affectedHeadway(normal, level),
                diversionStops = emptyList(),
                note = noteFor(impact, operator, level),
                isEstimate = true
            )
        }
    }

    fun noteFor(impact: ServiceImpact, operator: Operator, level: Int): String {
        val levelText = when (level) {
            LEVEL_HIGH -> "九號／十號信號或黑色暴雨警告生效期間"
            LEVEL_MEDIUM -> "八號信號或紅色暴雨警告生效期間"
            LEVEL_LOW -> "一號／三號信號或黃色暴雨警告生效期間"
            else -> "天氣警告生效期間"
        }
        return when (impact) {
            ServiceImpact.SUSPENDED -> "$levelText，${operator.labelTc}一般會暫停服務。"
            ServiceImpact.PARTIAL_SUSPENDED -> "$levelText，${operator.labelTc}部分路線會暫停，其餘維持有限度服務。"
            ServiceImpact.LIMITED -> "$levelText，${operator.labelTc}一般會維持有限度服務並調整班次。"
            ServiceImpact.NORMAL -> "$levelText，${operator.labelTc}一般維持正常服務。"
        }
    }

    /**
     * 推算恢復時間表（三段式）。
     *
     * 以警告「改發較低級別／取消」的時間起算；若警告仍然生效，
     * 則以目前時間起算並標示為推算。
     */
    fun recoveryStages(
        level: Int,
        downgradeOrCancelAt: Instant?,
        affectedByOperator: Map<Operator, Int>
    ): List<RecoveryStage> {
        if (level == LEVEL_NONE) return emptyList()
        val base = downgradeOrCancelAt ?: Instant.now()
        val rail = affectedByOperator[Operator.MTR_HR] ?: 0
        val bus = listOf(Operator.KMB, Operator.CTB, Operator.NLB, Operator.MTR_BUS)
            .sumOf { affectedByOperator[it] ?: 0 }
        val minibus = affectedByOperator[Operator.GMB] ?: 0
        val lrt = affectedByOperator[Operator.MTR_LR] ?: 0

        return listOf(
            RecoveryStage(
                stage = 1,
                minutesAfterDowngrade = 30,
                estimatedAt = base.plus(30, ChronoUnit.MINUTES),
                actualAt = null,
                routeCount = rail,
                description = "港鐵重鐵（地下路段）優先恢復有限度服務，其後逐步加密班次。"
            ),
            RecoveryStage(
                stage = 2,
                minutesAfterDowngrade = 60,
                estimatedAt = base.plus(60, ChronoUnit.MINUTES),
                actualAt = null,
                routeCount = bus,
                description = "巴士主要路線陸續恢復，初段以較疏班次行駛，再逐步回復正常班次時間表。"
            ),
            RecoveryStage(
                stage = 3,
                minutesAfterDowngrade = 120,
                estimatedAt = base.plus(120, ChronoUnit.MINUTES),
                actualAt = null,
                routeCount = minibus + lrt,
                description = "專線小巴、輕鐵及個別受影響路線全面恢復，並回復正常班次時間表。"
            )
        )
    }

    /**
     * 把天氣影響轉成「今日變動」記錄，供「今日變動」分頁顯示。
     *
     * @param resumedRoutes 已從運輸署消息中偵測到「恢復」的路線號碼 → 實際恢復時間
     */
    fun toDailyChanges(
        date: String,
        events: List<WeatherEvent>,
        impacts: List<WeatherRouteImpact>,
        resumedRoutes: Map<String, Instant> = emptyMap()
    ): List<DailyChangeEntity> {
        if (impacts.isEmpty()) return emptyList()
        val now = System.currentTimeMillis()
        val topEvent = events.maxByOrNull { it.level }
        val warningCode = topEvent?.warningCode
        val resumedAll = topEvent?.cancelTime

        return impacts.map { impact ->
            val resumedAt = resumedRoutes[impact.routeNo] ?: resumedAll
            DailyChangeEntity(
                date = date,
                scope = ChangeScope.ROUTE.name,
                changeType = ChangeType.WEATHER.name,
                operatorCode = impact.operator.code,
                routeKey = impact.routeKey,
                routeNo = impact.routeNo,
                bound = impact.bound,
                stopKey = null,
                stopId = null,
                title = "天氣影響・${impact.operator.labelTc} ${impact.routeNo} 往${impact.destTc}（${impact.impact.labelTc}）",
                detail = buildString {
                    append(impact.note)
                    append("\n影響類別：${impact.impact.labelTc}")
                    if (impact.normalHeadwayMinutes != null) {
                        append("\n正常班次時間表：每 ${impact.normalHeadwayMinutes} 分鐘一班")
                    } else {
                        append("\n正常班次時間表：官方未提供班次資料")
                    }
                    if (impact.affectedHeadwayMinutes != null) {
                        append("\n受影響班次時間表：每 ${impact.affectedHeadwayMinutes} 分鐘一班（推算）")
                    } else {
                        append("\n受影響班次時間表：暫停服務")
                    }
                    if (impact.diversionStops.isNotEmpty()) {
                        append("\n受影響車站：${impact.diversionStops.joinToString("、")}")
                    }
                    resumedAt?.let {
                        append("\n實際恢復時間：${TimeUtil.formatDateTime(it)}")
                    } ?: append("\n預計恢復時間：請參考「天氣影響」分頁的推算恢復時間表")
                },
                affectedStopsJson = "[]",
                affectedStopIdsJson = "[]",
                effectiveFrom = topEvent?.issueTime?.toEpochMilli(),
                effectiveTo = topEvent?.cancelTime?.toEpochMilli(),
                resumedAt = resumedAt?.toEpochMilli(),
                weatherRelated = true,
                warningCode = warningCode,
                headwayMinutes = impact.affectedHeadwayMinutes,
                normalHeadwayMinutes = impact.normalHeadwayMinutes,
                source = ChangeSource.HKO.name,
                isEstimate = true,
                createdAt = now,
                dedupKey = "WEATHER|${impact.routeKey}|${warningCode ?: "NONE"}|$date"
            )
        }
    }
}
