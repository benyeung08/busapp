package hk.transit.eta.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Traffic
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import hk.transit.eta.R
import hk.transit.eta.core.di.AppContainer
import hk.transit.eta.ui.screens.ChangesScreen
import hk.transit.eta.ui.screens.HomeScreen
import hk.transit.eta.ui.screens.SettingsScreen
import hk.transit.eta.ui.screens.StopBoardScreen
import hk.transit.eta.ui.screens.WeatherScreen
import hk.transit.eta.ui.theme.HKTransitTheme
import hk.transit.eta.ui.viewmodel.AppViewModelFactory
import hk.transit.eta.ui.viewmodel.ChangesViewModel
import hk.transit.eta.ui.viewmodel.HomeViewModel
import hk.transit.eta.ui.viewmodel.SettingsViewModel
import hk.transit.eta.ui.viewmodel.StopBoardViewModel
import hk.transit.eta.ui.viewmodel.WeatherViewModel

class MainActivity : ComponentActivity() {

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* 忽略結果 */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        requestNotificationPermissionIfNeeded()

        setContent {
            HKTransitTheme {
                Surface {
                    AppNavigation(onStopSelected = { /* 由 NavHost 處理 */ })
                }
            }
        }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                this, Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }
}

sealed class Destination(
    val route: String,
    val labelRes: Int,
    val icon: ImageVector
) {
    data object Home : Destination("home", R.string.nav_home, Icons.Default.Home)
    data object Stop : Destination("stop/{stopKey}", R.string.nav_stop, Icons.Default.Traffic)
    data object Changes : Destination("changes", R.string.nav_changes, Icons.AutoMirrored.Filled.List)
    data object Weather : Destination("weather", R.string.nav_weather, Icons.Default.Cloud)
    data object Settings : Destination("settings", R.string.nav_settings, Icons.Default.Settings)

    companion object {
        fun home() = Home.route
        fun stop(stopKey: String) = "stop/${java.net.URLEncoder.encode(stopKey, "UTF-8")}"
    }
}

@Composable
fun AppNavigation(
    modifier: Modifier = Modifier,
    onStopSelected: (String) -> Unit = {}
) {
    val container = AppContainer.get(androidx.compose.ui.platform.LocalContext.current)
    val navController = rememberNavController()
    var showBottomBar by rememberSaveable { mutableStateOf(true) }

    Scaffold(
        modifier = modifier,
        bottomBar = {
            if (showBottomBar) {
                BottomNavigationBar(navController)
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = Destination.home(),
            modifier = Modifier.padding(padding)
        ) {
            composable(Destination.home()) {
                showBottomBar = true
                val vm: HomeViewModel = viewModel(factory = AppViewModelFactory(container))
                HomeScreen(
                    viewModel = vm,
                    onOpenStop = { key ->
                        navController.navigate(Destination.stop(key)) {
                            launchSingleTop = true
                        }
                    }
                )
            }

            composable(
                route = Destination.Stop.route,
                arguments = listOf(navArgument("stopKey") { type = NavType.StringType })
            ) { entry ->
                showBottomBar = false
                val raw = entry.arguments?.getString("stopKey").orEmpty()
                val stopKey = java.net.URLDecoder.decode(raw, "UTF-8")
                val vm: StopBoardViewModel = viewModel(
                    factory = AppViewModelFactory(container, stopKey)
                )
                StopBoardScreen(
                    viewModel = vm,
                    onBack = { navController.popBackStack() }
                )
            }

            composable(Destination.Changes.route) {
                showBottomBar = true
                val vm: ChangesViewModel = viewModel(factory = AppViewModelFactory(container))
                ChangesScreen(vm)
            }

            composable(Destination.Weather.route) {
                showBottomBar = true
                val vm: WeatherViewModel = viewModel(factory = AppViewModelFactory(container))
                WeatherScreen(vm)
            }

            composable(Destination.Settings.route) {
                showBottomBar = true
                val vm: SettingsViewModel = viewModel(factory = AppViewModelFactory(container))
                SettingsScreen(vm)
            }
        }
    }
}

@Composable
private fun BottomNavigationBar(navController: NavHostController) {
    val items = listOf(
        Destination.Home,
        Destination.Changes,
        Destination.Weather,
        Destination.Settings
    )
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route

    NavigationBar {
        items.forEach { destination ->
            NavigationBarItem(
                selected = currentRoute == destination.route,
                onClick = {
                    navController.navigate(destination.route) {
                        popUpTo(navController.graph.findStartDestination().id) {
                            saveState = true
                        }
                        launchSingleTop = true
                        restoreState = true
                    }
                },
                icon = { Icon(destination.icon, contentDescription = null) },
                label = { Text(stringResource(destination.labelRes)) }
            )
        }
    }
}
