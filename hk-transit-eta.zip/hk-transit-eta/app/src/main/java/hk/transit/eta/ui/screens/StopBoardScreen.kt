package hk.transit.eta.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import hk.transit.eta.R
import hk.transit.eta.core.util.TimeUtil
import hk.transit.eta.ui.components.StopBoardCard
import hk.transit.eta.ui.components.signalFor
import hk.transit.eta.ui.viewmodel.StopBoardViewModel

/**
 * 車站到站燈號畫面。
 *
 * 所有巴士與小巴車站均會在此顯示：
 *  起點站／中途站／終點站 三種燈號狀態與對應文案。
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StopBoardScreen(
    viewModel: StopBoardViewModel,
    onBack: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val boards by viewModel.boards.collectAsState()
    val stopName by viewModel.stopName.collectAsState()
    val loading by viewModel.loading.collectAsState()
    val error by viewModel.error.collectAsState()
    val updatedAt by viewModel.updatedAt.collectAsState()
    val flashEnabled by viewModel.flashEnabled.collectAsState()
    // 每秒重新運算燈號，令「即將到站／開出中」等狀態準時切換
    viewModel.tick.collectAsState()

    Scaffold(
        modifier = modifier,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = stopName.ifBlank { stringResource(R.string.stop_board_title) },
                        style = MaterialTheme.typography.titleMedium
                    )
                },
                navigationIcon = {
                    if (onBack != null) {
                        IconButton(onClick = onBack) {
                            Icon(
                                Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = stringResource(R.string.action_back)
                            )
                        }
                    }
                },
                actions = {
                    IconButton(onClick = viewModel::manualRefresh) {
                        Icon(Icons.Default.Refresh, contentDescription = stringResource(R.string.action_refresh))
                    }
                }
            )
        }
    ) { padding ->
        Box(modifier = Modifier.fillMaxSize().padding(padding)) {
            when {
                loading && boards.isEmpty() -> {
                    CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
                }
                boards.isEmpty() -> {
                    Text(
                        text = error ?: stringResource(R.string.stop_board_empty),
                        modifier = Modifier
                            .align(Alignment.Center)
                            .padding(24.dp),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                else -> {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(14.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        item {
                            Text(
                                text = stringResource(
                                    R.string.last_updated,
                                    TimeUtil.formatTime(TimeUtil.fromEpochMillis(updatedAt ?: 0L))
                                ),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        items(boards, key = { it.routeKey + it.bound }) { board ->
                            StopBoardCard(
                                board = board,
                                signal = signalFor(board),
                                flashEnabled = flashEnabled,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                        item {
                            Text(
                                text = stringResource(R.string.disclaimer_estimate),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}
