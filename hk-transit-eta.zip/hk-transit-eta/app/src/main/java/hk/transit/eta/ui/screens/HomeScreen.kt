package hk.transit.eta.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import hk.transit.eta.R
import hk.transit.eta.core.util.TimeUtil
import hk.transit.eta.domain.model.Mode
import hk.transit.eta.ui.components.RouteChip
import hk.transit.eta.ui.components.WeatherBanner
import hk.transit.eta.ui.viewmodel.HomeViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: HomeViewModel,
    onOpenStop: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val query by viewModel.query.collectAsState()
    val mode by viewModel.mode.collectAsState()
    val routes by viewModel.routes.collectAsState()
    val stops by viewModel.stops.collectAsState()
    val changeCount by viewModel.changeCount.collectAsState()
    val weather by viewModel.weatherSummary.collectAsState()
    val lastSync by viewModel.lastSync.collectAsState()
    val syncing by viewModel.syncing.collectAsState()
    val scope = rememberCoroutineScope()

    Scaffold(
        modifier = modifier,
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.app_name)) },
                actions = {
                    IconButton(onClick = { viewModel.syncNow { viewModel.refreshSummary() } }, enabled = !syncing) {
                        Icon(Icons.Default.Refresh, contentDescription = stringResource(R.string.action_refresh))
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                OutlinedTextField(
                    value = query,
                    onValueChange = viewModel::onQueryChange,
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    placeholder = { Text(stringResource(R.string.home_search_hint)) }
                )
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Mode.entries.forEach { item ->
                        FilterChip(
                            selected = mode == item,
                            onClick = { viewModel.onModeChange(item) },
                            label = { Text(item.labelTc) }
                        )
                    }
                }
            }
            item {
                Text(
                    text = stringResource(
                        R.string.home_summary,
                        changeCount,
                        weather?.affectedRouteCount ?: 0
                    ),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = stringResource(
                        R.string.settings_last_sync,
                        if (lastSync == 0L) stringResource(R.string.settings_never)
                        else TimeUtil.formatDateTime(TimeUtil.fromEpochMillis(lastSync))
                    ),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            weather?.activeEvents?.firstOrNull()?.let { event ->
                item {
                    WeatherBanner(
                        warningName = event.warningName,
                        affectedRouteCount = weather?.affectedRouteCount ?: 0
                    )
                }
            }
            if (routes.isNotEmpty()) {
                item {
                    Text(
                        text = "路線（${routes.size}）",
                        style = MaterialTheme.typography.titleSmall
                    )
                }
                items(routes.take(30), key = { it.routeKey }) { route ->
                    Card(
                        onClick = {
                            scope.launch {
                                val stopKey = viewModel.firstStopOf(route.routeKey)
                                if (stopKey != null) onOpenStop(stopKey)
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RouteChip(operator = route.operator, routeNo = route.routeNo)
                            Spacer(Modifier.padding(8.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(route.nameTc, style = MaterialTheme.typography.bodyMedium)
                                Text(
                                    route.operator.labelTc,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            if (route.hasRealtime) {
                                Surface(
                                    color = MaterialTheme.colorScheme.primaryContainer,
                                    shape = MaterialTheme.shapes.small
                                ) {
                                    Text(
                                        text = stringResource(R.string.signal_realtime_badge),
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                        style = MaterialTheme.typography.labelMedium
                                    )
                                }
                            }
                        }
                    }
                }
            }
            if (stops.isNotEmpty()) {
                item {
                    Spacer(Modifier.height(6.dp))
                    Text(text = "車站（${stops.size}）", style = MaterialTheme.typography.titleSmall)
                }
                items(stops.take(30), key = { it.stopKey }) { stop ->
                    Card(onClick = { onOpenStop(stop.stopKey) }, modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(stop.nameTc, style = MaterialTheme.typography.titleSmall)
                            Text(
                                "${stop.operator.labelTc}・站號 ${stop.stopId}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
            item {
                Spacer(Modifier.height(16.dp))
                Text(
                    text = stringResource(R.string.disclaimer_official),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
