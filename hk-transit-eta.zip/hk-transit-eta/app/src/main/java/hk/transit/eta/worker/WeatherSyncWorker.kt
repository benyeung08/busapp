package hk.transit.eta.worker

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import hk.transit.eta.core.di.AppContainer
import hk.transit.eta.core.util.TimeUtil

/**
 * 每 15 分鐘抓取天文台天氣警告，
 * 並據此推算當日受影響的路線、班次時間表與恢復時間表。
 */
class WeatherSyncWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val container = AppContainer.get(applicationContext)
        return try {
            container.weatherRepository.sync(TimeUtil.today())
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }
}
