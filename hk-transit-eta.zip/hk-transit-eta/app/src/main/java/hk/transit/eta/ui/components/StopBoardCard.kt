package hk.transit.eta.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import hk.transit.eta.domain.SignalLight
import hk.transit.eta.domain.SignalLightEngine
import hk.transit.eta.domain.model.Operator
import hk.transit.eta.domain.model.StopEtaBoard
import hk.transit.eta.ui.theme.BrandBlue

/**
 * 車站內「單一路線」的到站卡片：左邊燈號、右邊路線與目的地。
 */
@Composable
fun StopBoardCard(
    board: StopEtaBoard,
    signal: SignalLight,
    flashEnabled: Boolean,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        onClick = { onClick?.invoke() }
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                RouteChip(operator = board.operator, routeNo = board.routeNo)
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "往${board.destTc}",
                        style = MaterialTheme.typography.titleSmall
                    )
                    Text(
                        text = board.operator.labelTc,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                SourceBadge(isEstimate = signal.isEstimate)
            }

            Spacer(Modifier.height(10.dp))
            StopRoleBadge(role = board.stopRole, stopSeq = board.stopSeq, totalStops = board.totalStops)

            Spacer(Modifier.height(12.dp))
            EtaSignalLight(
                signal = signal,
                role = board.stopRole,
                flashEnabled = flashEnabled
            )

            board.entries.take(3).forEachIndexed { index, entry ->
                if (index == 0) return@forEachIndexed
                Text(
                    text = "第 ${index + 1} 班：${entry.minutes ?: "—"} 分鐘（${entry.destTc}）",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (board.entries.size > 1 && board.stopRole != hk.transit.eta.domain.model.StopRole.TERMINUS) {
                Spacer(Modifier.height(4.dp))
            }
        }
    }
}

@Composable
fun RouteChip(operator: Operator, routeNo: String) {
    androidx.compose.material3.Surface(
        color = BrandBlue,
        shape = MaterialTheme.shapes.small
    ) {
        Text(
            text = routeNo,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
            style = MaterialTheme.typography.titleMedium,
            color = androidx.compose.ui.graphics.Color.White
        )
    }
}

/** 由 board 直接運算燈號（供列表預覽使用）。 */
fun signalFor(board: StopEtaBoard): SignalLight = SignalLightEngine.evaluate(board)
