package hk.transit.eta.domain

import hk.transit.eta.domain.model.ChangeType
import hk.transit.eta.domain.model.Operator

/**
 * 將運輸署「特別交通消息」的文字分類為具體變動類型。
 *
 * 現時政府並未提供「路線改動」的結構化開放數據，
 * 故此分類屬關鍵字推導，介面上會標示來源為「運輸署特別交通消息」。
 */
object NewsClassifier {

    data class Classification(
        val changeTypes: List<ChangeType>,
        val routeNumbers: List<String>,
        val stopNames: List<String>,
        val weatherRelated: Boolean,
        val restoration: Boolean,
        val matchedKeywords: List<String>
    )

    private val DIVERSION_KEYS = listOf(
        "改道", "改行", "改經", "繞道", "臨時改", "改為途經", "不經", "遷移", "巴士站遷移", "站點臨時",
        "diversion", "diverted", "re-route", "reroute"
    )
    private val CANCEL_KEYS = listOf(
        "取消", "停駛", "暫停服務", "暫停", "停開", "停止服務", "不設", "暫緩", "縮減",
        "cancel", "cancelled", "suspended", "suspension"
    )
    private val ADDED_KEYS = listOf(
        "新增", "加開", "增設", "開辦", "新路線", "增加班次", "加密班次", "投入服務",
        "new route", "additional", "commence", "launched"
    )
    private val RESTORE_KEYS = listOf(
        "恢復", "回復", "重開", "復常", "回復正常", "恢復正常", "重新開放", "解封",
        "resume", "restored", "reopen", "back to normal"
    )
    private val WEATHER_KEYS = listOf(
        "八號", "九號", "十號", "三號", "一號", "風球", "烈風", "颶風", "熱帶氣旋", "信號",
        "黑色暴雨", "紅色暴雨", "黃色暴雨", "暴雨", "雷暴", "山泥傾瀉", "水浸", "塌樹",
        "typhoon", "rainstorm", "black rain", "red rain", "amber rain"
    )
    private val RAIL_KEYS = listOf("港鐵", "鐵路", "輕鐵", "重鐵", "東鐵", "屯馬", "荃灣", "觀塘", "港島", "將軍澳", "東涌", "南港島", "機場快")
    private val MINIBUS_KEYS = listOf("小巴", "專線小巴", "專綫小巴", "minibus")

    private val ROUTE_PATTERNS = listOf(
        Regex("""(?:路線|route|Route|ROUTE)\s*[:：]?\s*([0-9]{1,3}[A-Za-z]?)"""),
        Regex("""([0-9]{1,3}[A-Za-z])\s*(?:號|路線|線)\s*(?:巴士|小巴)?"""),
        Regex("""(?:K|N|A|B|S|NR|X)\s?([0-9]{1,3}[A-Za-z]?)""")
    )

    private val STOP_PATTERNS = listOf(
        Regex("""「([^」]{2,20}站)」"""),
        Regex("""([\u4e00-\u9fa5A-Za-z0-9]{2,18}站)(?:之|，|,|。|；|;)"""),
        Regex("""(?:巴士站|小巴站|站)\s*[：:]?\s*([\u4e00-\u9fa5]{2,18})""")
    )

    fun classify(text: String): Classification {
        if (text.isBlank()) return Classification(emptyList(), emptyList(), emptyList(), false, false, emptyList())

        val types = mutableListOf<ChangeType>()
        val matched = mutableListOf<String>()

        if (matchesAny(text, DIVERSION_KEYS, matched)) types += ChangeType.DIVERSION
        if (matchesAny(text, CANCEL_KEYS, matched)) types += ChangeType.REMOVED
        if (matchesAny(text, ADDED_KEYS, matched)) types += ChangeType.ADDED
        val restoration = matchesAny(text, RESTORE_KEYS, matched)
        if (restoration) types += ChangeType.RESTORED
        val weatherRelated = matchesAny(text, WEATHER_KEYS, matched)

        if (types.isEmpty() && (weatherRelated || restoration)) {
            types += ChangeType.MODIFIED
        }

        return Classification(
            changeTypes = types.distinct(),
            routeNumbers = extractRoutes(text),
            stopNames = extractStops(text),
            weatherRelated = weatherRelated,
            restoration = restoration,
            matchedKeywords = matched.distinct()
        )
    }

    /** 從消息文字粗略判斷涉及的營辦商類型。 */
    fun inferOperators(text: String): Set<Operator> {
        val result = mutableSetOf<Operator>()
        if (matchesAny(text, MINIBUS_KEYS)) result += Operator.GMB
        if (matchesAny(text, RAIL_KEYS)) result += Operator.MTR_HR
        if (text.contains("輕鐵")) result += Operator.MTR_LR
        return result
    }

    private fun matchesAny(text: String, keys: List<String>, sink: MutableList<String>? = null): Boolean {
        var hit = false
        for (k in keys) {
            if (text.contains(k, ignoreCase = true)) {
                hit = true
                sink?.add(k)
            }
        }
        return hit
    }

    private fun extractRoutes(text: String): List<String> {
        val out = LinkedHashSet<String>()
        for (p in ROUTE_PATTERNS) {
            p.findAll(text).forEach { m ->
                val v = m.groupValues.getOrNull(1)?.trim()
                if (!v.isNullOrBlank() && v.length in 1..5) out += v.uppercase()
            }
        }
        return out.toList()
    }

    private fun extractStops(text: String): List<String> {
        val out = LinkedHashSet<String>()
        for (p in STOP_PATTERNS) {
            p.findAll(text).forEach { m ->
                val v = m.groupValues.getOrNull(1)?.trim()
                if (!v.isNullOrBlank() && v.length in 2..20) out += v
            }
        }
        return out.toList()
    }
}
