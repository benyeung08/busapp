package hk.transit.eta.worker

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import hk.transit.eta.core.di.AppContainer
import hk.transit.eta.core.util.TimeUtil

/** 每 15 分鐘抓取運輸署特別交通消息，偵測當日臨時改道／取消／恢復。 */
class NewsSyncWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val container = AppContainer.get(applicationContext)
        return try {
            val result = container.newsRepository.sync(TimeUtil.today())
            container.weatherRepository.applyActualRecovery(TimeUtil.today(), result.resumedRoutes)
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }
}
