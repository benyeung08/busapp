package hk.transit.eta.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import hk.transit.eta.core.di.AppContainer

/**
 * 極簡 ViewModel 工廠：把 AppContainer 注入各 ViewModel。
 * @param stopKey 只有 StopBoardViewModel 需要，用於指定要顯示的車站
 */
@Suppress("UNCHECKED_CAST")
class AppViewModelFactory(
    private val container: AppContainer,
    private val stopKey: String? = null
) : ViewModelProvider.Factory {

    override fun <T : ViewModel> create(modelClass: Class<T>): T = when {
        modelClass.isAssignableFrom(HomeViewModel::class.java) ->
            HomeViewModel(container) as T

        modelClass.isAssignableFrom(StopBoardViewModel::class.java) ->
            StopBoardViewModel(container, stopKey) as T

        modelClass.isAssignableFrom(ChangesViewModel::class.java) ->
            ChangesViewModel(container) as T

        modelClass.isAssignableFrom(WeatherViewModel::class.java) ->
            WeatherViewModel(container) as T

        modelClass.isAssignableFrom(SettingsViewModel::class.java) ->
            SettingsViewModel(container) as T

        else -> throw IllegalArgumentException("Unknown ViewModel: ${modelClass.name}")
    }
}
