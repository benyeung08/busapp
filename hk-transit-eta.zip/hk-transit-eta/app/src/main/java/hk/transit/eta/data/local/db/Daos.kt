package hk.transit.eta.data.local.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

/**
 * SQLite 的變數上限（999）。分批寫入時每列佔用的變數數不同，
 * 各 DAO 會依實體欄位數量自行縮減批次大小。
 */
internal const val SQLITE_MAX_VARIABLES = 900

@Dao
interface RouteDao {

    @Upsert
    suspend fun upsertAll(routes: List<RouteEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(routes: List<RouteEntity>)

    @Query("DELETE FROM route WHERE operatorCode = :operatorCode")
    suspend fun deleteByOperator(operatorCode: String)

    @Query("SELECT * FROM route WHERE routeKey = :routeKey")
    suspend fun get(routeKey: String): RouteEntity?

    @Query("SELECT * FROM route WHERE routeKey IN (:keys)")
    suspend fun getByKeys(keys: List<String>): List<RouteEntity>

    @Query("SELECT * FROM route WHERE operatorCode = :operatorCode ORDER BY routeNo")
    fun observeByOperator(operatorCode: String): Flow<List<RouteEntity>>

    /**
     * 依營辦商過濾的搜尋。
     *
     * 必須把 operatorCode 放進 SQL：舊寫法是在 Kotlin 端先 `LIMIT` 再 filter，
     * 結果取回的 N 筆幾乎全屬九巴，導致小巴／輕鐵等分頁永遠是空的。
     */
    @Query(
        """
        SELECT * FROM route
        WHERE operatorCode IN (:operatorCodes)
          AND (routeNo LIKE :q OR nameTc LIKE :q OR originTc LIKE :q OR destTc LIKE :q)
        ORDER BY routeNo LIMIT :limit
        """
    )
    suspend fun search(q: String, operatorCodes: Collection<String>, limit: Int): List<RouteEntity>

    /** 指定營辦商的全部路線（供同步與批次運算）。 */
    @Query("SELECT * FROM route WHERE operatorCode IN (:operatorCodes) ORDER BY routeNo")
    suspend fun byOperators(operatorCodes: Collection<String>): List<RouteEntity>

    /** 使用者可見的營辦商路線（排除純目錄命名空間），並限制筆數以免一次載入過量。 */
    @Query(
        """
        SELECT * FROM route
        WHERE operatorCode IN (:operatorCodes)
        ORDER BY routeNo LIMIT :limit
        """
    )
    suspend fun visible(operatorCodes: Collection<String>, limit: Int): List<RouteEntity>

    @Query("SELECT COUNT(*) FROM route")
    suspend fun count(): Int

    /** 整批重建目錄前先清空（由 GitHub 資料集匯入時使用）。 */
    @Query("DELETE FROM route")
    suspend fun deleteAll()

    @Transaction
    suspend fun replaceOperator(operatorCode: String, routes: List<RouteEntity>) {
        deleteByOperator(operatorCode)
        upsertAllInTx(routes)
    }

    /** 大量寫入時包在單一交易內，避免每列都開一次 transaction。 */
    @Transaction
    suspend fun upsertAllInTx(routes: List<RouteEntity>) {
        routes.chunked(SQLITE_MAX_VARIABLES).forEach { upsertAll(it) }
    }
}

@Dao
interface StopDao {

    @Upsert
    suspend fun upsertAll(stops: List<StopEntity>)

    @Query("DELETE FROM stop WHERE operatorCode = :operatorCode")
    suspend fun deleteByOperator(operatorCode: String)

    @Query("SELECT * FROM stop WHERE stopKey = :stopKey")
    suspend fun get(stopKey: String): StopEntity?

    @Query("SELECT * FROM stop WHERE stopKey IN (:keys)")
    suspend fun getByKeys(keys: List<String>): List<StopEntity>

    /** 依營辦商過濾的搜尋（同樣必須在 SQL 端過濾，理由見 RouteDao.search）。 */
    @Query(
        """
        SELECT * FROM stop
        WHERE operatorCode IN (:operatorCodes)
          AND (nameTc LIKE :q OR nameEn LIKE :q OR stopId LIKE :q)
        ORDER BY nameTc LIMIT :limit
        """
    )
    suspend fun search(q: String, operatorCodes: Collection<String>, limit: Int): List<StopEntity>

    @Query("SELECT * FROM stop WHERE operatorCode = :operatorCode")
    suspend fun byOperator(operatorCode: String): List<StopEntity>

    @Query("SELECT COUNT(*) FROM stop")
    suspend fun count(): Int

    @Query("DELETE FROM stop")
    suspend fun deleteAll()

    @Transaction
    suspend fun replaceOperator(operatorCode: String, stops: List<StopEntity>) {
        deleteByOperator(operatorCode)
        upsertAllInTx(stops)
    }

    @Transaction
    suspend fun upsertAllInTx(stops: List<StopEntity>) {
        stops.chunked(SQLITE_MAX_VARIABLES).forEach { upsertAll(it) }
    }
}

@Dao
interface RouteStopDao {

    @Upsert
    suspend fun upsertAll(items: List<RouteStopEntity>)

    @Query("DELETE FROM route_stop WHERE routeKey = :routeKey")
    suspend fun deleteByRoute(routeKey: String)

    @Query("SELECT * FROM route_stop WHERE routeKey = :routeKey ORDER BY stopSeq")
    suspend fun ofRoute(routeKey: String): List<RouteStopEntity>

    @Query("SELECT * FROM route_stop WHERE stopKey = :stopKey")
    suspend fun ofStop(stopKey: String): List<RouteStopEntity>

    /** ⚠️ 僅供匯出／除錯：全表資料量可達十萬列，請勿在一般流程呼叫。 */
    @Query("SELECT * FROM route_stop ORDER BY routeKey, stopSeq")
    suspend fun all(): List<RouteStopEntity>

    @Query("DELETE FROM route_stop WHERE routeKey LIKE :prefix || '%'")
    suspend fun deleteByPrefix(prefix: String)

    @Query("SELECT COUNT(*) FROM route_stop WHERE routeKey = :routeKey")
    suspend fun countOfRoute(routeKey: String): Int

    /** 一次取得大量路線的車站數，取代逐條 countOfRoute 的 N+1 查詢。 */
    @Query(
        """
        SELECT routeKey, COUNT(*) AS cnt FROM route_stop
        WHERE routeKey IN (:routeKeys) GROUP BY routeKey
        """
    )
    suspend fun countOfRoutes(routeKeys: Collection<String>): List<RouteKeyCount>

    /** 一次取得大量路線的站序指紋，避免把全表讀進記憶體。 */
    @Query(
        """
        SELECT routeKey, stopSeq, stopId FROM route_stop
        WHERE routeKey IN (:routeKeys) ORDER BY routeKey, stopSeq
        """
    )
    suspend fun sequencesOf(routeKeys: Collection<String>): List<RouteStopTuple>

    @Query("SELECT COUNT(*) FROM route_stop")
    suspend fun countAll(): Int

    @Query("DELETE FROM route_stop")
    suspend fun deleteAll()

    @Transaction
    suspend fun replaceRoute(routeKey: String, items: List<RouteStopEntity>) {
        deleteByRoute(routeKey)
        upsertAllInTx(items)
    }

    @Transaction
    suspend fun upsertAllInTx(items: List<RouteStopEntity>) {
        items.chunked(SQLITE_MAX_VARIABLES).forEach { upsertAll(it) }
    }
}

/** GROUP BY 的輸出列：路線 → 車站數。 */
data class RouteKeyCount(
    @androidx.room.ColumnInfo(name = "routeKey") val routeKey: String,
    @androidx.room.ColumnInfo(name = "cnt") val count: Int
)

/** 只取站序與站號的輕量列，用於計算指紋時節省記憶體。 */
data class RouteStopTuple(
    val routeKey: String,
    val stopSeq: Int,
    val stopId: String
)

@Dao
interface MtrBusStopMapDao {

    @Upsert
    suspend fun upsertAll(items: List<MtrBusStopMapEntity>)

    @Query("SELECT * FROM mtr_bus_stop_map WHERE routeKey = :routeKey ORDER BY stopSeq")
    suspend fun ofRoute(routeKey: String): List<MtrBusStopMapEntity>

    /** 一次取回多條路線的對照表，避免在迴圈內逐條查詢（N+1）。 */
    @Query("SELECT * FROM mtr_bus_stop_map WHERE routeKey IN (:routeKeys) ORDER BY routeKey, stopSeq")
    suspend fun ofRoutes(routeKeys: Collection<String>): List<MtrBusStopMapEntity>

    @Query("DELETE FROM mtr_bus_stop_map WHERE routeKey = :routeKey")
    suspend fun deleteByRoute(routeKey: String)

    @Query("SELECT COUNT(*) FROM mtr_bus_stop_map")
    suspend fun count(): Int

    @Transaction
    suspend fun replaceRoute(routeKey: String, items: List<MtrBusStopMapEntity>) {
        deleteByRoute(routeKey)
        items.chunked(SQLITE_MAX_VARIABLES / 4).forEach { upsertAll(it) }
    }

    @Query("DELETE FROM mtr_bus_stop_map")
    suspend fun deleteAll()

    @Transaction
    suspend fun upsertAllInTx(items: List<MtrBusStopMapEntity>) {
        items.chunked(SQLITE_MAX_VARIABLES / 4).forEach { upsertAll(it) }
    }
}

@Dao
interface SnapshotDao {

    @Transaction
    suspend fun upsertRoutes(items: List<RouteSnapshotEntity>) {
        items.chunked(SQLITE_MAX_VARIABLES / 8).forEach { upsertRouteChunk(it) }
    }

    @Upsert
    suspend fun upsertRouteChunk(items: List<RouteSnapshotEntity>)

    @Transaction
    suspend fun upsertStops(items: List<StopSnapshotEntity>) {
        items.chunked(SQLITE_MAX_VARIABLES / 8).forEach { upsertStopChunk(it) }
    }

    @Upsert
    suspend fun upsertStopChunk(items: List<StopSnapshotEntity>)

    @Query("SELECT * FROM route_snapshot")
    suspend fun allRoutes(): List<RouteSnapshotEntity>

    @Query("SELECT * FROM stop_snapshot")
    suspend fun allStops(): List<StopSnapshotEntity>

    @Query("SELECT * FROM route_snapshot WHERE routeKey = :routeKey")
    suspend fun route(routeKey: String): RouteSnapshotEntity?

    @Query("SELECT COUNT(*) FROM route_snapshot")
    suspend fun routeCount(): Int

    @Query("SELECT COUNT(*) FROM stop_snapshot")
    suspend fun stopCount(): Int

    @Query("DELETE FROM route_snapshot")
    suspend fun clearRoutes()

    @Query("DELETE FROM stop_snapshot")
    suspend fun clearStops()
}

@Dao
interface DailyChangeDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertChunk(items: List<DailyChangeEntity>)

    /** 批次寫入並包在交易內，避免上千筆逐列提交。 */
    @Transaction
    suspend fun insertAll(items: List<DailyChangeEntity>) {
        items.chunked(SQLITE_MAX_VARIABLES / 22).forEach { insertChunk(it) }
    }

    @Update
    suspend fun updateChunk(items: List<DailyChangeEntity>)

    @Transaction
    suspend fun updateAll(items: List<DailyChangeEntity>) {
        items.chunked(SQLITE_MAX_VARIABLES / 22).forEach { updateChunk(it) }
    }

    @Query("SELECT * FROM daily_change WHERE date = :date ORDER BY weatherRelated DESC, id DESC")
    fun observeByDate(date: String): Flow<List<DailyChangeEntity>>

    @Query("SELECT * FROM daily_change WHERE date = :date ORDER BY weatherRelated DESC, id DESC")
    suspend fun byDate(date: String): List<DailyChangeEntity>

    @Query("SELECT * FROM daily_change WHERE date = :date AND changeType = :changeType")
    suspend fun byDateAndType(date: String, changeType: String): List<DailyChangeEntity>

    @Query("SELECT * FROM daily_change WHERE date = :date AND weatherRelated = 1")
    suspend fun weatherByDate(date: String): List<DailyChangeEntity>

    @Query("SELECT COUNT(*) FROM daily_change WHERE date = :date")
    suspend fun countByDate(date: String): Int

    @Query("SELECT * FROM daily_change WHERE date = :date AND dedupKey IN (:keys)")
    suspend fun existing(date: String, keys: List<String>): List<DailyChangeEntity>

    @Query("DELETE FROM daily_change WHERE date = :date")
    suspend fun clearDate(date: String)

    @Query("DELETE FROM daily_change WHERE date < :date")
    suspend fun clearBefore(date: String)

    @Query("UPDATE daily_change SET resumedAt = :resumedAt WHERE date = :date AND weatherRelated = 1 AND resumedAt IS NULL")
    suspend fun markAllResumed(date: String, resumedAt: Long)
}

@Dao
interface WeatherEventDao {

    @Upsert
    suspend fun upsertAll(items: List<WeatherEventEntity>)

    @Query("SELECT * FROM weather_event WHERE date = :date ORDER BY level DESC, issueTime DESC")
    fun observeByDate(date: String): Flow<List<WeatherEventEntity>>

    @Query("SELECT * FROM weather_event WHERE date = :date ORDER BY level DESC, issueTime DESC")
    suspend fun byDate(date: String): List<WeatherEventEntity>

    @Query("SELECT * FROM weather_event WHERE key = :key")
    suspend fun get(key: String): WeatherEventEntity?

    @Query("DELETE FROM weather_event WHERE date < :date")
    suspend fun clearBefore(date: String)
}

@Dao
interface HeadwayDao {

    @Upsert
    suspend fun upsertAll(items: List<HeadwayEntity>)

    @Query("SELECT * FROM headway WHERE routeKey = :routeKey ORDER BY startTime")
    suspend fun ofRoute(routeKey: String): List<HeadwayEntity>

    @Query("SELECT * FROM headway WHERE routeNo = :routeNo AND operatorCode = :operatorCode")
    suspend fun ofRouteNo(routeNo: String, operatorCode: String): List<HeadwayEntity>

    /** 一次取回所有班次資料，避免在迴圈內逐條查詢（N+1）。 */
    @Query("SELECT * FROM headway")
    suspend fun all(): List<HeadwayEntity>

    @Query("SELECT COUNT(*) FROM headway")
    suspend fun count(): Int

    @Query("DELETE FROM headway")
    suspend fun clear()

    /** 整表重建：先清空再批次寫入，全部包在同一個交易內。 */
    @Transaction
    suspend fun replaceAll(items: List<HeadwayEntity>) {
        clear()
        items.chunked(SQLITE_MAX_VARIABLES / 8).forEach { upsertAll(it) }
    }
}

@Dao
interface SyncLogDao {

    @Upsert
    suspend fun upsert(item: SyncLogEntity)

    @Query("SELECT * FROM sync_log WHERE kind = :kind")
    suspend fun get(kind: String): SyncLogEntity?

    @Query("SELECT * FROM sync_log")
    fun observeAll(): Flow<List<SyncLogEntity>>
}
