package hk.transit.eta.data.repository

import hk.transit.eta.BuildConfig
import hk.transit.eta.core.util.TimeUtil
import hk.transit.eta.data.local.UserPreferences
import hk.transit.eta.data.local.db.AppDatabase
import hk.transit.eta.data.local.db.DailyChangeEntity
import hk.transit.eta.data.local.db.MtrBusStopMapEntity
import hk.transit.eta.data.local.db.RouteEntity
import hk.transit.eta.data.local.db.RouteStopEntity
import hk.transit.eta.data.local.db.StopEntity
import hk.transit.eta.data.local.db.WeatherEventEntity
import hk.transit.eta.data.remote.NetworkClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * 從 GitHub 下載由 Actions 預先產生好的資料集，並匯入本機資料庫。
 *
 * 為什麼改由 GitHub 供應目錄資料
 * ------------------------------
 * 1. 每日變動要比對「昨日的快照」。放在裝置上會因清除資料、重裝或換機而遺失，
 *    導致變動偵測失效；放在 git 裡則有完整歷史。
 * 2. 港鐵巴士的 busStopId 對照表必須逐條路線呼叫政府 API 才能建立，
 *    在 CI 做完可省下裝置的流量與時間。
 * 3. 裝置只需下載處理好的 JSON，不必在手機上解析數 MB 的 CSV——
 *    舊做法在慢速網絡下經常逾時，是同步失敗的主因之一。
 *
 * 即時到站（ETA）仍然由 App 直接呼叫政府 API，不經 GitHub：
 * 到站預報每 10 秒至 1 分鐘就變動，放進靜態檔只會得到過期資料。
 *
 * 若 GitHub 無法連線，會丟出例外，由 [CatalogueRepository] 退回直接下載政府資料。
 */
class DatasetRepository(
    private val database: AppDatabase,
    private val prefs: UserPreferences
) {

    private val api = NetworkClient.dataset()

    data class SyncResult(
        val version: Long,
        val routeCount: Int,
        val stopCount: Int,
        val routeStopCount: Int,
        val changeCount: Int,
        val mtrBusMapCount: Int
    )

    /** 是否已設定資料集來源倉庫（未設定時應直接退回本地下載）。 */
    fun isConfigured(): Boolean {
        val owner = BuildConfig.DATASET_OWNER.trim()
        return owner.isNotBlank() &&
            !owner.equals("YOUR_GITHUB_USERNAME", ignoreCase = true) &&
            BuildConfig.DATASET_REPO.isNotBlank()
    }

    private fun urlOf(file: String): String {
        val owner = BuildConfig.DATASET_OWNER.trim()
        val repo = BuildConfig.DATASET_REPO.trim()
        val branch = BuildConfig.DATASET_BRANCH.trim().ifBlank { "main" }
        return "https://raw.githubusercontent.com/$owner/$repo/$branch/data/$file"
    }

    /**
     * 下載並匯入資料集。
     *
     * @param force true 時忽略版本檢查，一律重新下載（設定頁的「立即更新」用）
     * @throws Exception 下載或解析失敗時丟出，讓呼叫端退回其他來源
     */
    suspend fun sync(force: Boolean = false): SyncResult = withContext(Dispatchers.IO) {
        val manifest = api.manifest(urlOf("manifest.json"))
        if (manifest.version <= 0) {
            throw IllegalStateException("資料集 manifest 缺少版本資訊")
        }
        if (!force && manifest.version == prefs.lastDatasetVersion && database.routeDao().count() > 0) {
            // 已是最新版本且本機有資料，無需重複下載
            return@withContext SyncResult(
                version = manifest.version,
                routeCount = database.routeDao().count(),
                stopCount = database.stopDao().count(),
                routeStopCount = 0,
                changeCount = 0,
                mtrBusMapCount = 0
            )
        }

        val routes = api.routes(urlOf("routes.json"))
        val stops = api.stops(urlOf("stops.json"))
        val routeStops = api.routeStops(urlOf("route_stops.json"))
        val mtrMap = api.mtrBusMap(urlOf("mtr_bus_map.json"))
        val changes = api.changes(urlOf("changes.json"))

        val now = System.currentTimeMillis()

        // 路線
        val routeEntities = routes.map { r ->
            RouteEntity(
                routeKey = r.routeKey,
                operatorCode = r.operatorCode,
                companyCode = r.companyCode,
                routeNo = r.routeNo,
                bound = r.bound,
                serviceType = r.serviceType,
                nameTc = r.nameTc,
                nameEn = r.nameEn,
                originTc = r.originTc,
                originEn = r.originEn,
                destTc = r.destTc,
                destEn = r.destEn,
                fullFare = r.fullFare ?: 0.0,
                journeyTime = r.journeyTime,
                specialType = r.specialType,
                serviceMode = r.serviceMode,
                hasRealtime = r.hasRealtime,
                lastUpdate = now
            )
        }

        // 車站
        val stopEntities = stops.map { s ->
            StopEntity(
                stopKey = s.stopKey,
                operatorCode = s.operatorCode,
                stopId = s.stopId,
                nameTc = s.nameTc,
                nameEn = s.nameEn,
                lat = s.lat ?: 0.0,
                lng = s.lng ?: 0.0,
                lastUpdate = now
            )
        }

        // 車站索引 → 站名，供還原站序三元組使用（後端為節省體積只傳索引）
        val stopNames = stops.associate { it.stopKey to (it.nameTc to it.nameEn) }

        // 站序：三元組 [routeIdx, stopIdx, seq]
        val routeStopEntities = routeStops.mapNotNull { t ->
            if (t.size < 3) return@mapNotNull null
            val route = routes.getOrNull(t[0]) ?: return@mapNotNull null
            val stop = stops.getOrNull(t[1]) ?: return@mapNotNull null
            RouteStopEntity(
                routeKey = route.routeKey,
                stopSeq = t[2],
                stopKey = stop.stopKey,
                stopId = stop.stopId,
                stopNameTc = stopNames[stop.stopKey]?.first ?: "",
                stopNameEn = stopNames[stop.stopKey]?.second ?: "",
                lat = stop.lat ?: 0.0,
                lng = stop.lng ?: 0.0
            )
        }

        val mapEntities = mtrMap.map { m ->
            MtrBusStopMapEntity(
                routeKey = m.routeKey,
                stopSeq = m.stopSeq,
                busStopId = m.busStopId,
                routeName = m.routeName,
                mappedAt = now
            )
        }

        val changeEntities = changes.map { c ->
            DailyChangeEntity(
                date = c.date.ifBlank { TimeUtil.today() },
                scope = c.scope,
                changeType = c.changeType,
                operatorCode = c.operatorCode,
                routeKey = c.routeKey,
                routeNo = c.routeNo,
                bound = c.bound,
                stopKey = c.stopKey,
                stopId = c.stopId,
                title = c.title,
                detail = c.detail,
                affectedStopsJson = toJsonArray(c.affectedStops),
                affectedStopIdsJson = toJsonArray(c.affectedStopIds),
                effectiveFrom = null,
                effectiveTo = null,
                resumedAt = null,
                weatherRelated = c.weatherRelated,
                warningCode = null,
                headwayMinutes = null,
                normalHeadwayMinutes = null,
                source = c.source,
                isEstimate = c.isEstimate,
                createdAt = now,
                dedupKey = c.dedupKey
            )
        }

        // 整批寫入：先清掉舊的目錄資料，避免已停辦路線的殘留站序留在庫中
        database.routeDao().deleteAll()
        database.stopDao().deleteAll()
        database.routeStopDao().deleteAll()
        database.mtrBusStopMapDao().deleteAll()
        database.routeDao().upsertAllInTx(routeEntities)
        database.stopDao().upsertAllInTx(stopEntities)
        database.routeStopDao().upsertAllInTx(routeStopEntities)
        database.mtrBusStopMapDao().upsertAllInTx(mapEntities)

        // 變動記錄：只清掉「同一天、同一來源」的舊記錄，保留其他來源
        if (changeEntities.isNotEmpty()) {
            val date = changeEntities.first().date
            database.dailyChangeDao().clearDate(date)
            database.dailyChangeDao().insertAll(changeEntities)
        }

        // 天氣事件（level = 0 代表無警告）
        runCatching {
            val w = api.weather(urlOf("weather.json"))
            val events = w.events.orEmpty().map { e ->
                WeatherEventEntity(
                    key = e.key,
                    date = e.date.ifBlank { TimeUtil.today() },
                    warningCode = e.warningCode,
                    warningName = e.warningName,
                    actionCode = e.actionCode,
                    level = e.level,
                    issueTime = now,
                    updateTime = now,
                    cancelTime = null,
                    detail = e.detail
                )
            }
            database.weatherEventDao().upsertAll(events)
        }

        // 記下 NLB 的路線號 → routeId 對應，供即時到站查詢使用
        manifest.nlbRouteIds?.let { prefs.nlbRouteIds = it }

        prefs.lastDatasetVersion = manifest.version

        SyncResult(
            version = manifest.version,
            routeCount = routeEntities.size,
            stopCount = stopEntities.size,
            routeStopCount = routeStopEntities.size,
            changeCount = changeEntities.size,
            mtrBusMapCount = mapEntities.size
        )
    }

    /**
     * 把字串清單序列化成 JSON 陣列。
     *
     * 刻意不在字串模板內再嵌字串常值（例如 `"\"${it.replace("\"", "")}\""`）：
     * 那種寫法雖然合法，但巢狀引號難讀，也容易讓工具誤判。
     * 此處改用變數帶出引號，邏輯相同但一眼可辨。
     */
    private fun toJsonArray(list: List<String>?): String {
        if (list.isNullOrEmpty()) return "[]"
        val quote = "\""
        val items = list.map { quote + it.replace(quote, "") + quote }
        return items.joinToString(",", prefix = "[", postfix = "]")
    }

    companion object {
        /** 供介面顯示的資料來源說明。 */
        fun sourceLabel(): String = "GitHub 後端資料集"
    }
}
