package hk.transit.eta.data.remote

import com.google.gson.Gson
import com.google.gson.GsonBuilder
import hk.transit.eta.BuildConfig
import okhttp3.ConnectionSpec
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

/**
 * 建立各資料源的 Retrofit 客戶端。
 *
 * 效能重點：
 *  - OkHttpClient 自備連線池與執行緒池，必須重用；
 *    舊寫法每次呼叫都新建一個 client，等於每次都重新握手、且洩漏執行緒。
 *  - Retrofit 實例亦按 baseUrl 快取。
 *
 * 政府 API 偶爾會瞬間回傳 429／5xx，故加入有限度重試；
 * 重試只針對連線例外與 429／5xx，且改用 OkHttp 原生的
 * `retryOnConnectionFailure` + 自訂攔截器，避免在攔截器內 `Thread.sleep`。
 */
object NetworkClient {

    private val gson: Gson = GsonBuilder()
        .setLenient()
        .serializeNulls()
        .create()

    /** 一般 JSON API：體積小，逾時可較短。 */
    private val jsonClient: OkHttpClient by lazy {
        baseBuilder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .writeTimeout(15, TimeUnit.SECONDS)
            .callTimeout(45, TimeUnit.SECONDS)
            .build()
    }

    /**
     * 靜態檔（CSV／XML）專用：運輸署 RSTOP_BUS.csv 可達數 MB，
     * 必須給予較長的讀取逾時，否則每日同步會在慢速網絡下失敗。
     */
    private val bulkClient: OkHttpClient by lazy {
        baseBuilder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(180, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .callTimeout(0, TimeUnit.SECONDS)   // 0 = 不設整體逾時，交由 readTimeout 控制
            .build()
    }

    private fun baseBuilder(): OkHttpClient.Builder {
        val builder = OkHttpClient.Builder()
            .retryOnConnectionFailure(true)
            // 只接受 TLS；Manifest 亦已關閉 cleartext
            .connectionSpecs(listOf(ConnectionSpec.MODERN_TLS, ConnectionSpec.COMPATIBLE_TLS))
            .addInterceptor(RetryInterceptor(maxAttempts = 3))
        if (BuildConfig.DEBUG) {
            builder.addInterceptor(
                HttpLoggingInterceptor().apply { level = HttpLoggingInterceptor.Level.BASIC }
            )
        }
        return builder
    }

    private val retrofitCache = ConcurrentHashMap<String, Retrofit>()

    private fun retrofit(baseUrl: String, client: OkHttpClient): Retrofit =
        retrofitCache.getOrPut(baseUrl + "@" + client.hashCode()) {
            Retrofit.Builder()
                .baseUrl(baseUrl)
                .client(client)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build()
        }

    fun kmb(): KmbService = retrofit(ApiConstants.KMB_BASE, jsonClient).create(KmbService::class.java)
    fun ctb(): CtbService = retrofit(ApiConstants.CTB_BASE, jsonClient).create(CtbService::class.java)
    fun nlb(): NlbService = retrofit(ApiConstants.NLB_BASE, jsonClient).create(NlbService::class.java)
    fun gmb(): GmbService = retrofit(ApiConstants.GMB_BASE, jsonClient).create(GmbService::class.java)
    fun mtr(): MtrService = retrofit(ApiConstants.MTR_BASE, jsonClient).create(MtrService::class.java)
    fun hko(): HkoService = retrofit(ApiConstants.HKO_BASE, jsonClient).create(HkoService::class.java)

    /** 靜態檔案使用絕對網址，baseUrl 僅作佔位。 */
    fun static(): StaticFileService =
        retrofit("https://static.data.gov.hk/", bulkClient).create(StaticFileService::class.java)

    /**
     * GitHub 後端資料集。
     *
     * 使用 bulkClient：routes.json／stops.json 可達數 MB，
     * 較長的讀取逾時可避免慢速網絡下同步失敗。
     * 連線會由 OkHttp 連線池重用，與其他資料來源共用同一個 client 實例。
     */
    fun dataset(): DatasetService =
        retrofit("https://raw.githubusercontent.com/", bulkClient).create(DatasetService::class.java)

    fun gson(): Gson = gson
}
