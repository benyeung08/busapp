package hk.transit.eta.domain

import hk.transit.eta.core.util.Fingerprint
import hk.transit.eta.data.local.db.DailyChangeEntity
import hk.transit.eta.data.local.db.HeadwayEntity
import hk.transit.eta.data.local.db.RouteEntity
import hk.transit.eta.data.local.db.RouteSnapshotEntity
import hk.transit.eta.data.local.db.RouteStopEntity
import hk.transit.eta.data.local.db.StopEntity
import hk.transit.eta.data.local.db.StopSnapshotEntity
import hk.transit.eta.domain.model.ChangeScope
import hk.transit.eta.domain.model.ChangeSource
import hk.transit.eta.domain.model.ChangeType
import hk.transit.eta.domain.model.Operator
import kotlin.math.abs

/**
 * 每日比對路線／車站快照，得出當日：
 *  - 新增的路線與車站
 *  - 取消的路線與車站
 *  - 修改的路線與車站（改名、改起訖點、改票價、改站序）
 *
 * 只比較「指紋」，因此即使官方檔案沒有提供明確的異動標記也能偵測。
 */
object ChangeDetector {

    fun routeFingerprint(route: RouteEntity, stopCount: Int, stopFingerprint: String): String =
        Fingerprint.of(
            route.nameTc, route.originTc, route.destTc, route.serviceType,
            route.specialType, route.serviceMode, stopCount, stopFingerprint
        )

    /** routeKey 格式：{operatorCode}|{routeNo}|{bound}|{serviceType}，TD 目錄為 TD{code}|{routeId} */
    private fun operatorOfKey(key: String): Operator? {
        val code = key.substringBefore("|")
        return Operator.fromCode(code) ?: Operator.fromCode(code.removePrefix("TD"))
    }

    fun stopFingerprint(stop: StopEntity): String =
        Fingerprint.of(stop.nameTc, stop.nameEn, "%.6f".format(stop.lat), "%.6f".format(stop.lng))

    /**
     * @param previous 昨日（或上次）的路線快照；若為空則代表首次建立，不產生變動記錄
     */
    fun detectRouteChanges(
        date: String,
        currentRoutes: List<RouteEntity>,
        stopCounts: Map<String, Int>,
        stopFingerprints: Map<String, String>,
        previous: Map<String, RouteSnapshotEntity>
    ): List<DailyChangeEntity> {
        if (previous.isEmpty()) return emptyList()   // 首次建立基準，不視為變動

        val now = System.currentTimeMillis()
        val currentKeys = currentRoutes.map { it.routeKey }.toSet()
        val out = mutableListOf<DailyChangeEntity>()

        for (route in currentRoutes) {
            val stopCount = stopCounts[route.routeKey] ?: 0
            val stopFp = stopFingerprints[route.routeKey] ?: ""
            val fp = routeFingerprint(route, stopCount, stopFp)
            val operator = Operator.fromCode(route.operatorCode) ?: continue
            val prev = previous[route.routeKey]

            if (prev == null) {
                out += entity(
                    date = date,
                    type = ChangeType.ADDED,
                    scope = ChangeScope.ROUTE,
                    operator = operator,
                    route = route,
                    title = "新增路線 ${operator.labelTc} ${route.routeNo}（${route.originTc} → ${route.destTc}）",
                    detail = buildString {
                        append("路線名稱：${route.nameTc}")
                        append("\n起點：${route.originTc}")
                        append("\n終點：${route.destTc}")
                        append("\n車站數目：$stopCount")
                        if (route.fullFare > 0) append("\n全程收費：$${"%.1f".format(route.fullFare)}")
                        append("\n方向：${if (route.bound == "O") "往 ${route.destTc}" else "往 ${route.originTc}"}")
                        append("\n營辦商：${route.companyCode}")
                    },
                    source = ChangeSource.CATALOGUE_DIFF,
                    now = now
                )
                continue
            }

            if (prev.fingerprint == fp) continue

            val diffs = mutableListOf<String>()
            if (prev.nameTc != route.nameTc) diffs += "路線名稱：${prev.nameTc} → ${route.nameTc}"
            if (prev.originTc != route.originTc) diffs += "起點站：${prev.originTc} → ${route.originTc}"
            if (prev.destTc != route.destTc) diffs += "終點站：${prev.destTc} → ${route.destTc}"
            if (abs(prev.fullFare - route.fullFare) > 0.001) {
                diffs += "全程收費：$${"%.1f".format(prev.fullFare)} → $${"%.1f".format(route.fullFare)}"
            }
            if (prev.journeyTime != route.journeyTime && route.journeyTime > 0) {
                diffs += "行車時間：${prev.journeyTime} 分鐘 → ${route.journeyTime} 分鐘"
            }
            if (prev.stopCount != stopCount) {
                diffs += "車站數目：${prev.stopCount} → $stopCount"
            }
            if (prev.stopFingerprint != stopFp) {
                diffs += "車站順序或車站名單已更改"
            }

            if (diffs.isEmpty()) continue

            out += entity(
                date = date,
                type = ChangeType.MODIFIED,
                scope = ChangeScope.ROUTE,
                operator = operator,
                route = route,
                title = "修改路線 ${operator.labelTc} ${route.routeNo}（${diffs.size} 項改動）",
                detail = diffs.joinToString("\n"),
                source = ChangeSource.CATALOGUE_DIFF,
                now = now
            )
        }

        // 已取消的路線
        for ((key, prev) in previous) {
            if (key in currentKeys) continue
            val operator = operatorOfKey(key) ?: Operator.KMB
            val parts = key.split("|")
            out += DailyChangeEntity(
                date = date,
                scope = ChangeScope.ROUTE.name,
                changeType = ChangeType.REMOVED.name,
                operatorCode = operator.code,
                routeKey = key,
                routeNo = parts.getOrNull(1),
                bound = parts.getOrNull(2),
                stopKey = null,
                stopId = null,
                title = "取消路線 ${prev.nameTc}",
                detail = buildString {
                    append("原起點：${prev.originTc}")
                    append("\n原終點：${prev.destTc}")
                    append("\n原車站數目：${prev.stopCount}")
                    append("\n最後收費紀錄：$${"%.1f".format(prev.fullFare)}")
                    append("\n\n此路線已於最新的官方路線資料中移除。")
                },
                affectedStopsJson = "[]",
                affectedStopIdsJson = "[]",
                effectiveFrom = null,
                effectiveTo = null,
                resumedAt = null,
                weatherRelated = false,
                warningCode = null,
                headwayMinutes = null,
                normalHeadwayMinutes = null,
                source = ChangeSource.CATALOGUE_DIFF.name,
                isEstimate = false,
                createdAt = now,
                dedupKey = "ROUTE|REMOVED|$key|$date"
            )
        }

        return out
    }

    fun detectStopChanges(
        date: String,
        currentStops: List<StopEntity>,
        previous: Map<String, StopSnapshotEntity>
    ): List<DailyChangeEntity> {
        if (previous.isEmpty()) return emptyList()

        val now = System.currentTimeMillis()
        val currentKeys = currentStops.map { it.stopKey }.toSet()
        val out = mutableListOf<DailyChangeEntity>()

        for (stop in currentStops) {
            val operator = Operator.fromCode(stop.operatorCode) ?: continue
            val fp = stopFingerprint(stop)
            val prev = previous[stop.stopKey]

            if (prev == null) {
                out += DailyChangeEntity(
                    date = date,
                    scope = ChangeScope.STOP.name,
                    changeType = ChangeType.ADDED.name,
                    operatorCode = operator.code,
                    routeKey = null,
                    routeNo = null,
                    bound = null,
                    stopKey = stop.stopKey,
                    stopId = stop.stopId,
                    title = "新增車站 ${stop.nameTc}",
                    detail = buildString {
                        append("英文名稱：${stop.nameEn}")
                        append("\n營辦商：${operator.labelTc}")
                        append("\n站號：${stop.stopId}")
                        append("\n座標：${"%.6f".format(stop.lat)}, ${"%.6f".format(stop.lng)}")
                    },
                    affectedStopsJson = "[]",
                    affectedStopIdsJson = "[]",
                    effectiveFrom = null,
                    effectiveTo = null,
                    resumedAt = null,
                    weatherRelated = false,
                    warningCode = null,
                    headwayMinutes = null,
                    normalHeadwayMinutes = null,
                    source = ChangeSource.CATALOGUE_DIFF.name,
                    isEstimate = false,
                    createdAt = now,
                    dedupKey = "STOP|ADDED|${stop.stopKey}|$date"
                )
                continue
            }

            if (prev.fingerprint == fp) continue

            val diffs = mutableListOf<String>()
            if (prev.nameTc != stop.nameTc) diffs += "中文站名：${prev.nameTc} → ${stop.nameTc}"
            if (prev.nameEn != stop.nameEn) diffs += "英文站名：${prev.nameEn} → ${stop.nameEn}"
            val moved = distanceMetres(prev.lat, prev.lng, stop.lat, stop.lng)
            if (moved > 30.0) {
                diffs += "車站位置移動約 ${moved.toInt()} 米（${"%.5f".format(prev.lat)},${"%.5f".format(prev.lng)} → ${"%.5f".format(stop.lat)},${"%.5f".format(stop.lng)}）"
            }
            if (diffs.isEmpty()) continue

            out += DailyChangeEntity(
                date = date,
                scope = ChangeScope.STOP.name,
                changeType = ChangeType.MODIFIED.name,
                operatorCode = operator.code,
                routeKey = null,
                routeNo = null,
                bound = null,
                stopKey = stop.stopKey,
                stopId = stop.stopId,
                title = "修改車站 ${prev.nameTc}（${diffs.size} 項改動）",
                detail = diffs.joinToString("\n"),
                affectedStopsJson = "[]",
                affectedStopIdsJson = "[]",
                effectiveFrom = null,
                effectiveTo = null,
                resumedAt = null,
                weatherRelated = false,
                warningCode = null,
                headwayMinutes = null,
                normalHeadwayMinutes = null,
                source = ChangeSource.CATALOGUE_DIFF.name,
                isEstimate = false,
                createdAt = now,
                dedupKey = "STOP|MODIFIED|${stop.stopKey}|$date"
            )
        }

        for ((key, prev) in previous) {
            if (key in currentKeys) continue
            val operator = operatorOfKey(key) ?: continue
            out += DailyChangeEntity(
                date = date,
                scope = ChangeScope.STOP.name,
                changeType = ChangeType.REMOVED.name,
                operatorCode = operator.code,
                routeKey = null,
                routeNo = null,
                bound = null,
                stopKey = key,
                stopId = key.substringAfter("|"),
                title = "取消車站 ${prev.nameTc}",
                detail = buildString {
                    append("英文名稱：${prev.nameEn}")
                    append("\n原座標：${"%.6f".format(prev.lat)}, ${"%.6f".format(prev.lng)}")
                    append("\n\n此車站已於最新的官方資料中移除。")
                },
                affectedStopsJson = "[]",
                affectedStopIdsJson = "[]",
                effectiveFrom = null,
                effectiveTo = null,
                resumedAt = null,
                weatherRelated = false,
                warningCode = null,
                headwayMinutes = null,
                normalHeadwayMinutes = null,
                source = ChangeSource.CATALOGUE_DIFF.name,
                isEstimate = false,
                createdAt = now,
                dedupKey = "STOP|REMOVED|$key|$date"
            )
        }

        return out
    }

    /** 由路線 — 車站關係產生「車站指紋」，任何站名或站序改動都會改變它。 */
    fun stopSequenceFingerprint(routeStops: List<RouteStopEntity>): String =
        Fingerprint.of(routeStops.joinToString(">") { "${it.stopSeq}:${it.stopId}:${it.stopNameTc}" })

    private fun entity(
        date: String,
        type: ChangeType,
        scope: ChangeScope,
        operator: Operator,
        route: RouteEntity,
        title: String,
        detail: String,
        source: ChangeSource,
        now: Long
    ) = DailyChangeEntity(
        date = date,
        scope = scope.name,
        changeType = type.name,
        operatorCode = operator.code,
        routeKey = route.routeKey,
        routeNo = route.routeNo,
        bound = route.bound,
        stopKey = null,
        stopId = null,
        title = title,
        detail = detail,
        affectedStopsJson = "[]",
        affectedStopIdsJson = "[]",
        effectiveFrom = null,
        effectiveTo = null,
        resumedAt = null,
        weatherRelated = false,
        warningCode = null,
        headwayMinutes = null,
        normalHeadwayMinutes = null,
        source = source.name,
        isEstimate = false,
        createdAt = now,
        dedupKey = "${scope.name}|${type.name}|${route.routeKey}|$date"
    )

    /** 兩點球面距離（米），Haversine。 */
    fun distanceMetres(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val r = 6371000.0
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = kotlin.math.sin(dLat / 2) * kotlin.math.sin(dLat / 2) +
            kotlin.math.cos(Math.toRadians(lat1)) * kotlin.math.cos(Math.toRadians(lat2)) *
            kotlin.math.sin(dLon / 2) * kotlin.math.sin(dLon / 2)
        return 2 * r * kotlin.math.atan2(kotlin.math.sqrt(a), kotlin.math.sqrt(1 - a))
    }

    /** 由班次表推算正常班次間距（分鐘）。 */
    fun normalHeadway(headways: List<HeadwayEntity>): Int? {
        if (headways.isEmpty()) return null
        return (headways.minOf { it.headwaySecs } / 60).coerceAtLeast(1)
    }
}
