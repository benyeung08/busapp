package hk.transit.eta.data.repository

import hk.transit.eta.core.util.CsvParser
import hk.transit.eta.core.util.Fingerprint
import hk.transit.eta.core.util.TimeUtil
import hk.transit.eta.data.local.db.DailyChangeEntity
import hk.transit.eta.data.local.db.RouteEntity
import hk.transit.eta.data.local.db.RouteStopEntity
import hk.transit.eta.data.local.db.StopEntity
import hk.transit.eta.data.remote.ApiConstants
import hk.transit.eta.data.remote.NetworkClient
import hk.transit.eta.domain.model.ChangeScope
import hk.transit.eta.domain.model.ChangeSource
import hk.transit.eta.domain.model.ChangeType
import hk.transit.eta.domain.model.Operator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * 運輸署「公共交通路線及收費資料」靜態檔（CSV）。
 *
 * 優點：一次下載即涵蓋全港巴士與專線小巴的路線、車站、站序與收費，
 * 不必逐條路線呼叫營辦商 API，非常適合每日全自動比對。
 */
class TdStaticRepository {

    private val static = NetworkClient.static()

    data class StaticCatalogue(
        val routes: List<RouteEntity>,
        val stops: List<StopEntity>,
        val routeStops: List<RouteStopEntity>
    )

    suspend fun url(path: String): String = "${ApiConstants.TD_STATIC_BASE}$path"

    /** 下載並解析巴士＋小巴的完整目錄。 */
    suspend fun fetchCatalogue(): StaticCatalogue = withContext(Dispatchers.IO) {
        val routeCsvBus = download(ApiConstants.TD_ROUTE_BUS)
        val routeCsvGmb = download(ApiConstants.TD_ROUTE_GMB)
        val rstopCsvBus = download(ApiConstants.TD_RSTOP_BUS)
        val rstopCsvGmb = download(ApiConstants.TD_RSTOP_GMB)

        val routes = mutableListOf<RouteEntity>()
        val stops = mutableListOf<StopEntity>()
        val routeStops = mutableListOf<RouteStopEntity>()

        // 港鐵巴士（LRTFEEDER）另有專屬處理，故從一般巴士目錄中排除，避免重複計算
        val mtrRouteIds = lrtFeederRouteIds(routeCsvBus)
        routes += parseRoutes(routeCsvBus, bus = true, excludeCompany = MTR_BUS_COMPANY)
        routes += parseRoutes(routeCsvGmb, bus = false)
        val stopCsvBus = download(ApiConstants.TD_STOP_BUS)
        stops += parseStops(stopCsvBus, bus = true)
        stops += parseStops(download(ApiConstants.TD_STOP_GMB), bus = false)
        routeStops += parseRouteStops(rstopCsvBus, bus = true, excludeRouteIds = mtrRouteIds)
        routeStops += parseRouteStops(rstopCsvGmb, bus = false)

        // 港鐵巴士：寫入可查詢的 MTR_BUS 命名空間（含去／回程方向）
        val mtrBus = buildMtrBusCatalogue(routeCsvBus, rstopCsvBus, stopCsvBus)
        routes += mtrBus.routes
        stops += mtrBus.stops
        routeStops += mtrBus.routeStops

        StaticCatalogue(routes, stops, routeStops)
    }

    /**
     * 建立港鐵巴士（LRTFEEDER）的路線與車站目錄。
     *
     * 與其他營辦商的差異：
     *  1. 寫入 Operator.MTR_BUS 命名空間，而非純目錄的 TD_BUS——
     *     港鐵巴士沒有對外開放的「車站清單 API」，運輸署的 STOP_ID
     *     是唯一同時具備中文站名與座標的政府資料，必須讓它能被查詢。
     *  2. routeKey 帶有 ROUTE_SEQ（方向）。運輸署的 RSTOP_BUS.csv
     *     以 ROUTE_SEQ 區分去程（1＝入站或循環）與回程（2＝出站），
     *     若忽略它，去回程的 STOP_SEQ 會互相覆蓋、令站序與燈號全數錯亂。
     *
     * 方向只能從 RSTOP 得知（ROUTE_BUS.csv 沒有 ROUTE_SEQ），
     * 故採兩段式：先取路線主檔，再由 RSTOP 反推該路線有哪些方向。
     */
    private fun buildMtrBusCatalogue(
        routeCsv: String,
        rstopCsv: String,
        stopCsv: String
    ): StaticCatalogue {
        if (routeCsv.isBlank() || rstopCsv.isBlank()) return StaticCatalogue(emptyList(), emptyList(), emptyList())

        val master = CsvParser.parseWithHeader(routeCsv)
            .filter { it["COMPANY_CODE"].orEmpty().trim().equals(MTR_BUS_COMPANY, ignoreCase = true) }
            .associateBy { it["ROUTE_ID"].orEmpty() }
        if (master.isEmpty()) return StaticCatalogue(emptyList(), emptyList(), emptyList())

        val now = TimeUtil.now().toEpochMilli()
        val rstopRows = CsvParser.parseWithHeader(rstopCsv)
            .filter { master.containsKey(it["ROUTE_ID"].orEmpty()) }
        if (rstopRows.isEmpty()) return StaticCatalogue(emptyList(), emptyList(), emptyList())

        // ROUTE_ID → 該路線出現過的方向（ROUTE_SEQ）
        val seqsByRoute = rstopRows
            .groupBy { it["ROUTE_ID"].orEmpty() }
            .mapValues { (_, rows) -> rows.mapNotNull { it["ROUTE_SEQ"]?.trim() }.toSet() }

        val routes = mutableListOf<RouteEntity>()
        val routeStops = mutableListOf<RouteStopEntity>()

        for ((routeId, row) in master) {
            val routeNo = row["ROUTE_NAMEC"].orEmpty().trim()
            if (routeNo.isBlank()) continue
            val seqs = seqsByRoute[routeId].orEmpty().ifEmpty { setOf("1") }

            for (seq in seqs) {
                val routeKey = MtrBusKeys.route(routeId, seq)
                routes += RouteEntity(
                    routeKey = routeKey,
                    operatorCode = Operator.MTR_BUS.code,
                    companyCode = MTR_BUS_COMPANY,
                    routeNo = routeNo,
                    bound = MtrBusKeys.boundOf(seq),
                    serviceType = row["SPECIAL_TYPE"]?.toIntOrNull() ?: 0,
                    nameTc = "$routeNo ${row["LOC_START_NAMEC"]}→${row["LOC_END_NAMEC"]}",
                    nameEn = "${row["ROUTE_NAMEE"]} ${row["LOC_START_NAMEE"]}→${row["LOC_END_NAMEE"]}",
                    originTc = row["LOC_START_NAMEC"].orEmpty(),
                    originEn = row["LOC_START_NAMEE"].orEmpty(),
                    destTc = row["LOC_END_NAMEC"].orEmpty(),
                    destEn = row["LOC_END_NAMEE"].orEmpty(),
                    fullFare = row["FULL_FARE"]?.toDoubleOrNull() ?: 0.0,
                    journeyTime = row["JOURNEY_TIME"]?.toIntOrNull() ?: 0,
                    specialType = row["SPECIAL_TYPE"]?.toIntOrNull() ?: 0,
                    serviceMode = row["SERVICE_MODE"].orEmpty(),
                    // 是否真的有即時到站，取決於同步時能否建立 busStopId 對照表
                    hasRealtime = false,
                    lastUpdate = TimeUtil.parseFlexible(row["LAST_UPDATE_DATE"])?.toEpochMilli() ?: now
                )

                routeStops += rstopRows
                    .filter { it["ROUTE_ID"].orEmpty() == routeId && it["ROUTE_SEQ"]?.trim() == seq }
                    .mapNotNull { s ->
                        val stopId = s["STOP_ID"].orEmpty().ifBlank { return@mapNotNull null }
                        val stopSeq = s["STOP_SEQ"]?.toIntOrNull() ?: return@mapNotNull null
                        RouteStopEntity(
                            routeKey = routeKey,
                            stopSeq = stopSeq,
                            stopKey = MtrBusKeys.stop(stopId),
                            stopId = stopId,
                            stopNameTc = s["STOP_NAMEC"].orEmpty(),
                            stopNameEn = s["STOP_NAMEE"].orEmpty(),
                            lat = 0.0,
                            lng = 0.0
                        )
                    }
            }
        }

        // 只保留港鐵巴士實際停靠的車站，避免把全港巴士站都複製一份
        val usedStopIds = routeStops.map { it.stopId }.toSet()
        val stops = if (stopCsv.isBlank() || usedStopIds.isEmpty()) {
            emptyList()
        } else {
            CsvParser.parseWithHeader(stopCsv)
                .filter { it["STOP_ID"].orEmpty() in usedStopIds }
                .mapNotNull { row ->
                    val stopId = row["STOP_ID"].orEmpty().ifBlank { return@mapNotNull null }
                    StopEntity(
                        stopKey = MtrBusKeys.stop(stopId),
                        operatorCode = Operator.MTR_BUS.code,
                        stopId = stopId,
                        nameTc = row["STOP_NAMEC"].orEmpty(),
                        nameEn = row["STOP_NAMEE"].orEmpty(),
                        lat = row["STOP_LAT"]?.toDoubleOrNull()
                            ?: row["LATITUDE"]?.toDoubleOrNull() ?: 0.0,
                        lng = row["STOP_LONG"]?.toDoubleOrNull()
                            ?: row["LONGITUDE"]?.toDoubleOrNull() ?: 0.0,
                        lastUpdate = TimeUtil.parseFlexible(row["LAST_UPDATE_DATE"])?.toEpochMilli() ?: now
                    )
                }
        }
        return StaticCatalogue(routes, stops, routeStops)
    }

    /**
     * 下載官方「更新記錄」（Delta）檔，直接產生當日變動。
     * 官方檔以 Add / Update / Delete 標示每筆記錄。
     */
    suspend fun fetchOfficialDeltas(date: String): List<DailyChangeEntity> = withContext(Dispatchers.IO) {
        val out = mutableListOf<DailyChangeEntity>()
        val now = TimeUtil.now().toEpochMilli()

        out += parseRouteDelta(download(ApiConstants.TD_ROUTE_BUS_DELTA), date, now, gmb = false)
        out += parseRouteDelta(download(ApiConstants.TD_ROUTE_GMB_DELTA), date, now, gmb = true)
        out += parseStopDelta(download(ApiConstants.TD_STOP_BUS_DELTA), date, now, gmb = false)
        out += parseStopDelta(download(ApiConstants.TD_STOP_GMB_DELTA), date, now, gmb = true)
        out += parseRouteStopDelta(download(ApiConstants.TD_RSTOP_BUS_DELTA), date, now, gmb = false)
        out += parseRouteStopDelta(download(ApiConstants.TD_RSTOP_GMB_DELTA), date, now, gmb = true)

        out
    }

    // ------------------------------------------------------------------
    // 內部：CSV 解析
    // ------------------------------------------------------------------

    private suspend fun download(path: String): String = try {
        static.raw(url(path)).string()
    } catch (e: Exception) {
        ""
    }

    private fun parseRoutes(csv: String, bus: Boolean, excludeCompany: String? = null): List<RouteEntity> {
        if (csv.isBlank()) return emptyList()
        return CsvParser.parseWithHeader(csv).mapNotNull { row ->
            val company = row["COMPANY_CODE"].orEmpty()
            if (excludeCompany != null && company.trim().equals(excludeCompany, ignoreCase = true)) {
                return@mapNotNull null
            }
            val operator = mapCompany(company, bus)
            val routeId = row["ROUTE_ID"].orEmpty().ifBlank { return@mapNotNull null }
            val now = TimeUtil.now().toEpochMilli()
            val routeNo = row["ROUTE_NAMEC"].orEmpty().trim()
            val nameTc = "${routeNo} ${row["LOC_START_NAMEC"]}→${row["LOC_END_NAMEC"]}"
            RouteEntity(
                routeKey = tdRouteKey(operator, routeId),
                operatorCode = operator.code,
                companyCode = company,
                routeNo = routeNo,
                bound = "O",
                serviceType = row["SPECIAL_TYPE"]?.toIntOrNull() ?: 0,
                nameTc = nameTc,
                nameEn = "${row["ROUTE_NAMEE"]} ${row["LOC_START_NAMEE"]}→${row["LOC_END_NAMEE"]}",
                originTc = row["LOC_START_NAMEC"].orEmpty(),
                originEn = row["LOC_START_NAMEE"].orEmpty(),
                destTc = row["LOC_END_NAMEC"].orEmpty(),
                destEn = row["LOC_END_NAMEE"].orEmpty(),
                fullFare = row["FULL_FARE"]?.toDoubleOrNull() ?: 0.0,
                journeyTime = row["JOURNEY_TIME"]?.toIntOrNull() ?: 0,
                specialType = row["SPECIAL_TYPE"]?.toIntOrNull() ?: 0,
                serviceMode = row["SERVICE_MODE"].orEmpty(),
                hasRealtime = false,
                lastUpdate = TimeUtil.parseFlexible(row["LAST_UPDATE_DATE"])?.toEpochMilli() ?: now
            )
        }
    }

    private fun parseStops(csv: String, bus: Boolean): List<StopEntity> {
        if (csv.isBlank()) return emptyList()
        // 運輸署的 STOP_ID 屬自己的編號系統，與各營辦商的站號並不相通。
        // 若寫入 KMB／GMB 命名空間，會覆蓋掉真正可用於即時到站查詢的站號，
        // 故一律使用獨立的 TD 目錄命名空間。
        val operator = if (bus) Operator.TD_BUS else Operator.TD_GMB
        val now = TimeUtil.now().toEpochMilli()
        return CsvParser.parseWithHeader(csv).mapNotNull { row ->
            val stopId = row["STOP_ID"].orEmpty().ifBlank { return@mapNotNull null }
            StopEntity(
                stopKey = "${operator.code}|$stopId",
                operatorCode = operator.code,
                stopId = stopId,
                nameTc = row["STOP_NAMEC"].orEmpty(),
                nameEn = row["STOP_NAMEE"].orEmpty(),
                lat = row["STOP_LAT"]?.toDoubleOrNull()
                    ?: row["LATITUDE"]?.toDoubleOrNull() ?: 0.0,
                lng = row["STOP_LONG"]?.toDoubleOrNull()
                    ?: row["LONGITUDE"]?.toDoubleOrNull() ?: 0.0,
                lastUpdate = TimeUtil.parseFlexible(row["LAST_UPDATE_DATE"])?.toEpochMilli() ?: now
            )
        }
    }

    /** 取出 ROUTE_BUS.csv 中屬於港鐵巴士（LRTFEEDER）的 ROUTE_ID 集合。 */
    private fun lrtFeederRouteIds(routeCsv: String): Set<String> {
        if (routeCsv.isBlank()) return emptySet()
        return CsvParser.parseWithHeader(routeCsv)
            .filter { it["COMPANY_CODE"].orEmpty().trim().equals(MTR_BUS_COMPANY, ignoreCase = true) }
            .mapNotNull { it["ROUTE_ID"].orEmpty().ifBlank { null } }
            .toSet()
    }

    private fun parseRouteStops(
        csv: String,
        bus: Boolean,
        excludeRouteIds: Set<String> = emptySet()
    ): List<RouteStopEntity> {
        if (csv.isBlank()) return emptyList()
        val operator = if (bus) Operator.TD_BUS else Operator.TD_GMB
        return CsvParser.parseWithHeader(csv).mapNotNull { row ->
            val routeId = row["ROUTE_ID"].orEmpty().ifBlank { return@mapNotNull null }
            if (routeId in excludeRouteIds) return@mapNotNull null
            val stopId = row["STOP_ID"].orEmpty().ifBlank { return@mapNotNull null }
            RouteStopEntity(
                routeKey = tdRouteKey(operator, routeId),
                stopSeq = row["STOP_SEQ"]?.toIntOrNull() ?: return@mapNotNull null,
                stopKey = "${operator.code}|$stopId",
                stopId = stopId,
                stopNameTc = row["STOP_NAMEC"].orEmpty(),
                stopNameEn = row["STOP_NAMEE"].orEmpty(),
                lat = 0.0,
                lng = 0.0
            )
        }
    }

    // ------------------------------------------------------------------
    // 內部：Delta 解析
    // ------------------------------------------------------------------

    private fun parseRouteDelta(csv: String, date: String, now: Long, gmb: Boolean): List<DailyChangeEntity> {
        if (csv.isBlank()) return emptyList()
        val rows = CsvParser.parseWithHeader(csv)
        return rows.mapNotNull { row ->
            val change = detectChange(row) ?: return@mapNotNull null
            val type = changeTypeOf(change) ?: return@mapNotNull null
            val company = row["COMPANY_CODE"].orEmpty()
            // 變動記錄中顯示真正的營辦商，但 routeKey 仍用 TD 命名空間
            val operator = displayOperator(company, !gmb)
            val directoryOperator = mapCompany(company, !gmb)
            val routeId = row["ROUTE_ID"].orEmpty()
            val routeNo = row["ROUTE_NAMEC"].orEmpty()
            DailyChangeEntity(
                date = date,
                scope = ChangeScope.ROUTE.name,
                changeType = type.name,
                operatorCode = operator.code,
                routeKey = tdRouteKey(directoryOperator, routeId),
                routeNo = routeNo,
                bound = "O",
                stopKey = null,
                stopId = null,
                title = "${type.labelTc}路線（官方更新記錄）${operator.labelTc} $routeNo",
                detail = buildString {
                    append("路線：$routeNo（${row["LOC_START_NAMEC"]} → ${row["LOC_END_NAMEC"]}）")
                    append("\n營辦商：$company")
                    append("\n全程收費：$${row["FULL_FARE"] ?: "—"}")
                    row["LAST_UPDATE_DATE"]?.let { append("\n官方更新時間：$it") }
                    append("\n\n來源：運輸署「公共交通路線及收費資料」更新記錄（$change）")
                },
                affectedStopsJson = "[]",
                affectedStopIdsJson = "[]",
                effectiveFrom = TimeUtil.parseFlexible(row["LAST_UPDATE_DATE"])?.toEpochMilli(),
                effectiveTo = null,
                resumedAt = null,
                weatherRelated = false,
                warningCode = null,
                headwayMinutes = null,
                normalHeadwayMinutes = null,
                source = ChangeSource.TD_DELTA.name,
                isEstimate = false,
                createdAt = now,
                dedupKey = "TDROUTE|${type.name}|${operator.code}|$routeId|$date|$change"
            )
        }
    }

    private fun parseStopDelta(csv: String, date: String, now: Long, gmb: Boolean): List<DailyChangeEntity> {
        if (csv.isBlank()) return emptyList()
        val operator = if (gmb) Operator.TD_GMB else Operator.TD_BUS
        return CsvParser.parseWithHeader(csv).mapNotNull { row ->
            val change = detectChange(row) ?: return@mapNotNull null
            val type = changeTypeOf(change) ?: return@mapNotNull null
            val stopId = row["STOP_ID"].orEmpty().ifBlank { return@mapNotNull null }
            val nameTc = row["STOP_NAMEC"].orEmpty()
            DailyChangeEntity(
                date = date,
                scope = ChangeScope.STOP.name,
                changeType = type.name,
                operatorCode = operator.code,
                routeKey = null,
                routeNo = null,
                bound = null,
                stopKey = "${operator.code}|$stopId",
                stopId = stopId,
                title = "${type.labelTc}車站（官方更新記錄）$nameTc",
                detail = buildString {
                    append("站名：$nameTc（${row["STOP_NAMEE"]}）")
                    append("\n站號：$stopId")
                    append("\n座標：${row["STOP_LAT"] ?: "—"}, ${row["STOP_LONG"] ?: "—"}")
                    row["LAST_UPDATE_DATE"]?.let { append("\n官方更新時間：$it") }
                    append("\n\n來源：運輸署「公共交通路線及收費資料」更新記錄（$change）")
                },
                affectedStopsJson = "[]",
                affectedStopIdsJson = "[]",
                effectiveFrom = TimeUtil.parseFlexible(row["LAST_UPDATE_DATE"])?.toEpochMilli(),
                effectiveTo = null,
                resumedAt = null,
                weatherRelated = false,
                warningCode = null,
                headwayMinutes = null,
                normalHeadwayMinutes = null,
                source = ChangeSource.TD_DELTA.name,
                isEstimate = false,
                createdAt = now,
                dedupKey = "TDSTOP|${type.name}|${operator.code}|$stopId|$date|$change"
            )
        }
    }

    private fun parseRouteStopDelta(csv: String, date: String, now: Long, gmb: Boolean): List<DailyChangeEntity> {
        if (csv.isBlank()) return emptyList()
        val operator = if (gmb) Operator.TD_GMB else Operator.TD_BUS
        // 站序改動代表「臨時改道／改經」的最普遍形式
        return CsvParser.parseWithHeader(csv).mapNotNull { row ->
            val change = detectChange(row) ?: return@mapNotNull null
            val type = changeTypeOf(change) ?: return@mapNotNull null
            val routeId = row["ROUTE_ID"].orEmpty().ifBlank { return@mapNotNull null }
            val stopId = row["STOP_ID"].orEmpty()
            val stopName = row["STOP_NAMEC"].orEmpty()
            if (stopName.isBlank()) return@mapNotNull null
            DailyChangeEntity(
                date = date,
                scope = ChangeScope.STOP.name,
                changeType = if (type == ChangeType.MODIFIED) ChangeType.DIVERSION.name else type.name,
                operatorCode = operator.code,
                routeKey = tdRouteKey(operator, routeId),
                routeNo = row["ROUTE_NAMEC"]?.takeIf { it.isNotBlank() },
                bound = row["ROUTE_SEQ"],
                stopKey = "${operator.code}|$stopId",
                stopId = stopId,
                title = "${
                    if (type == ChangeType.MODIFIED) ChangeType.DIVERSION.labelTc else type.labelTc
                }・站序變動：$stopName",
                detail = buildString {
                    append("路線 ID：$routeId")
                    append("\n站序：第 ${row["STOP_SEQ"] ?: "—"} 站")
                    append("\n車站：$stopName（${row["STOP_NAMEE"]}）")
                    append("\n方向：${if (row["ROUTE_SEQ"] == "1") "去程" else "回程"}")
                    row["LAST_UPDATE_DATE"]?.let { append("\n官方更新時間：$it") }
                    append("\n\n來源：運輸署「公共交通路線及收費資料」站序更新記錄（$change）")
                },
                affectedStopsJson = stopName.takeIf { it.isNotBlank() }?.let { """["$it"]""" } ?: "[]",
                affectedStopIdsJson = stopId.takeIf { it.isNotBlank() }?.let { """["$it"]""" } ?: "[]",
                effectiveFrom = TimeUtil.parseFlexible(row["LAST_UPDATE_DATE"])?.toEpochMilli(),
                effectiveTo = null,
                resumedAt = null,
                weatherRelated = false,
                warningCode = null,
                headwayMinutes = null,
                normalHeadwayMinutes = null,
                source = ChangeSource.TD_DELTA.name,
                isEstimate = false,
                createdAt = now,
                dedupKey = "TDRSTOP|${type.name}|$routeId|$stopId|$date|$change"
            )
        }
    }

    private fun detectChange(row: Map<String, String>): String? {
        val key = row.keys.firstOrNull { it.equals("CHANGE", true) || it.equals("DELTA", true) }
        return key?.let { row[it] }
    }

    private fun changeTypeOf(change: String): ChangeType? = when (change.trim().lowercase()) {
        "add", "added", "new" -> ChangeType.ADDED
        "update", "updated", "modify", "modified" -> ChangeType.MODIFIED
        "delete", "deleted", "remove", "removed" -> ChangeType.REMOVED
        else -> null
    }

    // ------------------------------------------------------------------

    companion object {
        /** 運輸署資料的 routeKey：以 TD 開頭，避免與營辦商即時路線資料衝突。 */
        fun tdRouteKey(operator: Operator, routeId: String): String = "${operator.code}|$routeId"

        /**
         * 運輸署資料一律存放在 TD 目錄命名空間（見 [tdRouteKey]）。
         *
         * 這裡回傳的只是「顯示用」的營辦商歸類；真正的即時到站資料
         * 由各營辦商 API 另行寫入各自的命名空間，兩者不會互相覆蓋。
         */
        /** 運輸署用來標示「港鐵巴士（及接駁巴士）」的公司代碼（舊稱 LRTFEEDER）。 */
        const val MTR_BUS_COMPANY = "LRTFEEDER"

        fun mapCompany(code: String, bus: Boolean): Operator = when (code.trim().uppercase()) {
            "GMB" -> Operator.TD_GMB
            else -> if (bus) Operator.TD_BUS else Operator.TD_GMB
        }

        /** 由運輸署的 COMPANY_CODE 推斷「顯示用」的即時營辦商（僅供介面標示）。 */
        fun displayOperator(code: String, bus: Boolean): Operator = when (code.trim().uppercase()) {
            "KMB", "LWB", "KMB+CTB", "KMB+NWFB", "LWB+CTB" -> Operator.KMB
            "CTB", "NWFB" -> Operator.CTB
            "NLB" -> Operator.NLB
            "GMB" -> Operator.GMB
            "LRTFEEDER" -> Operator.MTR_BUS
            else -> if (bus) Operator.KMB else Operator.GMB
        }
    }
}

/**
 * 港鐵巴士專用的鍵值規則。
 *
 * 與 [RouteKeys] 不同之處：routeKey 帶有運輸署的 ROUTE_SEQ（方向），
 * 因為 RSTOP_BUS.csv 的去程（1）與回程（2）各有自己的 STOP_SEQ 序列；
 * 若把兩者擠進同一個 routeKey，stopSeq 會互相覆蓋，燈號的角色判斷
 * （起點站／中途站／終點站）便會全數錯亂。
 */
object MtrBusKeys {
    /** ROUTE_SEQ ＝ "1" 代表入站或循環線，"2" 代表出站（運輸署資料規格）。 */
    fun boundOf(routeSeq: String): String = if (routeSeq.trim() == "2") "I" else "O"

    fun route(routeId: String, routeSeq: String): String =
        "${Operator.MTR_BUS.code}|$routeId|$routeSeq"

    fun stop(stopId: String): String = "${Operator.MTR_BUS.code}|$stopId"
}

/** 供 CatalogueRepository 產生指紋時使用。 */
fun routeFingerprintOf(route: RouteEntity, stops: List<RouteStopEntity>): String =
    Fingerprint.of(route.nameTc, route.originTc, route.destTc, stops.map { "${it.stopSeq}:${it.stopId}" })
