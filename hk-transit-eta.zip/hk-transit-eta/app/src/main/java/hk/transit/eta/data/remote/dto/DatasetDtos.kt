package hk.transit.eta.data.remote.dto

/**
 * GitHub 後端資料集的資料模型。
 *
 * 由 `tools/build_dataset.py` 在 GitHub Actions 上產生，
 * 欄位順序與命名必須與該腳本的輸出保持一致。
 *
 * 設計取捨：站序（route_stops）資料量最大，故後端把物件陣列壓成
 * `[路線索引, 車站索引, 站序]` 三元組，避免在手機上下載與解析數 MB 的字串鍵值。
 */

data class DatasetManifestDto(
    val date: String = "",
    val generatedAt: String = "",
    val version: Long = 0,
    val schema: Int = 0,
    val counts: DatasetCountsDto? = null,
    val sizes: Map<String, Int>? = null,
    /** 新大嶼山巴士：路線號 → 官方 routeId（查詢即時到站時需要）。 */
    val nlbRouteIds: Map<String, String>? = null
)

data class DatasetCountsDto(
    val routes: Int = 0,
    val stops: Int = 0,
    val routeStops: Int = 0,
    val changes: Int = 0,
    val mtrBusMap: Int = 0
)

data class DatasetRouteDto(
    val routeKey: String = "",
    val operatorCode: String = "",
    val companyCode: String = "",
    val routeNo: String = "",
    val bound: String = "",
    val serviceType: Int = 0,
    val nameTc: String = "",
    val nameEn: String = "",
    val originTc: String = "",
    val originEn: String = "",
    val destTc: String = "",
    val destEn: String = "",
    val fullFare: Double? = null,
    val journeyTime: Int = 0,
    val specialType: Int = 0,
    val serviceMode: String = "",
    val hasRealtime: Boolean = false
)

data class DatasetStopDto(
    val stopKey: String = "",
    val operatorCode: String = "",
    val stopId: String = "",
    val nameTc: String = "",
    val nameEn: String = "",
    val lat: Double? = null,
    val lng: Double? = null
)

data class DatasetMtrBusMapDto(
    val routeKey: String = "",
    val stopSeq: Int = 0,
    val busStopId: String = "",
    val routeName: String = ""
)

data class DatasetChangeDto(
    val date: String = "",
    val scope: String = "ROUTE",
    val changeType: String = "MODIFIED",
    val operatorCode: String = "",
    val routeKey: String? = null,
    val routeNo: String? = null,
    val bound: String? = null,
    val stopKey: String? = null,
    val stopId: String? = null,
    val title: String = "",
    val detail: String = "",
    val affectedStops: List<String>? = null,
    val affectedStopIds: List<String>? = null,
    val weatherRelated: Boolean = false,
    val source: String = "CATALOGUE_DIFF",
    val isEstimate: Boolean = false,
    val dedupKey: String = ""
)

data class DatasetWeatherDto(
    val date: String = "",
    val events: List<DatasetWeatherEventDto>? = null,
    val level: Int = 0
)

data class DatasetWeatherEventDto(
    val key: String = "",
    val date: String = "",
    val warningCode: String = "",
    val warningName: String = "",
    val actionCode: String = "",
    val level: Int = 0,
    val detail: String = ""
)
