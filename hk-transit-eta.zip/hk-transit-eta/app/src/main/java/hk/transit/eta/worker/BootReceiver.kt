package hk.transit.eta.worker

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * 重新開機、更新 App、時間或時區變更後，重新排程所有背景更新。
 */
class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_MY_PACKAGE_REPLACED,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED -> SyncScheduler.scheduleAll(context)
        }
    }
}
