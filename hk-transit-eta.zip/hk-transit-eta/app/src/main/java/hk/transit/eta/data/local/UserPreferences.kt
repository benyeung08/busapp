package hk.transit.eta.data.local

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * 使用者設定。刻意使用 SharedPreferences 而非 DataStore，
 * 以減少依賴並讓背景 Worker 可同步讀取。
 */
class UserPreferences(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences("hk_transit_prefs", Context.MODE_PRIVATE)

    private val _flashEnabled = MutableStateFlow(prefs.getBoolean(KEY_FLASH, true))
    val flashEnabled: StateFlow<Boolean> = _flashEnabled.asStateFlow()

    private val _autoUpdate = MutableStateFlow(prefs.getBoolean(KEY_AUTO_UPDATE, true))
    val autoUpdate: StateFlow<Boolean> = _autoUpdate.asStateFlow()

    private val _syncHour = MutableStateFlow(prefs.getInt(KEY_SYNC_HOUR, 4))
    val syncHour: StateFlow<Int> = _syncHour.asStateFlow()

    private val _language = MutableStateFlow(prefs.getString(KEY_LANG, "tc") ?: "tc")
    val language: StateFlow<String> = _language.asStateFlow()

    private val _followSystem = MutableStateFlow(prefs.getBoolean(KEY_FOLLOW_SYSTEM, true))
    val followSystem: StateFlow<Boolean> = _followSystem.asStateFlow()

    var lastCatalogueSync: Long
        get() = prefs.getLong(KEY_LAST_CATALOGUE_SYNC, 0L)
        set(value) = prefs.edit().putLong(KEY_LAST_CATALOGUE_SYNC, value).apply()

    var lastNewsSync: Long
        get() = prefs.getLong(KEY_LAST_NEWS_SYNC, 0L)
        set(value) = prefs.edit().putLong(KEY_LAST_NEWS_SYNC, value).apply()

    var lastWeatherSync: Long
        get() = prefs.getLong(KEY_LAST_WEATHER_SYNC, 0L)
        set(value) = prefs.edit().putLong(KEY_LAST_WEATHER_SYNC, value).apply()

    var lastHeadwaySync: Long
        get() = prefs.getLong(KEY_LAST_HEADWAY_SYNC, 0L)
        set(value) = prefs.edit().putLong(KEY_LAST_HEADWAY_SYNC, value).apply()

    /**
     * 已匯入的 GitHub 資料集版本。
     * 用以判斷是否需要重新下載；資料集版本相同時可完全略過下載以節省流量。
     */
    var lastDatasetVersion: Long
        get() = prefs.getLong(KEY_LAST_DATASET_VERSION, 0L)
        set(value) = prefs.edit().putLong(KEY_LAST_DATASET_VERSION, value).apply()

    /**
     * 新大嶼山巴士：路線號 → 官方 routeId。
     * 由後端資料集提供，查詢即時到站時需要 routeId 而非路線號。
     */
    var nlbRouteIds: Map<String, String>
        get() {
            val raw = prefs.getString(KEY_NLB_ROUTE_IDS, null) ?: return emptyMap()
            if (raw.isBlank()) return emptyMap()
            return try {
                val obj = org.json.JSONObject(raw)
                val out = mutableMapOf<String, String>()
                obj.keys().forEach { k -> out[k] = obj.optString(k) }
                out
            } catch (e: Exception) {
                emptyMap()
            }
        }
        set(value) {
            val obj = org.json.JSONObject()
            value.forEach { (k, v) -> obj.put(k, v) }
            prefs.edit().putString(KEY_NLB_ROUTE_IDS, obj.toString()).apply()
        }

    fun setFlashEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_FLASH, enabled).apply()
        _flashEnabled.value = enabled
    }

    fun setAutoUpdate(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_AUTO_UPDATE, enabled).apply()
        _autoUpdate.value = enabled
    }

    fun setSyncHour(hour: Int) {
        prefs.edit().putInt(KEY_SYNC_HOUR, hour.coerceIn(0, 23)).apply()
        _syncHour.value = hour.coerceIn(0, 23)
    }

    fun setLanguage(lang: String) {
        prefs.edit().putString(KEY_LANG, lang).apply()
        _language.value = lang
    }

    fun setFollowSystem(follow: Boolean) {
        prefs.edit().putBoolean(KEY_FOLLOW_SYSTEM, follow).apply()
        _followSystem.value = follow
    }

    companion object {
        private const val KEY_FLASH = "flash_enabled"
        private const val KEY_AUTO_UPDATE = "auto_update"
        private const val KEY_SYNC_HOUR = "sync_hour"
        private const val KEY_LANG = "lang"
        private const val KEY_FOLLOW_SYSTEM = "follow_system"
        private const val KEY_LAST_CATALOGUE_SYNC = "last_catalogue_sync"
        private const val KEY_LAST_NEWS_SYNC = "last_news_sync"
        private const val KEY_LAST_WEATHER_SYNC = "last_weather_sync"
        private const val KEY_LAST_HEADWAY_SYNC = "last_headway_sync"
        private const val KEY_LAST_DATASET_VERSION = "last_dataset_version"
        private const val KEY_NLB_ROUTE_IDS = "nlb_route_ids"
    }
}
