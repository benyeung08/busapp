package hk.transit.eta.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import hk.transit.eta.core.di.AppContainer
import hk.transit.eta.core.util.TimeUtil
import hk.transit.eta.data.local.db.StopEntity
import hk.transit.eta.domain.SignalLightEngine
import hk.transit.eta.domain.model.StopEtaBoard
import hk.transit.eta.ui.components.signalFor
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/**
 * 車站到站燈號畫面。
 * 畫面存活期間每 15 秒自動重新抓一次即時到站資料。
 */
class StopBoardViewModel(
    private val container: AppContainer,
    private val initialStopKey: String?
) : ViewModel() {

    private val _stopKey = MutableStateFlow(initialStopKey)
    val stopKey: StateFlow<String?> = _stopKey.asStateFlow()

    private val _stopName = MutableStateFlow("")
    val stopName: StateFlow<String> = _stopName.asStateFlow()

    private val _boards = MutableStateFlow<List<StopEtaBoard>>(emptyList())
    val boards: StateFlow<List<StopEtaBoard>> = _boards.asStateFlow()

    private val _loading = MutableStateFlow(false)
    val loading: StateFlow<Boolean> = _loading.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    private val _updatedAt = MutableStateFlow<Long?>(null)
    val updatedAt: StateFlow<Long?> = _updatedAt.asStateFlow()

    val flashEnabled: StateFlow<Boolean> = container.preferences.flashEnabled
        .stateIn(viewModelScope, SharingStarted.Lazily, true)

    /** 每秒跳動一次，令燈號與倒數即時更新（不需重新抓取資料）。 */
    private val _tick = MutableStateFlow(0L)
    val tick: StateFlow<Long> = _tick.asStateFlow()

    private var polling: Job? = null

    init {
        if (initialStopKey != null) select(initialStopKey)
        startTicker()
    }

    private fun startTicker() {
        viewModelScope.launch {
            while (true) {
                _tick.value = TimeUtil.now().toEpochMilli()
                delay(TICK_MS)
            }
        }
    }

    fun select(stopKey: String) {
        _stopKey.value = stopKey
        viewModelScope.launch {
            val entity: StopEntity? = container.database.stopDao().get(stopKey)
            _stopName.value = entity?.nameTc ?: stopKey.substringAfter("|")
        }
        startPolling(stopKey)
    }

    private fun startPolling(stopKey: String) {
        polling?.cancel()
        polling = viewModelScope.launch {
            while (true) {
                refresh(stopKey)
                delay(REFRESH_MS)
            }
        }
    }

    suspend fun refresh(stopKey: String = _stopKey.value ?: return) {
        _loading.value = true
        _error.value = null
        try {
            val result = container.etaRepository.fetchBoard(stopKey)
            _boards.value = result
            _updatedAt.value = TimeUtil.now().toEpochMilli()
        } catch (e: Exception) {
            _error.value = e.message ?: "未能取得即時資料"
        } finally {
            _loading.value = false
        }
    }

    fun manualRefresh() {
        viewModelScope.launch { refresh() }
    }

    /** 供 UI 直接取得某條路線的燈號。 */
    fun signalOf(board: StopEtaBoard) = signalFor(board)

    fun minutesOf(board: StopEtaBoard) =
        board.entries.firstOrNull()?.let { SignalLightEngine.minutesBetween(TimeUtil.now(), it.eta) }

    override fun onCleared() {
        polling?.cancel()
        super.onCleared()
    }

    companion object {
        const val REFRESH_MS = 15_000L
        const val TICK_MS = 1_000L
    }
}
