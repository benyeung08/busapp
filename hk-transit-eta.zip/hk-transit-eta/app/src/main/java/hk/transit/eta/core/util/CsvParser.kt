package hk.transit.eta.core.util

import java.security.MessageDigest

object Fingerprint {

    /** 以 SHA-1 產生穩定指紋，用作每日比對路線／車站是否有變動。 */
    fun of(vararg parts: Any?): String {
        val joined = parts.joinToString("|") { it?.toString().orEmpty() }
        val bytes = MessageDigest.getInstance("SHA-1").digest(joined.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }
}

object CsvParser {

    /**
     * 極簡 CSV 解析器：支援雙引號包裹、引號內逗號、引號轉義（""）。
     * 足以應付運輸署與港鐵的公開 CSV。
     */
    fun parse(text: String, delimiter: Char = ',', skipHeader: Boolean = true): List<List<String>> {
        val rows = mutableListOf<List<String>>()
        var row = mutableListOf<String>()
        val field = StringBuilder()
        var inQuotes = false
        var i = 0
        while (i < text.length) {
            val c = text[i]
            when {
                inQuotes -> {
                    when {
                        c == '"' -> {
                            if (i + 1 < text.length && text[i + 1] == '"') {
                                field.append('"')
                                i++
                            } else inQuotes = false
                        }
                        else -> field.append(c)
                    }
                }
                c == '"' -> inQuotes = true
                c == delimiter -> {
                    row.add(field.toString().trim())
                    field.setLength(0)
                }
                c == '\n' -> {
                    row.add(field.toString().trim())
                    if (row.any { it.isNotBlank() }) rows.add(row)
                    row = mutableListOf()
                }
                c == '\r' -> Unit
                else -> field.append(c)
            }
            i++
        }
        row.add(field.toString().trim())
        if (row.any { it.isNotBlank() }) rows.add(row)

        if (rows.isEmpty()) return emptyList()
        return if (skipHeader) rows.drop(1) else rows
    }

    /** 解析成「欄名 → 值」的 Map，方便按欄位名稱取值。 */
    fun parseWithHeader(text: String, delimiter: Char = ','): List<Map<String, String>> {
        val rows = parse(text, delimiter, skipHeader = false)
        if (rows.size < 2) return emptyList()
        val header = rows.first().map { it.trim().removePrefix("\uFEFF") }
        return rows.drop(1).map { cells ->
            header.indices.associate { idx -> header[idx] to cells.getOrElse(idx) { "" } }
        }
    }

    /**
     * 串流解析：每讀完一列就呼叫 [onRow]，不保留任何一列。
     *
     * ⚠️ 運輸署 RSTOP_BUS.csv 約有二十多萬列。若用 [parseWithHeader] 一口氣轉成
     * 二十萬個 Map，再加上原始的 List<List<String>>，峰值記憶體可超過 200MB，
     * 在低階裝置的背景同步中很容易 OOM。此函式逐列交付，
     * 呼叫方可累積到固定筆數就寫入資料庫並清空，峰值記憶體維持在常數級別。
     *
     * @param onHeader 收到表頭時呼叫一次（欄名已去除 BOM 與前後空白）
     * @param onRow    每列資料；回傳 false 可提前中止
     */
    fun streamRows(
        text: String,
        delimiter: Char = ',',
        onHeader: (List<String>) -> Unit,
        onRow: (List<String>) -> Boolean
    ) {
        val row = mutableListOf<String>()
        val field = StringBuilder()
        var inQuotes = false
        var isHeader = true
        var i = 0
        val n = text.length

        fun endField() {
            row.add(field.toString().trim())
            field.setLength(0)
        }

        fun endRow(): Boolean {
            endField()
            val keepGoing = if (row.any { it.isNotBlank() }) {
                if (isHeader) {
                    onHeader(row.map { it.trim().removePrefix("\uFEFF") })
                    isHeader = false
                    true
                } else {
                    onRow(row)
                }
            } else true
            row.clear()
            return keepGoing
        }

        while (i < n) {
            val c = text[i]
            when {
                inQuotes -> {
                    when {
                        c == '"' -> {
                            if (i + 1 < n && text[i + 1] == '"') {
                                field.append('"')
                                i++
                            } else inQuotes = false
                        }
                        else -> field.append(c)
                    }
                }
                c == '"' -> inQuotes = true
                c == delimiter -> endField()
                c == '\n' -> if (!endRow()) return
                c == '\r' -> Unit
                else -> field.append(c)
            }
            i++
        }
        endRow()
    }
}
