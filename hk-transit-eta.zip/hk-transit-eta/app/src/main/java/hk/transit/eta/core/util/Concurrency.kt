package hk.transit.eta.core.util

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.joinAll
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * 以「固定並行度」對大量項目執行非同步工作。
 *
 * 背景：城巴與專線小巴的官方 API 沒有提供整批車站／站序的端點，
 * 必須逐條路線呼叫（城巴約一千次、小巴約一千八百次）。
 * 若以循序方式發出，每日同步會耗時數分鐘甚至逾時；
 * 若全部同時發出，則會對政府 API 造成突發壓力並容易觸發 429。
 *
 * 這裡改用 `Dispatchers.IO.limitedParallelism(n)`，
 * 既借用 IO 執行緒池，又把同時在飛的請求數限制在 n 個。
 */
@OptIn(ExperimentalCoroutinesApi::class)
suspend fun <T, R> Collection<T>.mapParallel(
    parallelism: Int = DEFAULT_PARALLELISM,
    transform: suspend (T) -> R
): List<R> = withContext(Dispatchers.IO.limitedParallelism(parallelism.coerceAtLeast(1))) {
    map { item -> async { transform(item) } }.awaitAll()
}

@OptIn(ExperimentalCoroutinesApi::class)
suspend fun <T> Collection<T>.forEachParallel(
    parallelism: Int = DEFAULT_PARALLELISM,
    action: suspend (T) -> Unit
) {
    withContext(Dispatchers.IO.limitedParallelism(parallelism.coerceAtLeast(1))) {
        map { item -> launch { action(item) } }.joinAll()
    }
}

/** 分塊並行：每塊完成後即回呼，適合需要分批寫入資料庫的場景。 */
@OptIn(ExperimentalCoroutinesApi::class)
suspend fun <T, R> Collection<T>.mapParallelChunked(
    chunkSize: Int = 200,
    parallelism: Int = DEFAULT_PARALLELISM,
    transform: suspend (T) -> R,
    onChunk: suspend (List<R>) -> Unit
) {
    chunked(chunkSize).forEach { chunk ->
        onChunk(chunk.mapParallel(parallelism, transform))
    }
}

/** 對政府 API 的預設同時請求數。刻意保守，避免被視為濫用。 */
const val DEFAULT_PARALLELISM = 8
