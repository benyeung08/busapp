package hk.transit.eta.data.remote.dto

import com.google.gson.annotations.SerializedName

/**
 * 共通注意事項：
 *
 * Gson 以 Unsafe 直接配置物件，**不會**執行 Kotlin 建構函式，
 * 因此當 JSON 缺少某欄位時，Kotlin 的預設值（例如 `= emptyList()`）不會生效，
 * 欄位會保持 null。故所有集合欄位一律宣告為可空（nullable），
 * 並由呼叫端以 `.orEmpty()` 取值，避免 `NullPointerException`。
 */

// =====================================================================
// 九巴／龍運（data.etabus.gov.hk）
// =====================================================================

data class KmbRouteDto(
    @SerializedName("route") val route: String,
    @SerializedName("bound") val bound: String,
    @SerializedName("service_type") val serviceType: Int,
    @SerializedName("orig_tc") val origTc: String,
    @SerializedName("orig_en") val origEn: String,
    @SerializedName("orig_sc") val origSc: String,
    @SerializedName("dest_tc") val destTc: String,
    @SerializedName("dest_en") val destEn: String,
    @SerializedName("dest_sc") val destSc: String,
    @SerializedName("data_timestamp") val dataTimestamp: String?
)

data class KmbStopDto(
    @SerializedName("stop") val stop: String,
    @SerializedName("name_tc") val nameTc: String,
    @SerializedName("name_en") val nameEn: String,
    @SerializedName("name_sc") val nameSc: String,
    @SerializedName("lat") val lat: String,
    @SerializedName("long") val lng: String,
    @SerializedName("data_timestamp") val dataTimestamp: String?
)

data class KmbRouteStopDto(
    @SerializedName("route") val route: String,
    @SerializedName("bound") val bound: String,
    @SerializedName("service_type") val serviceType: Int,
    @SerializedName("seq") val seq: Int,
    @SerializedName("stop") val stop: String
)

data class KmbEtaDto(
    @SerializedName("route") val route: String,
    @SerializedName("service_type") val serviceType: Int,
    @SerializedName("seq") val seq: Int,
    @SerializedName("stop") val stop: String,
    @SerializedName("dir") val dir: String,
    @SerializedName("co") val co: String,
    @SerializedName("eta") val eta: String?,
    @SerializedName("dest_tc") val destTc: String,
    @SerializedName("dest_en") val destEn: String,
    @SerializedName("rmk_tc") val rmkTc: String?,
    @SerializedName("rmk_en") val rmkEn: String?,
    @SerializedName("eta_seq") val etaSeq: String?,
    @SerializedName("data_timestamp") val dataTimestamp: String?
)

// =====================================================================
// 城巴（rt.data.gov.hk/v2/transport/citybus）
// =====================================================================

data class CtbRouteDto(
    @SerializedName("route") val route: String,
    @SerializedName("bound") val bound: String,
    @SerializedName("service_type") val serviceType: Int,
    @SerializedName("orig_tc") val origTc: String,
    @SerializedName("orig_en") val origEn: String,
    @SerializedName("dest_tc") val destTc: String,
    @SerializedName("dest_en") val destEn: String,
    @SerializedName("data_timestamp") val dataTimestamp: String?
)

data class CtbStopDto(
    @SerializedName("stop") val stop: String,
    @SerializedName("name_tc") val nameTc: String,
    @SerializedName("name_en") val nameEn: String,
    @SerializedName("lat") val lat: String,
    @SerializedName("long") val lng: String,
    @SerializedName("data_timestamp") val dataTimestamp: String?
)

data class CtbRouteStopDto(
    @SerializedName("stop") val stop: String,
    @SerializedName("seq") val seq: Int
)

data class CtbEtaDto(
    @SerializedName("route") val route: String,
    @SerializedName("dir") val dir: String,
    @SerializedName("seq") val seq: Int,
    @SerializedName("stop") val stop: String,
    @SerializedName("co") val co: String,
    @SerializedName("eta") val eta: String?,
    @SerializedName("rmk_tc") val rmkTc: String?,
    @SerializedName("rmk_en") val rmkEn: String?,
    @SerializedName("dest_tc") val destTc: String,
    @SerializedName("dest_en") val destEn: String,
    @SerializedName("data_timestamp") val dataTimestamp: String?
)

// =====================================================================
// 新大嶼山巴士（rt.data.gov.hk/v2/transport/nlb）
// =====================================================================

data class NlbRouteListDto(
    @SerializedName("routes") val routes: List<NlbRouteDto>? = null
)

data class NlbRouteDto(
    @SerializedName("routeId") val routeId: String,
    @SerializedName("routeNo") val routeNo: String,
    @SerializedName("routeName_c") val routeNameC: String,
    @SerializedName("routeName_e") val routeNameE: String
)

data class NlbStopListDto(
    @SerializedName("stops") val stops: List<NlbStopDto>? = null
)

data class NlbStopDto(
    @SerializedName("stopId") val stopId: String,
    @SerializedName("stopName_c") val stopNameC: String,
    @SerializedName("stopName_e") val stopNameE: String,
    @SerializedName("latitude") val latitude: String?,
    @SerializedName("longitude") val longitude: String?
)

data class NlbEtaDto(
    @SerializedName("estimatedArrivals") val estimatedArrivals: List<NlbArrivalDto>? = null
)

data class NlbArrivalDto(
    @SerializedName("routeId") val routeId: String,
    @SerializedName("stopId") val stopId: String,
    @SerializedName("eta") val eta: String?,
    @SerializedName("isScheduled") val isScheduled: String?,
    @SerializedName("remark_c") val remarkC: String?
)

// =====================================================================
// 專線小巴（data.etagmb.gov.hk）
// =====================================================================

data class GmbRouteListDto(
    @SerializedName("route_code") val routeCode: String,
    @SerializedName("route_id") val routeId: String,
    @SerializedName("region") val region: String
)

data class GmbRouteDetailDto(
    @SerializedName("route_id") val routeId: String,
    @SerializedName("route_code") val routeCode: String,
    @SerializedName("directions") val directions: List<GmbDirectionDto>? = null
)

data class GmbDirectionDto(
    @SerializedName("route_seq") val routeSeq: Int,
    @SerializedName("orig_tc") val origTc: String?,
    @SerializedName("orig_en") val origEn: String?,
    @SerializedName("dest_tc") val destTc: String?,
    @SerializedName("dest_en") val destEn: String?,
    @SerializedName("description_tc") val descriptionTc: String?,
    @SerializedName("description_en") val descriptionEn: String?
)

data class GmbStopDto(
    @SerializedName("stop_id") val stopId: String,
    @SerializedName("name_tc") val nameTc: String,
    @SerializedName("name_en") val nameEn: String,
    @SerializedName("latitude") val latitude: String?,
    @SerializedName("longitude") val longitude: String?
)

data class GmbRouteStopDto(
    @SerializedName("stop_seq") val stopSeq: Int,
    @SerializedName("stop_id") val stopId: String,
    @SerializedName("name_tc") val nameTc: String?,
    @SerializedName("name_en") val nameEn: String?,
    @SerializedName("latitude") val latitude: String?,
    @SerializedName("longitude") val longitude: String?
)

data class GmbEtaDto(
    @SerializedName("route_id") val routeId: String?,
    @SerializedName("route_code") val routeCode: String?,
    @SerializedName("route_seq") val routeSeq: Int?,
    @SerializedName("stop_id") val stopId: String?,
    @SerializedName("stop_seq") val stopSeq: Int?,
    @SerializedName("enabled") val enabled: Boolean?,
    @SerializedName("eta") val eta: List<GmbEtaItemDto>? = null,
    @SerializedName("description_tc") val descriptionTc: String?,
    @SerializedName("description_en") val descriptionEn: String?,
    @SerializedName("remarks_tc") val remarksTc: String?,
    @SerializedName("remarks_en") val remarksEn: String?
)

data class GmbEtaItemDto(
    @SerializedName("timestamp") val timestamp: String?,
    @SerializedName("remarks_tc") val remarksTc: String?,
    @SerializedName("remarks_en") val remarksEn: String?
)

// =====================================================================
// 輕鐵（rt.data.gov.hk/v1/transport/mtr/lrt/getSchedule）
// =====================================================================

data class LightRailScheduleDto(
    @SerializedName("status") val status: Int?,
    @SerializedName("system_time") val systemTime: String?,
    @SerializedName("platform_list") val platformList: List<LightRailPlatformDto>? = null
)

data class LightRailPlatformDto(
    @SerializedName("platform_id") val platformId: Int?,
    @SerializedName("route_list") val routeList: List<LightRailTrainDto>? = null
)

data class LightRailTrainDto(
    @SerializedName("train_length") val trainLength: Int?,
    @SerializedName("arrival_departure") val arrivalDeparture: String?,
    @SerializedName("dest_en") val destEn: String?,
    @SerializedName("dest_ch") val destCh: String?,
    @SerializedName("time_en") val timeEn: String?,
    @SerializedName("time_ch") val timeCh: String?,
    @SerializedName("route_no") val routeNo: String?,
    @SerializedName("stop") val stop: Int?
)

// =====================================================================
// 港鐵巴士／接駁巴士（POST rt.data.gov.hk/v1/transport/mtr/bus/getSchedule）
// 依 MTR Bus API Specification v1.13
// =====================================================================

data class MtrBusScheduleDto(
    @SerializedName("routeName") val routeName: String? = null,
    /**
     * 系統狀態碼（官方數據字典）："1" ＝ 正常，"0" ＝ 錯誤或警示。
     * 不是 "1" 時代表這次回應不可信，應視為查無資料。
     */
    @SerializedName("status") val status: String? = null,
    /** 官方建議的重新整理間隔（秒）。 */
    @SerializedName("appRefreshTimeInSecond") val appRefreshTimeInSecond: String? = null,
    @Deprecated("官方數據字典已標示為 Deprecated")
    @SerializedName("routeStatus") val routeStatus: String? = null,
    @Deprecated("官方數據字典已標示為 Deprecated")
    @SerializedName("routeStatusRemarkContent") val routeStatusRemarkContent: String? = null,
    @SerializedName("busStop") val busStop: List<MtrBusStopDto>? = null
)

data class MtrBusStopDto(
    /** 查即時到站的唯一鍵；格式由伺服器決定，不可自行拼湊。 */
    @SerializedName("busStopId") val busStopId: String? = null,
    @Deprecated("官方數據字典已標示為 Deprecated")
    @SerializedName("busStopStatus") val busStopStatus: String? = null,
    @Deprecated("官方數據字典已標示為 Deprecated")
    @SerializedName("busStopRemark") val busStopRemark: String? = null,
    @Deprecated("官方數據字典已標示為 Deprecated")
    @SerializedName("busStopStatusRemarkContent") val busStopStatusRemarkContent: String? = null,
    @Deprecated("官方數據字典已標示為 Deprecated")
    @SerializedName("busStopStatusTime") val busStopStatusTime: String? = null,
    @SerializedName("busIcon") val busIcon: String? = null,
    /** 停靠此站的班次；無班次時為空陣列（屬正常情況，非錯誤）。 */
    @SerializedName("bus") val bus: List<MtrBusDto>? = null
)

data class MtrBusDto(
    @SerializedName("busId") val busId: String? = null,
    /** 抵站剩餘秒數（官方文件指出此值目前為佔位，應以 departureTimeInSecond 為準）。 */
    @SerializedName("arrivalTimeInSecond") val arrivalTimeInSecond: String? = null,
    /** 開出剩餘秒數 —— 實際可用的到站時間。 */
    @SerializedName("departureTimeInSecond") val departureTimeInSecond: String? = null,
    @SerializedName("departureTimeText") val departureTimeText: String? = null,
    @SerializedName("arrivalTimeText") val arrivalTimeText: String? = null,
    @SerializedName("isDelayed") val isDelayed: String? = null,
    /**
     * 預報是否以班次表為基礎：
     * "1" ＝ 依班次表推算（非實時），"0" ＝ 依實時位置。
     * 為 "1" 時介面須標示「推算」。
     */
    @SerializedName("isScheduled") val isScheduled: String? = null,
    @SerializedName("lineRef") val lineRef: String? = null,
    @Deprecated("官方數據字典已標示為 Deprecated")
    @SerializedName("busRemark") val busRemark: String? = null,
    @SerializedName("busLocation") val busLocation: MtrBusLocationDto? = null
)

data class MtrBusLocationDto(
    @SerializedName("latitude") val latitude: Double? = null,
    @SerializedName("longitude") val longitude: Double? = null
)
