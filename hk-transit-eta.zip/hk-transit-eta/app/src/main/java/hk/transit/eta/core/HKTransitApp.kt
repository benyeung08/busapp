package hk.transit.eta.core

import android.app.Application
import hk.transit.eta.core.di.AppContainer
import hk.transit.eta.worker.SyncScheduler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class HKTransitApp : Application() {

    val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    override fun onCreate() {
        super.onCreate()
        AppContainer.init(this)

        // 每次啟動都重新排程，確保每日更新不會因升級或重開機而中斷
        SyncScheduler.scheduleAll(this)

        // 首次啟動（或資料為空）時立即同步一次
        applicationScope.launch {
            val container = AppContainer.get(this@HKTransitApp)
            val routeCount = container.database.routeDao().count()
            if (routeCount == 0) {
                SyncScheduler.syncNow(this@HKTransitApp)
            }
        }
    }
}
