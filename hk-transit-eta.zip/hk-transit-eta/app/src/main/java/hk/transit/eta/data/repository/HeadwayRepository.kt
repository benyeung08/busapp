package hk.transit.eta.data.repository

import hk.transit.eta.core.util.CsvParser
import hk.transit.eta.core.util.TimeUtil
import hk.transit.eta.data.local.UserPreferences
import hk.transit.eta.data.local.db.AppDatabase
import hk.transit.eta.data.local.db.HeadwayEntity
import hk.transit.eta.data.local.db.RouteEntity
import hk.transit.eta.data.local.db.SyncLogEntity
import hk.transit.eta.data.remote.ApiConstants
import hk.transit.eta.data.remote.NetworkClient
import hk.transit.eta.domain.model.Operator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * 運輸署「公共交通服務班次資料」（GTFS 格式）。
 *
 * 這是全港唯一涵蓋巴士、小巴、港鐵巴士等「班次時間表」的公開資料，
 * 用於：
 *  - 沒有即時到站資料時推算到站時間（介面標示「推算」）
 *  - 天氣影響時對比「正常班次」與「受影響班次」
 */
class HeadwayRepository(
    private val database: AppDatabase,
    private val prefs: UserPreferences
) {

    private val static = NetworkClient.static()

    suspend fun sync(): Int = withContext(Dispatchers.IO) {
        val routesCsv = download(ApiConstants.TD_HEADWAY_ROUTES)
        val tripsCsv = download(ApiConstants.TD_HEADWAY_TRIPS)
        val frequenciesCsv = download(ApiConstants.TD_HEADWAY_FREQUENCIES)
        if (routesCsv.isBlank() || tripsCsv.isBlank() || frequenciesCsv.isBlank()) {
            database.syncLogDao().upsert(
                SyncLogEntity(
                    kind = KIND_HEADWAY,
                    lastSyncAt = System.currentTimeMillis(),
                    itemCount = 0,
                    success = false,
                    message = "班次資料下載失敗"
                )
            )
            return@withContext 0
        }

        val gtfsRoutes = CsvParser.parseWithHeader(routesCsv)
        val trips = CsvParser.parseWithHeader(tripsCsv)
        val frequencies = CsvParser.parseWithHeader(frequenciesCsv)

        // route_id → (route_short_name, agency_id)
        val routeMeta = gtfsRoutes.associate { row ->
            row["route_id"].orEmpty() to Pair(
                row["route_short_name"].orEmpty().trim(),
                row["agency_id"].orEmpty().trim()
            )
        }
        // trip_id → (route_id, direction_id, service_id)
        val tripMeta = trips.associate { row ->
            row["trip_id"].orEmpty() to Triple(
                row["route_id"].orEmpty(),
                row["direction_id"]?.toIntOrNull() ?: 0,
                row["service_id"].orEmpty()
            )
        }

        // 以路線號＋營辦商對應到本機的 routeKey
        val localRoutes = database.routeDao().byOperators(Operator.entries.map { it.code })
        val byNumber = localRoutes.groupBy { it.routeNo.uppercase() }

        val entities = mutableListOf<HeadwayEntity>()
        for (row in frequencies) {
            val tripId = row["trip_id"].orEmpty()
            val (routeId, directionId, serviceId) = tripMeta[tripId] ?: continue
            val (shortName, _) = routeMeta[routeId] ?: continue
            if (shortName.isBlank()) continue
            val headway = row["headway_secs"]?.toIntOrNull() ?: continue
            if (headway <= 0) continue

            val matches: List<RouteEntity> = byNumber[shortName.uppercase()].orEmpty()
                .ifEmpty {
                    // 部分路線號在官方目錄中帶有額外前綴，改用「包含」比對
                    localRoutes.filter { it.routeNo.uppercase().contains(shortName.uppercase()) }
                }
            if (matches.isEmpty()) continue

            for (match in matches) {
                val operator = Operator.fromCode(match.operatorCode) ?: continue
                entities += HeadwayEntity(
                    routeKey = match.routeKey,
                    routeNo = match.routeNo,
                    operatorCode = operator.code,
                    startTime = row["start_time"].orEmpty(),
                    endTime = row["end_time"].orEmpty(),
                    headwaySecs = headway,
                    serviceId = serviceId,
                    directionId = directionId
                )
            }
            if (entities.size > 200_000) break
        }

        database.headwayDao().clear()
        entities.chunked(2000).forEach { chunk -> database.headwayDao().upsertAll(chunk) }

        database.syncLogDao().upsert(
            SyncLogEntity(
                kind = KIND_HEADWAY,
                lastSyncAt = System.currentTimeMillis(),
                itemCount = entities.size,
                success = true,
                message = null
            )
        )
        prefs.lastHeadwaySync = TimeUtil.now().toEpochMilli()
        entities.size
    }

    private suspend fun download(path: String): String = try {
        static.raw("${ApiConstants.TD_STATIC_BASE}$path").string()
    } catch (e: Exception) {
        ""
    }

    companion object {
        const val KIND_HEADWAY = "headway"
    }
}
