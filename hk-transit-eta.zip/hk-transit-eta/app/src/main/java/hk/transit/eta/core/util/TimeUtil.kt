package hk.transit.eta.core.util

import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.time.format.DateTimeParseException

/** 香港時間（資料一線通所有時間戳均為 HKT）。 */
val HKT: ZoneId = ZoneId.of("Asia/Hong_Kong")

object TimeUtil {

    private val dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")
    private val timeFormatter = DateTimeFormatter.ofPattern("HH:mm")
    private val dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")

    fun now(): Instant = Instant.now()

    fun today(): String = LocalDate.now(HKT).format(dateFormatter)

    fun today(zone: ZoneId): String = LocalDate.now(zone).format(dateFormatter)

    fun todayDate(): LocalDate = LocalDate.now(HKT)

    fun formatDate(instant: Instant?): String =
        instant?.atZone(HKT)?.format(dateFormatter) ?: "—"

    fun formatTime(instant: Instant?): String =
        instant?.atZone(HKT)?.format(timeFormatter) ?: "—"

    fun formatDateTime(instant: Instant?): String =
        instant?.atZone(HKT)?.format(dateTimeFormatter) ?: "—"

    /** 供 SQL LIKE 使用的當日字首（yyyy-MM-dd）。 */
    fun dateKey(instant: Instant): String = instant.atZone(HKT).format(dateFormatter)

    fun atStartOfToday(): Long = LocalDate.now(HKT).atStartOfDay(HKT).toInstant().toEpochMilli()

    fun fromEpochMillis(millis: Long?): Instant? = millis?.let { Instant.ofEpochMilli(it) }

    fun toEpochMillis(instant: Instant?): Long? = instant?.toEpochMilli()

    /**
     * 解析政府 API 常見時間格式：
     *  - 2023-07-01T11:40:48+08:00（ISO_OFFSET_DATE_TIME）
     *  - 2023-07-01T11:40:48.072+08:00（含毫秒）
     *  - 2021-02-26 11:15:51（輕鐵 system_time）
     */
    fun parseFlexible(raw: String?): Instant? {
        if (raw.isNullOrBlank()) return null
        val trimmed = raw.trim()
        return try {
            Instant.parse(trimmed)
        } catch (_: DateTimeParseException) {
            try {
                ZonedDateTime.parse(trimmed, DateTimeFormatter.ISO_OFFSET_DATE_TIME).toInstant()
            } catch (_: DateTimeParseException) {
                try {
                    LocalDateTime.parse(
                        trimmed.replace(" ", "T"),
                        DateTimeFormatter.ISO_LOCAL_DATE_TIME
                    ).atZone(HKT).toInstant()
                } catch (_: DateTimeParseException) {
                    null
                }
            }
        }
    }

    /** 由「HH:mm:ss」或「HH:mm」轉成今日（或翌日）的 Instant。 */
    fun todayAt(hhmm: String): Instant? {
        val parts = hhmm.split(":")
        if (parts.isEmpty()) return null
        val hour = parts.getOrNull(0)?.toIntOrNull() ?: return null
        val minute = parts.getOrNull(1)?.toIntOrNull() ?: 0
        val second = parts.getOrNull(2)?.toIntOrNull() ?: 0
        // GTFS 允許 24:00:00 之後的時間表示翌日
        return LocalDate.now(HKT)
            .atStartOfDay(HKT)
            .plusHours(hour.toLong())
            .plusMinutes(minute.toLong())
            .plusSeconds(second.toLong())
            .toInstant()
    }

    /** 判斷某時間是否落在 [start, end) 區間內（同一天）。 */
    fun isWithin(now: Instant, start: Instant, end: Instant): Boolean =
        !now.isBefore(start) && now.isBefore(end)
}
