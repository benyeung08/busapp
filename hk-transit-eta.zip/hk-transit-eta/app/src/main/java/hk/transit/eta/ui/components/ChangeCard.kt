package hk.transit.eta.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import hk.transit.eta.core.util.TimeUtil
import hk.transit.eta.domain.model.ChangeType
import hk.transit.eta.domain.model.DailyChange
import hk.transit.eta.ui.theme.SignalAmber
import hk.transit.eta.ui.theme.SignalGreen
import hk.transit.eta.ui.theme.SignalRed

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ChangeCard(
    change: DailyChange,
    modifier: Modifier = Modifier,
    expandedByDefault: Boolean = false
) {
    var expanded by remember(change.id) { mutableStateOf(expandedByDefault) }
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        onClick = { expanded = !expanded }
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                ChangeTypeChip(change.changeType)
                Spacer(Modifier.weight(1f))
                Text(
                    text = change.operator.labelTc,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Spacer(Modifier.height(8.dp))
            Text(
                text = change.title,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold
            )
            if (expanded) {
                Spacer(Modifier.height(8.dp))
                Text(
                    text = change.detail,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (change.affectedStops.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        change.affectedStops.take(12).forEach { stop ->
                            Surface(
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                shape = MaterialTheme.shapes.small
                            ) {
                                Text(
                                    text = stop,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                    style = MaterialTheme.typography.labelMedium
                                )
                            }
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                change.effectiveFrom?.let {
                    Text(
                        text = "生效時間：${TimeUtil.formatDateTime(it)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                change.resumedAt?.let {
                    Text(
                        text = "已於 ${TimeUtil.formatDateTime(it)} 恢復",
                        style = MaterialTheme.typography.bodySmall,
                        color = SignalGreen
                    )
                }
                Text(
                    text = "來源：${change.source.labelTc}${if (change.isEstimate) "（推算）" else ""}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun ChangeTypeChip(type: ChangeType) {
    val (background, foreground) = when (type) {
        ChangeType.ADDED -> SignalGreen.copy(alpha = 0.14f) to SignalGreen
        ChangeType.REMOVED -> SignalRed.copy(alpha = 0.14f) to SignalRed
        ChangeType.DIVERSION -> SignalAmber.copy(alpha = 0.16f) to SignalAmber
        ChangeType.WEATHER -> Color(0xFF0277BD).copy(alpha = 0.14f) to Color(0xFF0277BD)
        ChangeType.RESTORED -> SignalGreen.copy(alpha = 0.18f) to SignalGreen
        ChangeType.MODIFIED -> MaterialTheme.colorScheme.surfaceVariant to MaterialTheme.colorScheme.onSurfaceVariant
    }
    Surface(color = background, shape = MaterialTheme.shapes.small) {
        Text(
            text = type.labelTc,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
            style = MaterialTheme.typography.labelMedium,
            color = foreground
        )
    }
}

/** 天氣警告橫幅，顯示於首頁與到站頁頂部。 */
@Composable
fun WeatherBanner(
    warningName: String,
    affectedRouteCount: Int,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = SignalAmber.copy(alpha = 0.14f)
        ),
        onClick = { onClick?.invoke() }
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "⚠ $warningName",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = SignalAmber
                )
                Text(
                    text = "受影響路線 $affectedRouteCount 條",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
