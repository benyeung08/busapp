package hk.transit.eta.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import hk.transit.eta.core.di.AppContainer
import hk.transit.eta.core.util.TimeUtil
import hk.transit.eta.data.repository.toDomain
import hk.transit.eta.domain.model.ChangeType
import hk.transit.eta.domain.model.DailyChange
import hk.transit.eta.domain.model.Mode
import hk.transit.eta.domain.model.Operator
import hk.transit.eta.domain.model.RouteInfo
import hk.transit.eta.domain.model.StopInfo
import hk.transit.eta.domain.model.WeatherImpactSummary
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** 首頁：搜尋路線／車站、顯示今日變動與天氣摘要。 */
class HomeViewModel(private val container: AppContainer) : ViewModel() {

    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query.asStateFlow()

    private val _mode = MutableStateFlow(Mode.BUS)
    val mode: StateFlow<Mode> = _mode.asStateFlow()

    private val _routes = MutableStateFlow<List<RouteInfo>>(emptyList())
    val routes: StateFlow<List<RouteInfo>> = _routes.asStateFlow()

    private val _stops = MutableStateFlow<List<StopInfo>>(emptyList())
    val stops: StateFlow<List<StopInfo>> = _stops.asStateFlow()

    private val _changeCount = MutableStateFlow(0)
    val changeCount: StateFlow<Int> = _changeCount.asStateFlow()

    private val _weatherSummary = MutableStateFlow<WeatherImpactSummary?>(null)
    val weatherSummary: StateFlow<WeatherImpactSummary?> = _weatherSummary.asStateFlow()

    private val _lastSync = MutableStateFlow(0L)
    val lastSync: StateFlow<Long> = _lastSync.asStateFlow()

    private val _syncing = MutableStateFlow(false)
    val syncing: StateFlow<Boolean> = _syncing.asStateFlow()

    init {
        refreshSummary()
        search("")
    }

    fun onQueryChange(value: String) {
        _query.value = value
        search(value)
    }

    fun onModeChange(mode: Mode) {
        _mode.value = mode
        search(_query.value)
    }

    private fun search(value: String) {
        viewModelScope.launch {
            val q = if (value.isBlank()) "%" else "%$value%"
            val mode = _mode.value
            val codes = mode.operators()
            val (routeEntities, stopEntities) = withContext(Dispatchers.IO) {
                container.database.routeDao().search(q, codes, 100) to
                    container.database.stopDao().search(q, codes, 100)
            }
            _routes.value = routeEntities.map { it.toDomain() }
            _stops.value = stopEntities.map { it.toDomain() }
        }
    }

    /** 點選路線時，直接開啟該路線的起點站燈號畫面。 */
    suspend fun firstStopOf(routeKey: String): String? = withContext(Dispatchers.IO) {
        container.database.routeStopDao().ofRoute(routeKey)
            .minByOrNull { it.stopSeq }?.stopKey
    }

    fun refreshSummary() {
        viewModelScope.launch {
            val date = TimeUtil.today()
            withContext(Dispatchers.IO) {
                _changeCount.value = container.database.dailyChangeDao().countByDate(date)
            }
            _weatherSummary.value = container.weatherRepository.summaryOf(date)
            _lastSync.value = container.preferences.lastCatalogueSync
        }
    }

    fun syncNow(onDone: () -> Unit = {}) {
        viewModelScope.launch {
            _syncing.value = true
            try {
                hk.transit.eta.worker.SyncScheduler.syncNow(container.appContext)
                onDone()
            } finally {
                _syncing.value = false
            }
        }
    }

    private fun Mode.operators(): Set<String> = when (this) {
        Mode.BUS -> setOf(Operator.KMB.code, Operator.CTB.code, Operator.NLB.code, Operator.MTR_BUS.code)
        Mode.MINIBUS -> setOf(Operator.GMB.code)
        Mode.HEAVY_RAIL -> setOf(Operator.MTR_HR.code)
        Mode.LIGHT_RAIL -> setOf(Operator.MTR_LR.code)
    }
}

/** 今日變動：可依類型篩選。 */
class ChangesViewModel(private val container: AppContainer) : ViewModel() {

    private val _changes = MutableStateFlow<List<DailyChange>>(emptyList())
    val changes: StateFlow<List<DailyChange>> = _changes.asStateFlow()

    private val _filter = MutableStateFlow<ChangeType?>(null)
    val filter: StateFlow<ChangeType?> = _filter.asStateFlow()

    private val _counts = MutableStateFlow<Map<ChangeType, Int>>(emptyMap())
    val counts: StateFlow<Map<ChangeType, Int>> = _counts.asStateFlow()

    private val _loading = MutableStateFlow(false)
    val loading: StateFlow<Boolean> = _loading.asStateFlow()

    init {
        load()
    }

    fun setFilter(type: ChangeType?) {
        _filter.value = type
        load()
    }

    fun load() {
        viewModelScope.launch {
            _loading.value = true
            val date = TimeUtil.today()
            val all = withContext(Dispatchers.IO) {
                container.database.dailyChangeDao().byDate(date).map { it.toDomain() }
            }
            _counts.value = all.groupBy { it.changeType }.mapValues { it.value.size }
            _changes.value = _filter.value?.let { type -> all.filter { it.changeType == type } } ?: all
            _loading.value = false
        }
    }
}

/** 天氣影響：警告、受影響路線、班次與恢復時間表。 */
class WeatherViewModel(private val container: AppContainer) : ViewModel() {

    private val _summary = MutableStateFlow<WeatherImpactSummary?>(null)
    val summary: StateFlow<WeatherImpactSummary?> = _summary.asStateFlow()

    private val _loading = MutableStateFlow(false)
    val loading: StateFlow<Boolean> = _loading.asStateFlow()

    val flashEnabled = container.preferences.flashEnabled
        .stateIn(viewModelScope, SharingStarted.Lazily, true)

    init {
        load()
    }

    fun load() {
        viewModelScope.launch {
            _loading.value = true
            _summary.value = container.weatherRepository.summaryOf(TimeUtil.today())
            _loading.value = false
        }
    }

    fun refresh() {
        viewModelScope.launch {
            _loading.value = true
            _summary.value = container.weatherRepository.sync(TimeUtil.today())
            _loading.value = false
        }
    }
}

/** 設定：自動更新、燈號閃爍、語言與立即更新。 */
class SettingsViewModel(private val container: AppContainer) : ViewModel() {

    val flashEnabled = container.preferences.flashEnabled
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), true)
    val autoUpdate = container.preferences.autoUpdate
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), true)
    val syncHour = container.preferences.syncHour
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 4)
    val language = container.preferences.language
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), "tc")

    private val _lastSync = MutableStateFlow(0L)
    val lastSync: StateFlow<Long> = _lastSync.asStateFlow()

    fun setFlash(enabled: Boolean) = container.preferences.setFlashEnabled(enabled)
    fun setAutoUpdate(enabled: Boolean) = container.preferences.setAutoUpdate(enabled)
    fun setSyncHour(hour: Int) = container.preferences.setSyncHour(hour)
    fun setLanguage(lang: String) = container.preferences.setLanguage(lang)

    fun refreshLastSync() {
        viewModelScope.launch { _lastSync.value = container.preferences.lastCatalogueSync }
    }

    suspend fun syncNow() {
        container.catalogueRepository.syncAll()
        container.newsRepository.sync()
        container.weatherRepository.sync()
        container.headwayRepository.sync()
        refreshLastSync()
    }

    val catalogueCount: StateFlow<Int> = flow {
        emit(withContext(Dispatchers.IO) { container.database.routeDao().count() })
    }.stateIn(viewModelScope, SharingStarted.Lazily, 0)
}
