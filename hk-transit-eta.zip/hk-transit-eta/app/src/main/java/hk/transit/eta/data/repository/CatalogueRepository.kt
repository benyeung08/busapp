package hk.transit.eta.data.repository

import hk.transit.eta.core.util.CsvParser
import hk.transit.eta.core.util.Fingerprint
import hk.transit.eta.core.util.HKT
import hk.transit.eta.core.util.TimeUtil
import hk.transit.eta.data.local.UserPreferences
import hk.transit.eta.data.local.db.AppDatabase
import hk.transit.eta.data.local.db.DailyChangeEntity
import hk.transit.eta.data.local.db.RouteEntity
import hk.transit.eta.data.local.db.RouteSnapshotEntity
import hk.transit.eta.data.local.db.RouteStopEntity
import hk.transit.eta.data.local.db.StopEntity
import hk.transit.eta.data.local.db.StopSnapshotEntity
import hk.transit.eta.data.local.db.SyncLogEntity
import hk.transit.eta.data.remote.ApiConstants
import hk.transit.eta.data.remote.MtrBusRequest
import hk.transit.eta.data.remote.NetworkClient
import hk.transit.eta.data.local.db.MtrBusStopMapEntity
import hk.transit.eta.domain.ChangeDetector
import hk.transit.eta.domain.model.Operator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext

/**
 * 路線／車站目錄的每日全自動更新。
 *
 * 分層設計：
 *  1. 運輸署靜態 CSV：全港巴士與小巴的完整目錄（用作「新增／取消／修改」比對）
 *  2. 各營辦商 API：有即時到站服務的路線與車站（用作燈號與即時查詢）
 *  3. 港鐵／輕鐵靜態 CSV：官方未有即時到站的路線資料，故以官方班次表為準
 */
class CatalogueRepository(
    private val database: AppDatabase,
    private val prefs: UserPreferences,
    private val datasetRepository: DatasetRepository = DatasetRepository(database, prefs)
) {

    private val kmb = NetworkClient.kmb()
    private val ctb = NetworkClient.ctb()
    private val nlb = NetworkClient.nlb()
    private val gmb = NetworkClient.gmb()
    private val mtr = NetworkClient.mtr()
    private val static = NetworkClient.static()
    private val td = TdStaticRepository()

    data class SyncSummary(
        val success: Boolean,
        val routeCount: Int,
        val stopCount: Int,
        val changeCount: Int,
        val messages: List<String>
    )

    suspend fun syncAll(onProgress: (String) -> Unit = {}): SyncSummary = withContext(Dispatchers.IO) {
        val messages = mutableListOf<String>()
        val date = TimeUtil.today()
        var ok = true

        suspend fun step(name: String, block: suspend () -> Int) {
            onProgress(name)
            val n = try {
                block()
            } catch (e: Exception) {
                ok = false
                messages += "$name 失敗：${e.message}"
                -1
            }
            if (n >= 0) messages += "$name：$n 筆"
        }

        // 優先使用 GitHub 後端資料集：目錄、站序、每日變動與港鐵巴士對照表
        // 都已在那裡算好，可省去在手機上解析數 MB 的 CSV。
        var fromDataset = false
        if (datasetRepository.isConfigured()) {
            onProgress("下載 GitHub 後端資料集")
            fromDataset = try {
                val r = datasetRepository.sync()
                messages += "後端資料集 v${r.version}：路線 ${r.routeCount}、" +
                    "車站 ${r.stopCount}、站序 ${r.routeStopCount}、" +
                    "變動 ${r.changeCount}、對照表 ${r.mtrBusMapCount}"
                true
            } catch (e: Exception) {
                // 後端不可用時退回直接下載，不讓同步整體失敗
                messages += "後端資料集失敗，改為直接下載：${e.message}"
                false
            }
        }

        if (fromDataset) {
            // 目錄與變動已由資料集提供，只需更新各營辦商的即時路線（供 ETA 查詢）
            step("下載運輸署官方更新記錄") { syncTdDeltas(date) }
            step("更新九巴／龍運即時路線") { syncKmb() }
            step("更新城巴即時路線") { syncCtb() }
            step("更新新大嶼山巴士即時路線") { syncNlb() }
            step("更新專線小巴即時路線") { syncGmb() }
            step("更新港鐵重鐵路線") { syncMtrHeavyRail() }
            step("更新輕鐵路線") { syncLightRail() }
        } else {
            step("下載運輸署路線目錄") { syncTdCatalogue() }
            step("下載運輸署官方更新記錄") { syncTdDeltas(date) }
            step("更新九巴／龍運即時路線") { syncKmb() }
            step("更新城巴即時路線") { syncCtb() }
            step("更新新大嶼山巴士即時路線") { syncNlb() }
            step("更新專線小巴即時路線") { syncGmb() }
            step("更新港鐵重鐵路線") { syncMtrHeavyRail() }
            step("更新輕鐵路線") { syncLightRail() }
            // 只有在沒有資料集時才需要自行建立港鐵巴士對照表
            step("更新港鐵巴士路線") { syncMtrBus() }
            step("比對今日變動") { commitChanges(date) }
        }

        val routeCount = database.routeDao().count()
        val stopCount = database.stopDao().count()
        database.syncLogDao().upsert(
            SyncLogEntity(
                kind = KIND_CATALOGUE,
                lastSyncAt = System.currentTimeMillis(),
                itemCount = routeCount,
                success = ok,
                message = messages.takeLast(3).joinToString("；")
            )
        )
        prefs.lastCatalogueSync = System.currentTimeMillis()

        SyncSummary(ok, routeCount, stopCount, database.dailyChangeDao().countByDate(date), messages)
    }

    // ==================================================================
    // 運輸署
    // ==================================================================

    private suspend fun syncTdCatalogue(): Int {
        val catalogue = td.fetchCatalogue()
        if (catalogue.routes.isEmpty()) return 0

        catalogue.routes.groupBy { it.operatorCode }.forEach { (op, routes) ->
            database.routeDao().replaceOperator(op, routes)
        }
        catalogue.stops.groupBy { it.operatorCode }.forEach { (op, stops) ->
            database.stopDao().replaceOperator(op, stops)
        }
        // 站序採整批覆寫（先刪後寫），否則已停辦路線的殘留站序會一直留在庫中。
        // 需涵蓋兩個命名空間：「TD」為運輸署純目錄；「MTRBUS」為港鐵巴士
        // （其路線與車站同樣來自運輸署資料，但放在可查詢的命名空間）。
        database.routeStopDao().deleteByPrefix(Operator.TD_BUS.code)
        database.routeStopDao().deleteByPrefix(Operator.MTR_BUS.code)
        catalogue.routeStops.chunked(2000).forEach { database.routeStopDao().upsertAll(it) }
        return catalogue.routes.size + catalogue.stops.size
    }

    private suspend fun syncTdDeltas(date: String): Int {
        val changes = td.fetchOfficialDeltas(date)
        insertChanges(changes)
        return changes.size
    }

    // ==================================================================
    // 九巴／龍運
    // ==================================================================

    private suspend fun syncKmb(): Int {
        val routes = kmb.routes().data
        val stops = kmb.stops().data
        val routeStops = kmb.routeStops().data

        val routeEntities = routes.map { r ->
            RouteEntity(
                routeKey = RouteKeys.route(Operator.KMB, r.route, r.bound, r.serviceType),
                operatorCode = Operator.KMB.code,
                companyCode = "KMB",
                routeNo = r.route,
                bound = r.bound,
                serviceType = r.serviceType,
                nameTc = "${r.route} ${r.origTc}→${r.destTc}",
                nameEn = "${r.route} ${r.origEn}→${r.destEn}",
                originTc = r.origTc,
                originEn = r.origEn,
                destTc = r.destTc,
                destEn = r.destEn,
                fullFare = 0.0,
                journeyTime = 0,
                specialType = r.serviceType,
                serviceMode = "",
                hasRealtime = true,
                lastUpdate = TimeUtil.parseFlexible(r.dataTimestamp)?.toEpochMilli()
                    ?: System.currentTimeMillis()
            )
        }
        // TD 目錄已有同名路線時，只更新「有即時到站」標記
        val tdRoutes = database.routeDao().byOperators(setOf(Operator.KMB.code))
        val realtimeRoutes = tdRoutes.map { rt ->
            if (routeEntities.any { it.routeNo == rt.routeNo }) rt.copy(hasRealtime = true) else rt
        }
        database.routeDao().upsertAll(realtimeRoutes)
        database.routeDao().upsertAll(routeEntities)

        val stopEntities = stops.mapNotNull { s ->
            if (s.stop.isBlank()) return@mapNotNull null
            StopEntity(
                stopKey = RouteKeys.stop(Operator.KMB, s.stop),
                operatorCode = Operator.KMB.code,
                stopId = s.stop,
                nameTc = s.nameTc,
                nameEn = s.nameEn,
                lat = s.lat.toDoubleOrNull() ?: 0.0,
                lng = s.lng.toDoubleOrNull() ?: 0.0,
                lastUpdate = TimeUtil.parseFlexible(s.dataTimestamp)?.toEpochMilli()
                    ?: System.currentTimeMillis()
            )
        }
        // 全量覆寫九巴車站（站數約六千，一次 upsert 比逐筆快得多）
        database.stopDao().replaceOperator(Operator.KMB.code, stopEntities)

        val stopNameById = stopEntities.associateBy { it.stopId }
        val entities = routeStops.mapNotNull { rs ->
            val info = stopNameById[rs.stop] ?: return@mapNotNull null
            RouteStopEntity(
                routeKey = RouteKeys.route(Operator.KMB, rs.route, rs.bound, rs.serviceType),
                stopSeq = rs.seq,
                stopKey = info.stopKey,
                stopId = rs.stop,
                stopNameTc = info.nameTc,
                stopNameEn = info.nameEn,
                lat = info.lat,
                lng = info.lng
            )
        }
        database.routeStopDao().deleteByPrefix("${Operator.KMB.code}|")
        entities.chunked(2000).forEach { database.routeStopDao().upsertAll(it) }
        return routeEntities.size + stopEntities.size + entities.size
    }

    // ==================================================================
    // 城巴
    // ==================================================================

    private suspend fun syncCtb(): Int {
        val routes = ctb.routes(ApiConstants.CTB_COMPANY_ID).data
        val entities = routes.map { r ->
            RouteEntity(
                routeKey = RouteKeys.route(Operator.CTB, r.route, r.bound, r.serviceType),
                operatorCode = Operator.CTB.code,
                companyCode = ApiConstants.CTB_COMPANY_ID,
                routeNo = r.route,
                bound = r.bound,
                serviceType = r.serviceType,
                nameTc = "${r.route} ${r.origTc}→${r.destTc}",
                nameEn = "${r.route} ${r.origEn}→${r.destEn}",
                originTc = r.origTc,
                originEn = r.origEn,
                destTc = r.destTc,
                destEn = r.destEn,
                fullFare = 0.0,
                journeyTime = 0,
                specialType = r.serviceType,
                serviceMode = "",
                hasRealtime = true,
                lastUpdate = System.currentTimeMillis()
            )
        }
        database.routeDao().upsertAll(entities)
        return entities.size
    }

    // ==================================================================
    // 新大嶼山巴士
    // ==================================================================

    private suspend fun syncNlb(): Int {
        val routes = nlb.routes().routes
        val entities = routes.mapNotNull { r ->
            if (r.routeNo.isBlank()) return@mapNotNull null
            RouteEntity(
                routeKey = RouteKeys.route(Operator.NLB, r.routeNo, "O", 1),
                operatorCode = Operator.NLB.code,
                companyCode = "NLB",
                routeNo = r.routeNo,
                bound = "O",
                serviceType = 1,
                nameTc = "${r.routeNo} ${r.routeNameC}",
                nameEn = "${r.routeNo} ${r.routeNameE}",
                originTc = r.routeNameC.substringBefore("往").trim(),
                originEn = r.routeNameE.substringBefore(" to ").trim(),
                destTc = r.routeNameC.substringAfter("往", "").trim().ifBlank { r.routeNameC },
                destEn = r.routeNameE.substringAfter(" to ", "").trim().ifBlank { r.routeNameE },
                fullFare = 0.0,
                journeyTime = 0,
                specialType = 0,
                serviceMode = "",
                hasRealtime = true,
                lastUpdate = System.currentTimeMillis()
            )
        }
        database.routeDao().upsertAll(entities)
        return entities.size
    }

    // ==================================================================
    // 專線小巴
    // ==================================================================

    private suspend fun syncGmb(): Int {
        val allRoutes = gmb.allRoutes().data ?: return 0
        if (!allRoutes.has("routes")) return 0
        val routesObject = allRoutes.getAsJsonObject("routes") ?: return 0

        val entities = mutableListOf<RouteEntity>()
        val now = System.currentTimeMillis()
        for (region in ApiConstants.GMB_REGIONS) {
            val array = routesObject.getAsJsonArray(region) ?: continue
            for (element in array) {
                val code = element.asString
                val detail = try {
                    gmb.routeDetail(region, code).data
                } catch (e: Exception) {
                    null
                }
                // GMB 即時到站 API 以 route_id 查詢，故把 route_id 存放在 companyCode 以便對應
                val routeId = detail?.routeId ?: code
                val dirs = detail?.directions.orEmpty()
                if (dirs.isEmpty()) {
                    entities += RouteEntity(
                        routeKey = RouteKeys.route(Operator.GMB, code, "O", 1),
                        operatorCode = Operator.GMB.code,
                        companyCode = routeId,
                        routeNo = code,
                        bound = "O",
                        serviceType = 1,
                        nameTc = "$code（$region）",
                        nameEn = "$code ($region)",
                        originTc = "",
                        originEn = "",
                        destTc = "",
                        destEn = "",
                        fullFare = 0.0,
                        journeyTime = 0,
                        specialType = 0,
                        serviceMode = region,
                        hasRealtime = true,
                        lastUpdate = now
                    )
                } else {
                    dirs.forEach { d ->
                        val routeSeq = d.routeSeq
                        val bound = if (routeSeq == 1) "O" else "I"
                        val description = d.descriptionTc ?: ""
                        entities += RouteEntity(
                            routeKey = RouteKeys.route(Operator.GMB, code, bound, routeSeq),
                            operatorCode = Operator.GMB.code,
                            companyCode = routeId,
                            routeNo = code,
                            bound = bound,
                            serviceType = routeSeq,
                            nameTc = "$code ${d.origTc ?: description}→${d.destTc ?: description}",
                            nameEn = "$code ${d.origEn ?: ""}→${d.destEn ?: ""}",
                            originTc = d.origTc ?: description.substringBefore("至").trim(),
                            originEn = d.origEn.orEmpty(),
                            destTc = d.destTc ?: description.substringAfter("至", "").trim(),
                            destEn = d.destEn.orEmpty(),
                            fullFare = 0.0,
                            journeyTime = 0,
                            specialType = routeSeq,
                            serviceMode = region,
                            hasRealtime = true,
                            lastUpdate = now
                        )
                    }
                }
            }
        }
        database.routeDao().upsertAll(entities)
        return entities.size
    }

    // ==================================================================
    // 港鐵重鐵
    // ==================================================================

    private suspend fun syncMtrHeavyRail(): Int {
        val csv = downloadCsv("${ApiConstants.MTR_OPEN_BASE}${ApiConstants.MTR_LINES_STATIONS_CSV}")
            ?: return 0
        val rows = CsvParser.parseWithHeader(csv)
        val now = System.currentTimeMillis()

        // CSV 的列序即為該線車站的先後次序，故直接以出現次序作為站序
        val lineStations = linkedMapOf<String, MutableList<StationRow>>()
        val allStations = linkedMapOf<String, StationRow>()
        for (row in rows) {
            val lineCode = pick(row, "Line Code", "line_code", "LINE_CODE").orEmpty().trim()
            val stationCode = pick(row, "Station Code", "station_code", "STATION_CODE").orEmpty().trim()
            val nameTc = pick(row, "Station Name (Chinese)", "station_name_ch", "Station Name Chinese")?.trim()
            val nameEn = pick(row, "Station Name (English)", "station_name_en", "Station Name English")?.trim()
            if (stationCode.isBlank() || nameTc.isNullOrBlank()) continue
            val record = StationRow(lineCode, stationCode, nameTc, nameEn.orEmpty())
            allStations[stationCode] = record
            if (lineCode.isNotBlank() && ApiConstants.MTR_HEAVY_RAIL_LINES.containsKey(lineCode)) {
                val list = lineStations.getOrPut(lineCode) { mutableListOf() }
                if (list.none { it.code == stationCode }) list += record
            }
        }
        val stations = allStations.values.toList()

        database.stopDao().upsertAll(
            stations.map {
                StopEntity(
                    stopKey = RouteKeys.stop(Operator.MTR_HR, it.code),
                    operatorCode = Operator.MTR_HR.code,
                    stopId = it.code,
                    nameTc = it.nameTc,
                    nameEn = it.nameEn,
                    lat = 0.0,
                    lng = 0.0,
                    lastUpdate = now
                )
            }
        )

        // 寫入各線的站序（供燈號判斷起點／中途／終點站）
        lineStations.forEach { (lineCode, list) ->
            val routeKey = RouteKeys.route(Operator.MTR_HR, lineCode, "UP", 1)
            database.routeStopDao().replaceRoute(
                routeKey,
                list.mapIndexed { index, station ->
                    RouteStopEntity(
                        routeKey = routeKey,
                        stopSeq = index + 1,
                        stopKey = RouteKeys.stop(Operator.MTR_HR, station.code),
                        stopId = station.code,
                        stopNameTc = station.nameTc,
                        stopNameEn = station.nameEn,
                        lat = 0.0,
                        lng = 0.0
                    )
                }
            )
        }

        val routeEntities = ApiConstants.MTR_HEAVY_RAIL_LINES.map { (code, nameTc) ->
            RouteEntity(
                routeKey = RouteKeys.route(Operator.MTR_HR, code, "UP", 1),
                operatorCode = Operator.MTR_HR.code,
                companyCode = "MTR",
                routeNo = code,
                bound = "UP",
                serviceType = 1,
                nameTc = nameTc,
                nameEn = code,
                originTc = nameTc,
                originEn = code,
                destTc = nameTc,
                destEn = code,
                fullFare = 0.0,
                journeyTime = 0,
                specialType = 0,
                serviceMode = "",
                hasRealtime = true,
                lastUpdate = now
            )
        }
        database.routeDao().upsertAll(routeEntities)
        return stations.size + routeEntities.size
    }

    private data class StationRow(val line: String, val code: String, val nameTc: String, val nameEn: String)

    // ==================================================================
    // 輕鐵
    // ==================================================================

    private suspend fun syncLightRail(): Int {
        val csv = downloadCsv("${ApiConstants.MTR_OPEN_BASE}${ApiConstants.MTR_LR_ROUTES_STOPS_CSV}")
            ?: return 0
        val rows = CsvParser.parseWithHeader(csv)
        val now = System.currentTimeMillis()

        val stopEntities = mutableMapOf<String, StopEntity>()
        val routeStopMap = mutableMapOf<String, MutableList<RouteStopEntity>>()
        val routeMetaMap = mutableMapOf<String, Pair<String, String>>()

        for (row in rows) {
            val routeNo = pick(row, "Route Number", "route_no", "ROUTE_NO").orEmpty().trim()
            val stopId = pick(row, "Stop Number", "stop_id", "STOP_ID").orEmpty().trim()
            val nameTc = pick(row, "Stop Name (Chinese)", "stop_name_ch", "STOP_NAME_CH").orEmpty().trim()
            val nameEn = pick(row, "Stop Name (English)", "stop_name_en", "STOP_NAME_EN").orEmpty().trim()
            val seq = pick(row, "Stop Order", "stop_order", "STOP_ORDER")?.toIntOrNull()
            val bound = pick(row, "Route Direction", "route_direction", "ROUTE_DIRECTION")?.trim() ?: "1"
            if (routeNo.isBlank() || stopId.isBlank()) continue

            val stopKey = RouteKeys.stop(Operator.MTR_LR, stopId)
            stopEntities[stopKey] = StopEntity(
                stopKey = stopKey,
                operatorCode = Operator.MTR_LR.code,
                stopId = stopId,
                nameTc = nameTc,
                nameEn = nameEn,
                lat = 0.0,
                lng = 0.0,
                lastUpdate = now
            )

            val routeKey = RouteKeys.route(Operator.MTR_LR, routeNo, bound, 1)
            routeStopMap.getOrPut(routeKey) { mutableListOf() }.add(
                RouteStopEntity(
                    routeKey = routeKey,
                    stopSeq = seq ?: (routeStopMap[routeKey]?.size ?: 0) + 1,
                    stopKey = stopKey,
                    stopId = stopId,
                    stopNameTc = nameTc,
                    stopNameEn = nameEn,
                    lat = 0.0,
                    lng = 0.0
                )
            )
            if (!routeMetaMap.containsKey(routeKey)) {
                routeMetaMap[routeKey] = Pair(
                    routeStopMap[routeKey]!!.firstOrNull()?.stopNameTc ?: "",
                    nameTc
                )
            } else {
                val (origin, _) = routeMetaMap[routeKey]!!
                routeMetaMap[routeKey] = Pair(origin, nameTc)
            }
        }

        database.stopDao().upsertAll(stopEntities.values.toList())
        database.routeDao().upsertAll(
            routeMetaMap.map { (routeKey, meta) ->
                RouteEntity(
                    routeKey = routeKey,
                    operatorCode = Operator.MTR_LR.code,
                    companyCode = "MTR",
                    routeNo = routeKey.split("|").getOrElse(1) { "" },
                    bound = routeKey.split("|").getOrElse(2) { "1" },
                    serviceType = 1,
                    nameTc = "輕鐵 ${routeKey.split("|").getOrElse(1) { "" }} ${meta.first}→${meta.second}",
                    nameEn = "LRT ${routeKey.split("|").getOrElse(1) { "" }}",
                    originTc = meta.first,
                    originEn = meta.first,
                    destTc = meta.second,
                    destEn = meta.second,
                    fullFare = 0.0,
                    journeyTime = 0,
                    specialType = 0,
                    serviceMode = "",
                    hasRealtime = true,
                    lastUpdate = now
                )
            }
        )
        routeStopMap.forEach { (routeKey, list) ->
            database.routeStopDao().replaceRoute(routeKey, list.sortedBy { it.stopSeq })
        }
        return stopEntities.size + routeStopMap.size
    }

    // ==================================================================
    // 港鐵巴士（接駁巴士）
    // ==================================================================

    /**
     * 建立港鐵巴士的「站序 → 政府 API busStopId」對照表。
     *
     * 路線與車站目錄本身已由運輸署資料寫入（見 [TdStaticRepository.buildMtrBusCatalogue]），
     * 這裡只補上即時到站所需的最後一塊拼圖。
     *
     * 做法：每條路線呼叫一次政府 API，其回傳的 busStop 陣列即為**依站序排列**的車站清單，
     * 故可依序對應到本機的 stopSeq。這樣就不必猜測 busStopId 的格式
     * （官方文件並未說明，任何字串拼湊都只是賭注）。
     *
     * 去／回程的取捨：API 只接受 routeName，不帶方向參數，因此當同一路線編號
     * 有兩個方向、且兩者車站數相同時，無從判斷回傳的是哪一個方向。
     * 這種情況一律略過（維持 hasRealtime = false，介面顯示「推算」），
     * 也不會寫入任何對照——寧可不顯示，也不要顯示錯誤的到站時間。
     */
    private suspend fun syncMtrBus(): Int = coroutineScope {
        val routes = database.routeDao().byOperators(setOf(Operator.MTR_BUS.code))
        if (routes.isEmpty()) return@coroutineScope 0

        val stopCounts = database.routeStopDao().countOfRoutes(routes.map { it.routeKey })
            .associate { it.routeKey to it.count }

        // 同一路線編號可能對應去／回程兩個 routeKey
        val byRouteNo = routes.groupBy { it.routeNo.trim().uppercase() }
        val now = System.currentTimeMillis()
        var mapped = 0

        // 逐批進行，避免同時對政府 API 發出大量請求
        for (batch in byRouteNo.entries.chunked(MTR_BUS_SYNC_CONCURRENCY)) {
            val deferred = batch.map { (routeNo, candidates) ->
                async { mapRouteNo(routeNo, candidates, stopCounts, now) }
            }
            deferred.awaitAll().filterNotNull().forEach { (routeKey, mapping) ->
                database.mtrBusStopMapDao().replaceRoute(routeKey, mapping)
                val route = routes.firstOrNull { it.routeKey == routeKey }
                if (route != null && !route.hasRealtime) {
                    database.routeDao().upsertAll(listOf(route.copy(hasRealtime = true)))
                }
                mapped++
            }
        }
        mapped
    }

    /**
     * 為單一路線編號建立對照表；無法明確對應時回傳 null。
     *
     * @return (routeKey, 對照表) 或 null
     */
    private suspend fun mapRouteNo(
        routeNo: String,
        candidates: List<RouteEntity>,
        stopCounts: Map<String, Int>,
        now: Long
    ): Pair<String, List<MtrBusStopMapEntity>>? {
        val dto = try {
            mtr.busSchedule(MtrBusRequest(routeName = routeNo))
        } catch (e: Exception) {
            return null
        }
        // status "1" = 正常；"0" = 錯誤或警示
        if (dto.status != null && dto.status != "1") return null
        val stops = dto.busStop.orEmpty()
        if (stops.isEmpty()) return null

        // 只有車站數恰好等於 API 回傳數量的方向才是明確的候選
        val exact = candidates.filter { stopCounts[it.routeKey] == stops.size }
        if (exact.size != 1) return null
        val route = exact.single()

        val mapping = stops.mapIndexedNotNull { index, stop ->
            val busStopId = stop.busStopId?.takeIf { it.isNotBlank() } ?: return@mapIndexedNotNull null
            MtrBusStopMapEntity(
                routeKey = route.routeKey,
                // API 陣列從第 0 個開始，運輸署 STOP_SEQ 從 1 開始
                stopSeq = index + 1,
                busStopId = busStopId,
                routeName = routeNo,
                mappedAt = now
            )
        }
        if (mapping.size != stops.size) return null
        return route.routeKey to mapping
    }

    // ==================================================================
    // 比對今日變動
    // ==================================================================

    private suspend fun commitChanges(date: String): Int {
        val previousRoutes = database.snapshotDao().allRoutes().associateBy { it.routeKey }
        val previousStops = database.snapshotDao().allStops().associateBy { it.stopKey }

        val currentRoutes = database.routeDao().byOperators(Operator.entries.map { it.code })
        val allRouteStops = database.routeStopDao().all()
        val routeStopsByRoute = allRouteStops.groupBy { it.routeKey }
        val stopCounts = routeStopsByRoute.mapValues { it.value.size }
        val stopFingerprints = routeStopsByRoute.mapValues { (_, list) ->
            ChangeDetector.stopSequenceFingerprint(list.sortedBy { it.stopSeq })
        }

        val routeChanges = ChangeDetector.detectRouteChanges(
            date = date,
            currentRoutes = currentRoutes,
            stopCounts = stopCounts,
            stopFingerprints = stopFingerprints,
            previous = previousRoutes
        )

        val currentStops = database.stopDao().search(
            q = "%",
            operatorCodes = Operator.entries.map { it.code },
            limit = Int.MAX_VALUE
        )

        val stopChanges = ChangeDetector.detectStopChanges(
            date = date,
            currentStops = currentStops,
            previous = previousStops
        )

        insertChanges(routeChanges + stopChanges)

        // 建立今日新快照
        database.snapshotDao().upsertRoutes(
            currentRoutes.map { route ->
                RouteSnapshotEntity(
                    routeKey = route.routeKey,
                    fingerprint = ChangeDetector.routeFingerprint(
                        route,
                        stopCounts[route.routeKey] ?: 0,
                        stopFingerprints[route.routeKey] ?: ""
                    ),
                    nameTc = route.nameTc,
                    originTc = route.originTc,
                    destTc = route.destTc,
                    fullFare = route.fullFare,
                    journeyTime = route.journeyTime,
                    stopCount = stopCounts[route.routeKey] ?: 0,
                    stopFingerprint = stopFingerprints[route.routeKey] ?: "",
                    capturedAt = System.currentTimeMillis()
                )
            }
        )
        database.snapshotDao().upsertStops(
            currentStops.map { stop ->
                StopSnapshotEntity(
                    stopKey = stop.stopKey,
                    fingerprint = ChangeDetector.stopFingerprint(stop),
                    nameTc = stop.nameTc,
                    nameEn = stop.nameEn,
                    lat = stop.lat,
                    lng = stop.lng,
                    capturedAt = System.currentTimeMillis()
                )
            }
        )
        return routeChanges.size + stopChanges.size
    }

    private suspend fun insertChanges(changes: List<DailyChangeEntity>) {
        if (changes.isEmpty()) return
        val grouped = changes.groupBy { it.date }
        val existing = mutableSetOf<String>()
        grouped.forEach { (date, items) ->
            items.map { it.dedupKey }.chunked(900).forEach { chunk ->
                existing += database.dailyChangeDao().existing(date, chunk).map { it.dedupKey }
            }
        }
        val newOnes = changes.filter { it.dedupKey !in existing }.distinctBy { it.dedupKey }
        if (newOnes.isNotEmpty()) database.dailyChangeDao().insertAll(newOnes)
    }

    private suspend fun downloadCsv(url: String): String? = try {
        static.raw(url).string().takeIf { it.isNotBlank() }
    } catch (e: Exception) {
        null
    }

    private fun pick(row: Map<String, String>, vararg keys: String): String? {
        for (k in keys) {
            row.entries.firstOrNull { it.key.equals(k, ignoreCase = true) }?.value?.let { return it }
        }
        return null
    }

    /** 清理過舊的變動記錄（預設保留 14 天）。 */
    suspend fun pruneOldChanges(keepDays: Int = 14) {
        val cutoff = java.time.LocalDate.now(HKT).minusDays(keepDays.toLong()).toString()
        database.dailyChangeDao().clearBefore(cutoff)
        database.weatherEventDao().clearBefore(cutoff)
    }

    companion object {
        const val KIND_CATALOGUE = "catalogue"

        /** 建立 busStopId 對照表時，同時對政府 API 發出的請求上限。 */
        private const val MTR_BUS_SYNC_CONCURRENCY = 4
    }
}

/** routeKey / stopKey 的統一產生規則。 */
object RouteKeys {
    fun route(operator: Operator, routeNo: String, bound: String, serviceType: Int): String =
        "${operator.code}|$routeNo|$bound|$serviceType"

    fun stop(operator: Operator, stopId: String): String = "${operator.code}|$stopId"

    fun operatorOfRouteKey(key: String): Operator? = Operator.fromCode(key.substringBefore("|"))
    fun routeNoOf(key: String): String? = key.split("|").getOrNull(1)
    fun boundOf(key: String): String? = key.split("|").getOrNull(2)
    fun serviceTypeOf(key: String): Int? = key.split("|").getOrNull(3)?.toIntOrNull()
}

/** 供外部計算路線指紋（例如天氣影響模組）。 */
fun fingerprintOfRoute(route: RouteEntity, stops: List<RouteStopEntity>): String =
    Fingerprint.of(
        route.routeNo,
        route.originTc,
        route.destTc,
        route.fullFare.toString(),
        stops.joinToString(">") { "${it.stopSeq}:${it.stopId}:${it.stopNameTc}" }
    )
