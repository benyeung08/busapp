package hk.transit.eta.data.repository

import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import hk.transit.eta.data.local.db.DailyChangeEntity
import hk.transit.eta.data.local.db.RouteEntity
import hk.transit.eta.data.local.db.StopEntity
import hk.transit.eta.data.local.db.WeatherEventEntity
import hk.transit.eta.domain.model.ChangeScope
import hk.transit.eta.domain.model.ChangeSource
import hk.transit.eta.domain.model.ChangeType
import hk.transit.eta.domain.model.DailyChange
import hk.transit.eta.domain.model.HeadwaySlot
import hk.transit.eta.domain.model.Operator
import hk.transit.eta.domain.model.RouteInfo
import hk.transit.eta.domain.model.RouteStopInfo
import hk.transit.eta.domain.model.StopInfo
import hk.transit.eta.domain.model.WeatherEvent
import java.time.Instant

private val mapperGson = Gson()

private fun jsonToList(json: String): List<String> = try {
    val type = object : TypeToken<List<String>>() {}.type
    mapperGson.fromJson(json, type) ?: emptyList()
} catch (e: Exception) {
    emptyList()
}

fun DailyChangeEntity.toDomain(): DailyChange = DailyChange(
    id = id,
    date = date,
    scope = runCatching { ChangeScope.valueOf(scope) }.getOrDefault(ChangeScope.ROUTE),
    changeType = runCatching { ChangeType.valueOf(changeType) }.getOrDefault(ChangeType.MODIFIED),
    operator = Operator.fromCode(operatorCode) ?: Operator.KMB,
    routeKey = routeKey,
    routeNo = routeNo,
    bound = bound,
    stopKey = stopKey,
    stopId = stopId,
    title = title,
    detail = detail,
    affectedStops = jsonToList(affectedStopsJson),
    affectedStopIds = jsonToList(affectedStopIdsJson),
    effectiveFrom = effectiveFrom?.let { Instant.ofEpochMilli(it) },
    effectiveTo = effectiveTo?.let { Instant.ofEpochMilli(it) },
    resumedAt = resumedAt?.let { Instant.ofEpochMilli(it) },
    weatherRelated = weatherRelated,
    warningCode = warningCode,
    headwayMinutes = headwayMinutes,
    normalHeadwayMinutes = normalHeadwayMinutes,
    source = runCatching { ChangeSource.valueOf(source) }.getOrDefault(ChangeSource.CATALOGUE_DIFF),
    isEstimate = isEstimate
)

fun WeatherEventEntity.toDomain(): WeatherEvent = WeatherEvent(
    key = key,
    date = date,
    warningCode = warningCode,
    warningName = warningName,
    actionCode = actionCode,
    level = level,
    issueTime = issueTime?.let { Instant.ofEpochMilli(it) },
    updateTime = updateTime?.let { Instant.ofEpochMilli(it) },
    cancelTime = cancelTime?.let { Instant.ofEpochMilli(it) },
    detail = detail
)

fun RouteEntity.toDomain(stopCount: Int = 0): RouteInfo = RouteInfo(
    routeKey = routeKey,
    operator = Operator.fromCode(operatorCode) ?: Operator.KMB,
    companyCode = companyCode,
    routeNo = routeNo,
    bound = bound,
    serviceType = serviceType,
    nameTc = nameTc,
    nameEn = nameEn,
    originTc = originTc,
    originEn = originEn,
    destTc = destTc,
    destEn = destEn,
    fullFare = fullFare,
    journeyTime = journeyTime,
    specialType = specialType,
    serviceMode = serviceMode,
    hasRealtime = hasRealtime,
    stopCount = stopCount
)

fun StopEntity.toDomain(): StopInfo = StopInfo(
    stopKey = stopKey,
    operator = Operator.fromCode(operatorCode) ?: Operator.KMB,
    stopId = stopId,
    nameTc = nameTc,
    nameEn = nameEn,
    lat = lat,
    lng = lng
)

fun hk.transit.eta.data.local.db.RouteStopEntity.toDomain(): RouteStopInfo = RouteStopInfo(
    routeKey = routeKey,
    stopSeq = stopSeq,
    stopKey = stopKey,
    stopId = stopId,
    stopNameTc = stopNameTc,
    stopNameEn = stopNameEn,
    lat = lat,
    lng = lng
)

fun hk.transit.eta.data.local.db.HeadwayEntity.toDomain(): HeadwaySlot = HeadwaySlot(
    routeKey = routeKey,
    startTime = startTime,
    endTime = endTime,
    headwaySecs = headwaySecs
)
