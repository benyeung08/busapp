package hk.transit.eta.ui.theme

import androidx.compose.ui.graphics.Color

val BrandBlue = Color(0xFF0F4C81)
val BrandBlueDark = Color(0xFF0A3357)

val SignalRed = Color(0xFFD32F2F)
val SignalAmber = Color(0xFFED6C02)
val SignalGreen = Color(0xFF2E7D32)
val SignalGrey = Color(0xFF757575)

val RailPurple = Color(0xFF6A1B9A)
val LightRailOrange = Color(0xFFE65100)
