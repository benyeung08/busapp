package hk.transit.eta.worker

import android.content.Context
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import hk.transit.eta.data.local.UserPreferences
import java.time.Duration
import java.time.LocalDateTime
import java.time.ZoneId
import java.util.concurrent.TimeUnit

/**
 * 每日全自動更新的排程中心。
 *
 *  - 路線／車站目錄：每日一次（預設凌晨 4 時）
 *  - 運輸署特別交通消息：每 15 分鐘（臨時改道／取消／恢復）
 *  - 天文台天氣警告：每 15 分鐘
 *
 * 使用 Unique Work 確保不會重複排程。
 */
object SyncScheduler {

    const val WORK_CATALOGUE = "catalogue_daily_sync"
    const val WORK_NEWS = "news_periodic_sync"
    const val WORK_WEATHER = "weather_periodic_sync"
    const val WORK_ONCE = "sync_once"

    private fun networkConstraints() = Constraints.Builder()
        .setRequiredNetworkType(NetworkType.CONNECTED)
        .build()

    fun scheduleAll(context: Context) {
        scheduleCatalogue(context)
        scheduleNews(context)
        scheduleWeather(context)
    }

    fun scheduleCatalogue(context: Context) {
        val prefs = UserPreferences(context)
        val delay = millisUntilHour(prefs.syncHour.value)
        val request = PeriodicWorkRequestBuilder<CatalogueSyncWorker>(1, TimeUnit.DAYS)
            .setConstraints(networkConstraints())
            .setInitialDelay(delay, TimeUnit.MILLISECONDS)
            .build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            WORK_CATALOGUE,
            ExistingPeriodicWorkPolicy.UPDATE,
            request
        )
    }

    fun scheduleNews(context: Context) {
        val request = PeriodicWorkRequestBuilder<NewsSyncWorker>(15, TimeUnit.MINUTES)
            .setConstraints(networkConstraints())
            .build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            WORK_NEWS,
            ExistingPeriodicWorkPolicy.KEEP,
            request
        )
    }

    fun scheduleWeather(context: Context) {
        val request = PeriodicWorkRequestBuilder<WeatherSyncWorker>(15, TimeUnit.MINUTES)
            .setConstraints(networkConstraints())
            .build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            WORK_WEATHER,
            ExistingPeriodicWorkPolicy.KEEP,
            request
        )
    }

    /** 立即執行一次完整同步（設定頁的「立即更新」）。 */
    fun syncNow(context: Context) {
        val request = OneTimeWorkRequestBuilder<CatalogueSyncWorker>()
            .setConstraints(networkConstraints())
            .build()
        WorkManager.getInstance(context).enqueueUniqueWork(
            WORK_ONCE,
            ExistingWorkPolicy.KEEP,
            request
        )
    }

    private fun millisUntilHour(hour: Int): Long {
        val zone = ZoneId.of("Asia/Hong_Kong")
        val now = LocalDateTime.now(zone)
        var next = now.withHour(hour.coerceIn(0, 23)).withMinute(0).withSecond(0).withNano(0)
        if (!next.isAfter(now)) next = next.plusDays(1)
        return Duration.between(now, next).toMillis().coerceAtLeast(60_000L)
    }
}
