package hk.transit.eta.data.local.db

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "route",
    indices = [Index("routeNo"), Index("operatorCode"), Index("routeNo", "bound")]
)
data class RouteEntity(
    @PrimaryKey val routeKey: String,
    val operatorCode: String,
    val companyCode: String,
    val routeNo: String,
    val bound: String,
    val serviceType: Int,
    val nameTc: String,
    val nameEn: String,
    val originTc: String,
    val originEn: String,
    val destTc: String,
    val destEn: String,
    val fullFare: Double,
    val journeyTime: Int,
    val specialType: Int,
    val serviceMode: String,
    val hasRealtime: Boolean,
    val lastUpdate: Long
)

@Entity(
    tableName = "stop",
    indices = [Index("operatorCode"), Index("nameTc")]
)
data class StopEntity(
    @PrimaryKey val stopKey: String,
    val operatorCode: String,
    val stopId: String,
    val nameTc: String,
    val nameEn: String,
    val lat: Double,
    val lng: Double,
    val lastUpdate: Long
)

@Entity(
    tableName = "route_stop",
    primaryKeys = ["routeKey", "stopSeq"],
    indices = [Index("stopKey"), Index("routeKey")]
)
data class RouteStopEntity(
    val routeKey: String,
    val stopSeq: Int,
    val stopKey: String,
    val stopId: String,
    val stopNameTc: String,
    val stopNameEn: String,
    val lat: Double,
    val lng: Double
)

/** 每日路線快照，用作翌日比對（偵測新增／取消／修改）。 */
@Entity(tableName = "route_snapshot")
data class RouteSnapshotEntity(
    @PrimaryKey val routeKey: String,
    val fingerprint: String,
    val nameTc: String,
    val originTc: String,
    val destTc: String,
    val fullFare: Double,
    val journeyTime: Int,
    val stopCount: Int,
    val stopFingerprint: String,
    val capturedAt: Long
)

/** 每日車站快照，用作翌日比對（偵測車站新增／取消／改名／移位）。 */
@Entity(tableName = "stop_snapshot")
data class StopSnapshotEntity(
    @PrimaryKey val stopKey: String,
    val fingerprint: String,
    val nameTc: String,
    val nameEn: String,
    val lat: Double,
    val lng: Double,
    val capturedAt: Long
)

@Entity(
    tableName = "daily_change",
    indices = [Index("date"), Index("changeType"), Index("date", "changeType")]
)
data class DailyChangeEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val date: String,
    val scope: String,
    val changeType: String,
    val operatorCode: String,
    val routeKey: String?,
    val routeNo: String?,
    val bound: String?,
    val stopKey: String?,
    val stopId: String?,
    val title: String,
    val detail: String,
    val affectedStopsJson: String,
    val affectedStopIdsJson: String,
    val effectiveFrom: Long?,
    val effectiveTo: Long?,
    val resumedAt: Long?,
    val weatherRelated: Boolean,
    val warningCode: String?,
    val headwayMinutes: Int?,
    val normalHeadwayMinutes: Int?,
    val source: String,
    val isEstimate: Boolean,
    val createdAt: Long,
    /** 同一事件的去重鍵，避免每日重複寫入 */
    val dedupKey: String
)

@Entity(tableName = "weather_event", indices = [Index("date")])
data class WeatherEventEntity(
    @PrimaryKey val key: String,
    val date: String,
    val warningCode: String,
    val warningName: String,
    val actionCode: String,
    val level: Int,
    val issueTime: Long?,
    val updateTime: Long?,
    val cancelTime: Long?,
    val detail: String
)

/**
 * 港鐵巴士：運輸署站序 ↔ 政府即時 API 的 busStopId 對照表。
 *
 * 為什麼需要這張表：
 * 政府「港鐵巴士及接駁巴士實時到站」API
 * （rt.data.gov.hk/v1/transport/mtr/bus/getSchedule）
 * 只接受 routeName，回傳該路線「依站序排列」的 busStop 陣列；
 * 陣列內每個元素的 busStopId 才是查到站時間的唯一鍵。
 * 而運輸署「路線及收費資料」用的是自己的 STOP_ID，兩套編號並不相通。
 *
 * 官方文件沒有說明 busStopId 的格式，因此**不能靠字串拼湊猜測**——
 * 一旦拼錯，查詢只會靜默落空、退回班次表推算，使用者完全看不出異常。
 * 正確做法是在每日同步時呼叫一次 API，把回傳的 busStopId 依序記錄下來。
 */
@Entity(
    tableName = "mtr_bus_stop_map",
    primaryKeys = ["routeKey", "stopSeq"],
    indices = [Index("routeName")]
)
data class MtrBusStopMapEntity(
    /** 本專案的 routeKey（含 ROUTE_SEQ，見 MtrBusKeys）。 */
    val routeKey: String,
    val stopSeq: Int,
    /** 政府 API 回傳的車站識別碼，供即時到站查詢使用。 */
    val busStopId: String,
    /** 呼叫 API 時使用的 routeName（＝運輸署 ROUTE_NAMEC）。 */
    val routeName: String,
    /** 建立時間，用以判斷對照表是否過舊。 */
    val mappedAt: Long
)

/** 班次時間表（GTFS frequencies.txt），供無即時資料時推算。 */
@Entity(
    tableName = "headway",
    primaryKeys = ["routeKey", "startTime"],
    indices = [Index("routeNo")]
)
data class HeadwayEntity(
    val routeKey: String,
    val routeNo: String,
    val operatorCode: String,
    val startTime: String,
    val endTime: String,
    val headwaySecs: Int,
    val serviceId: String,
    val directionId: Int
)

/** 同步記錄，用以判斷「今日是否已更新」。 */
@Entity(tableName = "sync_log")
data class SyncLogEntity(
    @PrimaryKey val kind: String,
    val lastSyncAt: Long,
    val itemCount: Int,
    val success: Boolean,
    val message: String?
)
