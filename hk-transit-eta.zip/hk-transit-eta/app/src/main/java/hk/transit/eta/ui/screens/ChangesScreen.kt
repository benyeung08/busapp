package hk.transit.eta.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import hk.transit.eta.R
import hk.transit.eta.domain.model.ChangeType
import hk.transit.eta.ui.components.ChangeCard
import hk.transit.eta.ui.viewmodel.ChangesViewModel

/**
 * 今日路線與車站變動：
 * 新增／取消／修改／臨時改道／天氣影響／已回復正常。
 */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun ChangesScreen(
    viewModel: ChangesViewModel,
    modifier: Modifier = Modifier
) {
    val changes by viewModel.changes.collectAsState()
    val filter by viewModel.filter.collectAsState()
    val counts by viewModel.counts.collectAsState()

    Scaffold(
        modifier = modifier,
        topBar = {
            TopAppBar(title = { Text(stringResource(R.string.changes_title)) })
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = filter == null,
                        onClick = { viewModel.setFilter(null) },
                        label = { Text("全部（${counts.values.sum()}）") }
                    )
                    ChangeType.entries.forEach { type ->
                        val count = counts[type] ?: 0
                        if (count > 0) {
                            FilterChip(
                                selected = filter == type,
                                onClick = { viewModel.setFilter(if (filter == type) null else type) },
                                label = { Text("${type.labelTc}（$count）") }
                            )
                        }
                    }
                }
            }
            if (changes.isEmpty()) {
                item {
                    Text(
                        text = stringResource(R.string.changes_empty),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                items(changes, key = { it.id }) { change ->
                    ChangeCard(change = change)
                }
            }
        }
    }
}
