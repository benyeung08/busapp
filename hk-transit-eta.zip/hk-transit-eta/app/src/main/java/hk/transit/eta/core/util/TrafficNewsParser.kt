package hk.transit.eta.core.util

import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserException
import java.io.StringReader

/**
 * 運輸署「特別交通消息（第二代）」XML 解析器。
 * https://www.td.gov.hk/tc/special_news/trafficnews.xml
 *
 * 官方 XSD 會隨版本微調欄位名稱，故此處以「寬鬆」方式解析：
 * 逐個 message 元素收集其子元素的文字，再由呼叫方按需要取值。
 */
object TrafficNewsParser {

    data class TrafficNewsItem(
        val id: String,
        val fields: Map<String, String>,
        val publishedAt: java.time.Instant?,
        val announcedAt: java.time.Instant?,
        val incidentStatus: String?
    ) {
        fun tc(): String = pick("chinese_message", "message_tc", "MESSAGE_TC", "chineseMessage")
        fun en(): String = pick("english_message", "message_en", "MESSAGE_EN", "englishMessage")

        private fun pick(vararg keys: String): String {
            for (k in keys) {
                val v = fields.entries.firstOrNull { it.key.equals(k, ignoreCase = true) }?.value
                if (!v.isNullOrBlank()) return v
            }
            return ""
        }
    }

    private val MESSAGE_TAGS = setOf("message", "news", "item", "row")

    @Throws(XmlPullParserException::class)
    fun parse(xml: String): List<TrafficNewsItem> {
        val parser = Xml.newPullParser().apply {
            setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
            setInput(StringReader(xml))
        }

        val results = mutableListOf<TrafficNewsItem>()
        var event = parser.eventType
        var currentItem: MutableMap<String, String>? = null
        var currentTag: String? = null
        var currentText = StringBuilder()

        while (event != XmlPullParser.END_DOCUMENT) {
            when (event) {
                XmlPullParser.START_TAG -> {
                    val tag = parser.name
                    if (tag != null && tag.lowercase() in MESSAGE_TAGS && currentItem == null) {
                        currentItem = mutableMapOf()
                    }
                    if (currentItem != null && tag != null && tag.lowercase() !in MESSAGE_TAGS) {
                        currentTag = tag
                        currentText = StringBuilder()
                    }
                }

                XmlPullParser.TEXT -> {
                    if (currentTag != null) currentText.append(parser.text ?: "")
                }

                XmlPullParser.END_TAG -> {
                    val tag = parser.name
                    if (tag == null) Unit
                    else if (currentTag != null && tag == currentTag) {
                        currentItem?.put(tag, currentText.toString().trim())
                        currentTag = null
                    } else if (tag.lowercase() in MESSAGE_TAGS && currentItem != null) {
                        val item = currentItem!!
                        val (published, announced, status) = extractMeta(item)
                        results.add(
                            TrafficNewsItem(
                                id = item.entries.firstOrNull { it.key.equals("message_id", true) || it.key.equals("id", true) }?.value
                                    ?: Fingerprint.of(item["message_id"], item.values.joinToString()),
                                fields = item,
                                publishedAt = published,
                                announcedAt = announced,
                                incidentStatus = status
                            )
                        )
                        currentItem = null
                    }
                }
            }
            event = parser.next()
        }
        return results
    }

    private fun extractMeta(item: Map<String, String>): Triple<java.time.Instant?, java.time.Instant?, String?> {
        fun find(vararg keys: String): String? =
            keys.firstNotNullOfOrNull { k -> item.entries.firstOrNull { it.key.equals(k, true) }?.value }

        val published = TimeUtil.parseFlexible(find("publication_date", "publish_date", "date"))
        val announced = TimeUtil.parseFlexible(find("announcement_date", "announce_date"))
        val status = find("incident_status", "status")
        return Triple(published, announced, status)
    }
}
