package hk.transit.eta.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import hk.transit.eta.R
import hk.transit.eta.core.util.TimeUtil
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: hk.transit.eta.ui.viewmodel.SettingsViewModel,
    modifier: Modifier = Modifier
) {
    val flash by viewModel.flashEnabled.collectAsState()
    val autoUpdate by viewModel.autoUpdate.collectAsState()
    val syncHour by viewModel.syncHour.collectAsState()
    val language by viewModel.language.collectAsState()
    val lastSync by viewModel.lastSync.collectAsState()
    val catalogueCount by viewModel.catalogueCount.collectAsState()

    var syncing by remember { mutableStateOf(false) }
    var hourDraft by remember(syncHour) { mutableStateOf(syncHour.toFloat()) }
    val scope = rememberCoroutineScope()

    Scaffold(
        modifier = modifier,
        topBar = { TopAppBar(title = { Text(stringResource(R.string.settings_title)) }) }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "本機路線資料：$catalogueCount 條路線",
                            style = MaterialTheme.typography.titleSmall
                        )
                        Text(
                            text = stringResource(
                                R.string.settings_last_sync,
                                if (lastSync == 0L) stringResource(R.string.settings_never)
                                else TimeUtil.formatDateTime(TimeUtil.fromEpochMillis(lastSync))
                            ),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
            item {
                SettingSwitch(
                    title = stringResource(R.string.settings_auto_update),
                    subtitle = stringResource(R.string.settings_auto_update_desc, "%02d:00".format(syncHour)),
                    checked = autoUpdate,
                    onCheckedChange = viewModel::setAutoUpdate
                )
            }
            item {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "每日更新時間：%02d:00".format(hourDraft.roundToInt()),
                            style = MaterialTheme.typography.titleSmall
                        )
                        Slider(
                            value = hourDraft,
                            onValueChange = { hourDraft = it },
                            onValueChangeFinished = { viewModel.setSyncHour(hourDraft.roundToInt()) },
                            valueRange = 0f..23f,
                            steps = 22
                        )
                    }
                }
            }
            item {
                SettingSwitch(
                    title = stringResource(R.string.settings_flash),
                    subtitle = stringResource(R.string.settings_flash_desc),
                    checked = flash,
                    onCheckedChange = viewModel::setFlash
                )
            }
            item {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = stringResource(R.string.settings_language),
                            style = MaterialTheme.typography.titleSmall
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            listOf("tc" to "繁體中文", "sc" to "简体中文", "en" to "English").forEach { (code, label) ->
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    RadioButton(
                                        selected = language == code,
                                        onClick = { viewModel.setLanguage(code) }
                                    )
                                    Text(label, style = MaterialTheme.typography.bodyMedium)
                                }
                            }
                        }
                    }
                }
            }
            item {
                Button(
                    onClick = {
                        scope.launch {
                            syncing = true
                            try {
                                viewModel.syncNow()
                            } finally {
                                syncing = false
                                viewModel.refreshLastSync()
                            }
                        }
                    },
                    enabled = !syncing,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (syncing) {
                        CircularProgressIndicator(
                            modifier = Modifier.padding(end = 8.dp),
                            strokeWidth = 2.dp
                        )
                    }
                    Text(
                        if (syncing) stringResource(R.string.settings_updating)
                        else stringResource(R.string.settings_update_now)
                    )
                }
            }
            item {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "資料來源",
                            style = MaterialTheme.typography.titleSmall
                        )
                        Text(
                            text = stringResource(R.string.disclaimer_official),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = stringResource(R.string.disclaimer_estimate),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingSwitch(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleSmall)
                Text(
                    subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Switch(checked = checked, onCheckedChange = onCheckedChange)
        }
    }
}
