package hk.transit.eta.data.local.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        RouteEntity::class,
        StopEntity::class,
        RouteStopEntity::class,
        RouteSnapshotEntity::class,
        StopSnapshotEntity::class,
        DailyChangeEntity::class,
        WeatherEventEntity::class,
        HeadwayEntity::class,
        MtrBusStopMapEntity::class,
        SyncLogEntity::class
    ],
    // v2：新增港鐵巴士 busStopId 對照表。
    // 所有內容均可由官方 API 重新抓取，故以重建代替編寫遷移
    // （見下方的 fallbackToDestructiveMigration）。
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun routeDao(): RouteDao
    abstract fun stopDao(): StopDao
    abstract fun routeStopDao(): RouteStopDao
    abstract fun snapshotDao(): SnapshotDao
    abstract fun dailyChangeDao(): DailyChangeDao
    abstract fun weatherEventDao(): WeatherEventDao
    abstract fun headwayDao(): HeadwayDao
    abstract fun mtrBusStopMapDao(): MtrBusStopMapDao
    abstract fun syncLogDao(): SyncLogDao

    companion object {
        private const val DB_NAME = "hk-transit.db"

        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    DB_NAME
                )
                    // 所有內容均可由官方 API 重新抓取，故以重建代替編寫遷移
                    .fallbackToDestructiveMigration()
                    .build()
                    .also { INSTANCE = it }
            }
    }
}
