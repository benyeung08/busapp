package hk.transit.eta.worker

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import hk.transit.eta.core.di.AppContainer
import hk.transit.eta.core.util.TimeUtil
import kotlinx.coroutines.coroutineScope

/**
 * 每日全自動更新：
 *  1. 巴士、小巴、港鐵重鐵、輕鐵的路線與車站資料
 *  2. 運輸署官方更新記錄（新增／取消／修改）
 *  3. 比對今日變動
 *  4. 特別交通消息（臨時改道／取消）
 *  5. 天文台天氣警告
 *  6. 班次時間表（GTFS）
 */
class CatalogueSyncWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result = coroutineScope {
        val container = AppContainer.get(applicationContext)
        val date = TimeUtil.today()
        val messages = mutableListOf<String>()
        var ok = true

        try {
            val summary = container.catalogueRepository.syncAll { step ->
                setProgressAsync(workDataOf("step" to step))
                messages += step
            }
            ok = summary.success
            messages += summary.messages
        } catch (e: Exception) {
            ok = false
            messages += "目錄同步失敗：${e.message}"
        }

        try {
            val news = container.newsRepository.sync(date)
            container.weatherRepository.applyActualRecovery(date, news.resumedRoutes)
            messages += "特別交通消息：${news.changeCount} 項"
        } catch (e: Exception) {
            messages += "特別交通消息同步失敗：${e.message}"
        }

        try {
            container.weatherRepository.sync(date)
        } catch (e: Exception) {
            messages += "天氣同步失敗：${e.message}"
        }

        try {
            container.headwayRepository.sync()
        } catch (e: Exception) {
            messages += "班次時間表同步失敗：${e.message}"
        }

        try {
            container.catalogueRepository.pruneOldChanges()
        } catch (e: Exception) {
            /* 清理失敗不影響同步結果 */
        }

        setProgressAsync(workDataOf("done" to true))
        if (ok) Result.success() else Result.retry()
    }
}
