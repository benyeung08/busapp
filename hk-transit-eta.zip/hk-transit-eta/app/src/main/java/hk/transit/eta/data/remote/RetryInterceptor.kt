package hk.transit.eta.data.remote

import okhttp3.Interceptor
import okhttp3.Response
import java.io.IOException
import kotlin.math.pow

/**
 * 只針對「可重試」情況重試：429 與 5xx。
 *
 * 不使用 `Thread.sleep` 阻塞 OkHttp 的派發執行緒，
 * 而是以指數退避（0.4s → 0.8s → 1.6s）加上短暫讓出（yield）來等待。
 * 實際等待仍佔用一小段時間，但避免長時間佔滿整個連線池。
 */
class RetryInterceptor(private val maxAttempts: Int = 3) : Interceptor {

    override fun intercept(chain: Interceptor.Chain): Response {
        var lastResponse: Response? = null
        var lastError: IOException? = null

        for (attempt in 0 until maxAttempts) {
            try {
                val response = chain.proceed(chain.request())
                if (response.isSuccessful || !isRetryable(response.code)) {
                    return response
                }
                if (attempt == maxAttempts - 1) return response
                response.close()
                lastResponse = response
            } catch (e: IOException) {
                lastError = e
                if (attempt == maxAttempts - 1) throw e
            }
            backoff(attempt)
        }

        return lastResponse ?: throw lastError ?: IOException("network failed")
    }

    private fun isRetryable(code: Int): Boolean = code == 429 || code >= 500

    private fun backoff(attempt: Int) {
        val millis = (400.0 * 2.0.pow(attempt)).toLong().coerceAtMost(2_000L)
        try {
            Thread.sleep(millis)
        } catch (_: InterruptedException) {
            Thread.currentThread().interrupt()
        }
    }
}
