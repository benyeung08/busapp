package hk.transit.eta.domain.model

import java.time.Instant

/**
 * 營辦商／服務類型。
 * code 會作為資料庫索引與 API 參數使用，請勿隨意更改。
 */
enum class Operator(
    val code: String,
    val labelTc: String,
    val group: Mode,
    /**
     * 純目錄用途、不提供即時到站查詢的命名空間。
     * 運輸署「路線及收費資料」使用自己的 ROUTE_ID／STOP_ID，與各營辦商的編號並不相同，
     * 若混入同一命名空間會互相覆蓋，故此處以獨立代碼存放，且不顯示於搜尋結果。
     */
    val directoryOnly: Boolean = false
) {
    KMB("KMB", "九巴／龍運", Mode.BUS),
    CTB("CTB", "城巴", Mode.BUS),
    NLB("NLB", "新大嶼山巴士", Mode.BUS),
    GMB("GMB", "專線小巴", Mode.MINIBUS),
    MTR_HR("MTR", "港鐵（重鐵）", Mode.HEAVY_RAIL),
    MTR_LR("LRT", "輕鐵", Mode.LIGHT_RAIL),
    MTR_BUS("MTRBUS", "港鐵巴士", Mode.BUS),
    TD_BUS("TD", "運輸署（路線及收費資料）", Mode.BUS, directoryOnly = true),
    TD_GMB("TDG", "運輸署（路線及收費資料・小巴）", Mode.MINIBUS, directoryOnly = true);

    companion object {
        fun fromCode(code: String?): Operator? = entries.firstOrNull { it.code == code }

        /** 可供使用者搜尋與顯示的營辦商（排除純目錄命名空間）。 */
        val visible: List<Operator> get() = entries.filter { !it.directoryOnly }

        /** 某個 Mode 下要顯示的營辦商代碼。 */
        fun codesOf(mode: Mode): Set<String> =
            visible.filter { it.group == mode }.map { it.code }.toSet()
    }
}

/** 四大顯示分頁，對應底部導覽。 */
enum class Mode(val labelTc: String) {
    BUS("巴士"),
    MINIBUS("小巴"),
    HEAVY_RAIL("港鐵"),
    LIGHT_RAIL("輕鐵")
}

/** 車站在路線中的角色，決定燈號文案。 */
enum class StopRole(val labelTc: String) {
    ORIGIN("起點站"),
    INTERMEDIATE("中途站"),
    TERMINUS("終點站")
}

/** ETA 的可靠程度。 */
enum class EtaSource(val labelTc: String) {
    REALTIME("即時"),       // 營辦商即時到站 API
    SCHEDULE("推算"),       // 由班次時間表推算
    NONE("無資料")
}

/** 路線資料（統一模型）。 */
data class RouteInfo(
    val routeKey: String,
    val operator: Operator,
    val companyCode: String,
    val routeNo: String,
    val bound: String,               // O / I（巴士、小巴）；UP / DOWN（鐵路）
    val serviceType: Int,
    val nameTc: String,
    val nameEn: String,
    val originTc: String,
    val originEn: String,
    val destTc: String,
    val destEn: String,
    val fullFare: Double,
    val journeyTime: Int,
    val specialType: Int,
    val serviceMode: String,
    val hasRealtime: Boolean,
    val stopCount: Int
)

/** 車站／月台資料（統一模型）。 */
data class StopInfo(
    val stopKey: String,
    val operator: Operator,
    val stopId: String,
    val nameTc: String,
    val nameEn: String,
    val lat: Double,
    val lng: Double
)

/** 路線 — 車站關係（含站序）。 */
data class RouteStopInfo(
    val routeKey: String,
    val stopSeq: Int,
    val stopKey: String,
    val stopId: String,
    val stopNameTc: String,
    val stopNameEn: String,
    val lat: Double,
    val lng: Double
)

/** 一筆到站預報。 */
data class EtaEntry(
    val routeKey: String,
    val routeNo: String,
    val operator: Operator,
    val bound: String,
    val serviceType: Int,
    val stopSeq: Int,
    val eta: Instant?,
    val minutes: Int?,
    val destTc: String,
    val destEn: String,
    val remarkTc: String?,
    val source: EtaSource,
    val trainLength: Int? = null,      // 輕鐵：車卡數
    val platform: String? = null       // 鐵路：月台
)

/** 一條路線在一個車站的完整班次列表（含站序、總站數，供燈號判斷角色）。 */
data class StopEtaBoard(
    val routeKey: String,
    val routeNo: String,
    val operator: Operator,
    val bound: String,
    val destTc: String,
    val stopSeq: Int,
    val totalStops: Int,
    val stopRole: StopRole,
    val entries: List<EtaEntry>,
    val hasRealtime: Boolean,
    val fetchedAt: Instant
)

/** 班次時間表的一節（供無即時資料時推算）。 */
data class HeadwaySlot(
    val routeKey: String,
    val startTime: String,   // HH:mm:ss
    val endTime: String,
    val headwaySecs: Int
)

/** 今日變動類型。 */
enum class ChangeType(val labelTc: String) {
    ADDED("新增"),
    REMOVED("取消"),
    MODIFIED("修改"),
    DIVERSION("臨時改道"),
    WEATHER("天氣影響"),
    RESTORED("已回復正常")
}

/** 變動的對象層級。 */
enum class ChangeScope(val labelTc: String) {
    ROUTE("路線"),
    STOP("車站")
}

/** 變動來源，決定介面上的可信度標示。 */
enum class ChangeSource(val labelTc: String) {
    CATALOGUE_DIFF("路線資料比對"),
    TD_DELTA("運輸署更新記錄"),
    TD_NEWS("運輸署特別交通消息"),
    HKO("天文台警告＋推算"),
    OPERATOR("營辦商")
}

/** 一項今日變動記錄。 */
data class DailyChange(
    val id: Long = 0,
    val date: String,                    // yyyy-MM-dd（香港時間）
    val scope: ChangeScope,
    val changeType: ChangeType,
    val operator: Operator,
    val routeKey: String?,
    val routeNo: String?,
    val bound: String?,
    val stopKey: String?,
    val stopId: String?,
    val title: String,
    val detail: String,
    val affectedStops: List<String> = emptyList(),
    val affectedStopIds: List<String> = emptyList(),
    val effectiveFrom: Instant? = null,
    val effectiveTo: Instant? = null,
    val resumedAt: Instant? = null,
    val weatherRelated: Boolean = false,
    val warningCode: String? = null,
    val headwayMinutes: Int? = null,
    val normalHeadwayMinutes: Int? = null,
    val source: ChangeSource,
    val isEstimate: Boolean = false
)

/** 天文台警告事件。 */
data class WeatherEvent(
    val key: String,
    val date: String,
    val warningCode: String,
    val warningName: String,
    val actionCode: String,
    val level: Int,
    val issueTime: Instant?,
    val updateTime: Instant?,
    val cancelTime: Instant?,
    val detail: String
)

/** 天氣對服務的影響等級。 */
enum class ServiceImpact(val labelTc: String, val severity: Int) {
    NORMAL("維持正常服務", 0),
    LIMITED("有限度服務（班次加密／減班）", 1),
    PARTIAL_SUSPENDED("部分路線暫停", 2),
    SUSPENDED("暫停服務", 3)
}

/** 天氣影響下的單條路線狀態。 */
data class WeatherRouteImpact(
    val routeKey: String,
    val routeNo: String,
    val operator: Operator,
    val bound: String,
    val destTc: String,
    val impact: ServiceImpact,
    val normalHeadwayMinutes: Int?,
    val affectedHeadwayMinutes: Int?,
    val diversionStops: List<String>,
    val note: String,
    val isEstimate: Boolean
)

/** 恢復時間表的一個階段。 */
data class RecoveryStage(
    val stage: Int,
    val minutesAfterDowngrade: Int,
    val estimatedAt: Instant?,
    val actualAt: Instant?,
    val routeCount: Int,
    val description: String
)

/** 天氣影響總覽（供「天氣影響」分頁使用）。 */
data class WeatherImpactSummary(
    val date: String,
    val activeEvents: List<WeatherEvent>,
    val affectedRoutes: List<WeatherRouteImpact>,
    val recoveryStages: List<RecoveryStage>,
    val affectedRouteCount: Int,
    val restoredRouteCount: Int,
    val isEstimate: Boolean
)
