package hk.transit.eta.data.repository

import com.google.gson.Gson
import hk.transit.eta.core.util.TimeUtil
import hk.transit.eta.core.util.TrafficNewsParser
import hk.transit.eta.data.local.UserPreferences
import hk.transit.eta.data.local.db.AppDatabase
import hk.transit.eta.data.local.db.DailyChangeEntity
import hk.transit.eta.data.local.db.RouteEntity
import hk.transit.eta.data.local.db.SyncLogEntity
import hk.transit.eta.data.remote.ApiConstants
import hk.transit.eta.data.remote.NetworkClient
import hk.transit.eta.domain.NewsClassifier
import hk.transit.eta.domain.model.ChangeScope
import hk.transit.eta.domain.model.ChangeSource
import hk.transit.eta.domain.model.ChangeType
import hk.transit.eta.domain.model.Operator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * 運輸署「特別交通消息（第二代）」。
 *
 * 這是目前唯一由政府即時發放、可用於判斷「當日臨時改道／取消／恢復」的公開資料，
 * 以 XML 形式提供，故以關鍵字分類後再寫入變動記錄。
 */
class NewsRepository(
    private val database: AppDatabase,
    private val prefs: UserPreferences
) {

    private val static = NetworkClient.static()
    private val gson: Gson = NetworkClient.gson()

    data class NewsSyncResult(
        val changeCount: Int,
        /** 偵測到「恢復正常」的路線號碼 → 實際恢復時間 */
        val resumedRoutes: Map<String, java.time.Instant>
    )

    suspend fun sync(date: String = TimeUtil.today()): NewsSyncResult = withContext(Dispatchers.IO) {
        val xml = try {
            static.raw("${ApiConstants.TD_NEWS_BASE}${ApiConstants.TD_NEWS_TC}").string()
        } catch (e: Exception) {
            recordFailure(e)
            return@withContext NewsSyncResult(0, emptyMap())
        }

        val items = try {
            TrafficNewsParser.parse(xml)
        } catch (e: Exception) {
            recordFailure(e)
            return@withContext NewsSyncResult(0, emptyMap())
        }

        val routes = database.routeDao().byOperators(Operator.entries.map { it.code })
        val routesByNumber = routes.groupBy { it.routeNo.uppercase() }

        val changes = mutableListOf<DailyChangeEntity>()
        val resumed = mutableMapOf<String, java.time.Instant>()

        for (item in items) {
            val text = if (item.tc().isNotBlank()) item.tc() else item.en()
            if (text.isBlank()) continue
            val published = item.publishedAt ?: item.announcedAt
            // 只處理「今日」的消息，避免把歷史消息算進當日變動
            if (published != null && TimeUtil.dateKey(published) != date) continue

            val classification = NewsClassifier.classify(text)
            if (classification.changeTypes.isEmpty()) continue

            val matchedRoutes = classification.routeNumbers
                .mapNotNull { number -> routesByNumber[number]?.firstOrNull() }

            if (classification.restoration) {
                val at = published ?: TimeUtil.now()
                if (classification.routeNumbers.isEmpty()) {
                    // 全域性恢復：記錄到一個約定鍵，供天氣模組使用
                    resumed["*"] = at
                } else {
                    classification.routeNumbers.forEach { number -> resumed[number.uppercase()] = at }
                }
            }

            val types = classification.changeTypes.filter { it != ChangeType.RESTORED }
                .ifEmpty { listOf(ChangeType.RESTORED) }

            for (type in types) {
                for (route in matchedRoutes) {
                    changes += buildChange(
                        date = date,
                        type = type,
                        route = route,
                        text = text,
                        publishedAt = published,
                        classification = classification,
                        itemId = item.id
                    )
                }
                if (matchedRoutes.isEmpty() && type != ChangeType.RESTORED) {
                    // 未能對應到具體路線（例如區域性改道），仍寫入一筆全域記錄
                    changes += buildGeneralChange(
                        date = date,
                        type = type,
                        text = text,
                        publishedAt = published,
                        classification = classification,
                        itemId = item.id
                    )
                }
            }
        }

        insertChanges(changes)
        database.syncLogDao().upsert(
            SyncLogEntity(
                kind = KIND_NEWS,
                lastSyncAt = System.currentTimeMillis(),
                itemCount = changes.size,
                success = true,
                message = null
            )
        )
        prefs.lastNewsSync = System.currentTimeMillis()
        NewsSyncResult(changes.size, resumed)
    }

    private fun buildChange(
        date: String,
        type: ChangeType,
        route: RouteEntity,
        text: String,
        publishedAt: java.time.Instant?,
        classification: NewsClassifier.Classification,
        itemId: String
    ): DailyChangeEntity {
        val operator = Operator.fromCode(route.operatorCode) ?: Operator.KMB
        val isDiversion = type == ChangeType.DIVERSION
        return DailyChangeEntity(
            date = date,
            scope = ChangeScope.ROUTE.name,
            changeType = type.name,
            operatorCode = operator.code,
            routeKey = route.routeKey,
            routeNo = route.routeNo,
            bound = route.bound,
            stopKey = null,
            stopId = null,
            title = "${if (isDiversion) "臨時改道" else type.labelTc}・${operator.labelTc} ${route.routeNo}",
            detail = buildString {
                append("消息原文：\n$text")
                append("\n\n路線：${route.nameTc}")
                if (classification.stopNames.isNotEmpty()) {
                    append("\n受影響車站：${classification.stopNames.joinToString("、")}")
                }
                if (classification.matchedKeywords.isNotEmpty()) {
                    append("\n觸發關鍵字：${classification.matchedKeywords.joinToString("、")}")
                }
                publishedAt?.let { append("\n運輸署發布時間：${TimeUtil.formatDateTime(it)}") }
                append("\n\n來源：運輸署特別交通消息（第二代）")
            },
            affectedStopsJson = gson.toJsonTree(classification.stopNames).toString(),
            affectedStopIdsJson = "[]",
            effectiveFrom = publishedAt?.toEpochMilli(),
            effectiveTo = null,
            resumedAt = if (classification.restoration) publishedAt?.toEpochMilli() else null,
            weatherRelated = classification.weatherRelated,
            warningCode = null,
            headwayMinutes = null,
            normalHeadwayMinutes = null,
            source = ChangeSource.TD_NEWS.name,
            isEstimate = false,
            createdAt = System.currentTimeMillis(),
            dedupKey = "NEWS|${type.name}|${route.routeKey}|$itemId|$date"
        )
    }

    private fun buildGeneralChange(
        date: String,
        type: ChangeType,
        text: String,
        publishedAt: java.time.Instant?,
        classification: NewsClassifier.Classification,
        itemId: String
    ): DailyChangeEntity {
        val operators = NewsClassifier.inferOperators(text)
        val operator = operators.firstOrNull() ?: Operator.KMB
        return DailyChangeEntity(
            date = date,
            scope = ChangeScope.ROUTE.name,
            changeType = type.name,
            operatorCode = operator.code,
            routeKey = null,
            routeNo = classification.routeNumbers.firstOrNull(),
            bound = null,
            stopKey = null,
            stopId = null,
            title = "${if (type == ChangeType.DIVERSION) "臨時改道" else type.labelTc}・區域性交通安排",
            detail = buildString {
                append("消息原文：\n$text")
                if (classification.routeNumbers.isNotEmpty()) {
                    append("\n\n涉及路線：${classification.routeNumbers.joinToString("、")}")
                }
                if (classification.stopNames.isNotEmpty()) {
                    append("\n受影響車站：${classification.stopNames.joinToString("、")}")
                }
                publishedAt?.let { append("\n運輸署發布時間：${TimeUtil.formatDateTime(it)}") }
                append("\n\n來源：運輸署特別交通消息（第二代）")
            },
            affectedStopsJson = gson.toJsonTree(classification.stopNames).toString(),
            affectedStopIdsJson = "[]",
            effectiveFrom = publishedAt?.toEpochMilli(),
            effectiveTo = null,
            resumedAt = if (classification.restoration) publishedAt?.toEpochMilli() else null,
            weatherRelated = classification.weatherRelated,
            warningCode = null,
            headwayMinutes = null,
            normalHeadwayMinutes = null,
            source = ChangeSource.TD_NEWS.name,
            isEstimate = false,
            createdAt = System.currentTimeMillis(),
            dedupKey = "NEWSGEN|${type.name}|$itemId|$date"
        )
    }

    private suspend fun insertChanges(changes: List<DailyChangeEntity>) {
        if (changes.isEmpty()) return
        val existing = mutableSetOf<String>()
        changes.map { it.dedupKey }.chunked(900).forEach { chunk ->
            existing += database.dailyChangeDao().existing(changes.first().date, chunk)
                .map { it.dedupKey }
        }
        val newOnes = changes.filter { it.dedupKey !in existing }.distinctBy { it.dedupKey }
        if (newOnes.isNotEmpty()) database.dailyChangeDao().insertAll(newOnes)
    }

    private suspend fun recordFailure(e: Exception) {
        database.syncLogDao().upsert(
            SyncLogEntity(
                kind = KIND_NEWS,
                lastSyncAt = System.currentTimeMillis(),
                itemCount = 0,
                success = false,
                message = e.message
            )
        )
    }

    companion object {
        const val KIND_NEWS = "news"
    }
}
