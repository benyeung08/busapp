package hk.transit.eta.domain

import hk.transit.eta.domain.model.EtaEntry
import hk.transit.eta.domain.model.EtaSource
import hk.transit.eta.domain.model.StopEtaBoard
import hk.transit.eta.domain.model.StopRole
import java.time.Instant

/**
 * 燈號階段。
 *
 * 命名對應需求的三種車站角色：
 *  - ORIGIN_*   起點站
 *  - STOP_*     中途站
 *  - TERMINUS_* 終點站
 */
enum class SignalPhase {
    SCHEDULED,           // 一般等候（>5 分鐘或 2–5 分鐘）
    ORIGIN_PREPARE,      // 起點站 2–5 分鐘：閃爍「本班車即將開出」
    ORIGIN_DEPARTING,    // 起點站 ≤1 分鐘：「本班車開出中」，其後顯示下一班
    STOP_ARRIVING,       // 中途站 ≤1 分鐘：閃爍「本班車即將到站」
    STOP_DEPARTED,       // 中途站 已離站：「本班車離站中」，其後顯示下一班
    TERMINUS_ARRIVED,    // 終點站 ≤1 分鐘：閃爍「本班車已到達終點站，請所有乘客落車。」
    NO_SERVICE,          // 暫無班次
    SERVICE_ENDED,       // 尾班車已過
    DATA_UNAVAILABLE     // 未能取得資料
}

enum class SignalColour { GREEN, AMBER, RED, GREY }

/**
 * 燈號運算結果。文案由 UI 依 phase 對應 string resource，
 * 令本引擎保持純邏輯、可獨立單元測試。
 */
data class SignalLight(
    val phase: SignalPhase,
    val colour: SignalColour,
    val flash: Boolean,
    val minutes: Int?,
    val nextMinutes: Int?,
    val countdownSeconds: Int?,
    val isEstimate: Boolean
)

object SignalThresholds {
    /** 起點站：距離開出 2–5 分鐘 → 閃爍「即將開出」。 */
    const val ORIGIN_FLASH_MIN_MINUTES = 2
    const val ORIGIN_FLASH_MAX_MINUTES = 5

    /** 起點站：≤1 分鐘 → 「本班車開出中」。 */
    const val ORIGIN_DEPARTING_MINUTES = 1

    /** 中途站：≤1 分鐘 → 閃爍「即將到站」。 */
    const val STOP_ARRIVING_MINUTES = 1

    /** 中途站：到站時間已過但仍在此寬限期內 → 「本班車離站中」。 */
    const val STOP_DEPARTED_GRACE_SECONDS = 60

    /** 終點站：≤1 分鐘 → 閃爍「已到達終點站」。 */
    const val TERMINUS_ARRIVED_MINUTES = 1

    /** 一般等候：≥6 分鐘綠燈，2–5 分鐘黃燈。 */
    const val AMBER_MAX_MINUTES = 5
}

object SignalLightEngine {

    /**
     * 依站序與總站數判斷車站角色。
     *
     * 重要：當總站數未知（<= 0，或尚未交換到路線站序）時，
     * 一律視為「中途站」。這是刻意的安全預設——
     * 若把未知當成「第 N/N 站」，每個車站都會被誤判為終點站，
     * 燈號便會一直顯示「已到達終點站，請所有乘客落車」。
     */
    fun resolveStopRole(stopSeq: Int, totalStops: Int): StopRole {
        if (totalStops <= 1) return StopRole.INTERMEDIATE
        if (stopSeq <= 0) return StopRole.INTERMEDIATE
        return when {
            stopSeq == 1 -> StopRole.ORIGIN
            stopSeq >= totalStops -> StopRole.TERMINUS
            else -> StopRole.INTERMEDIATE
        }
    }

    /**
     * 距離到站的分鐘數，採「無條件進位」。
     *
     * 用四捨五入會讓 90 秒後到站的班次顯示為 1 分鐘，
     * 令「≤1 分鐘」的紅燈提早 30 秒亮起；進位後 1 分鐘＝真正 60 秒內。
     */
    fun minutesBetween(now: Instant, target: Instant?): Int? {
        if (target == null) return null
        val seconds = (target.epochSecond - now.epochSecond).coerceAtLeast(-3600)
        return ceilDiv(seconds, 60L).toInt()
    }

    private fun ceilDiv(a: Long, b: Long): Long = Math.floorDiv(a, b) + if (a % b == 0L) 0 else 1

    fun secondsBetween(now: Instant, target: Instant?): Int? {
        if (target == null) return null
        return (target.epochSecond - now.epochSecond).toInt()
    }

    /**
     * 計算一條路線在某車站的燈號。
     *
     * @param board 該路線在該車站的所有到站預報（含站序、總站數）
     * @param now   目前時間（建議傳入伺服器時間或系統時間）
     */
    fun evaluate(board: StopEtaBoard, now: Instant = Instant.now()): SignalLight {
        val entries = board.entries
        if (entries.isEmpty()) {
            return SignalLight(
                phase = if (board.hasRealtime) SignalPhase.NO_SERVICE else SignalPhase.DATA_UNAVAILABLE,
                colour = SignalColour.GREY,
                flash = false,
                minutes = null,
                nextMinutes = null,
                countdownSeconds = null,
                isEstimate = false
            )
        }

        val upcoming = entries
            .filter { it.eta == null || !it.eta.isBefore(now) }
            .sortedWith { a, b ->
                when {
                    a.eta == null && b.eta == null -> 0
                    a.eta == null -> 1      // 無資料的班次排最後
                    b.eta == null -> -1
                    else -> a.eta!!.compareTo(b.eta!!)
                }
            }
        val justDeparted = entries
            .filter { it.eta != null && it.eta.isBefore(now) }
            .maxByOrNull { it.eta!! }

        val current = upcoming.firstOrNull()
        val next = upcoming.getOrNull(1)

        val isEstimate = current?.source == EtaSource.SCHEDULE

        if (current == null) {
            // 所有班次時間已過
            val grace = justDeparted?.eta
                ?.let { now.epochSecond - it.epochSecond }
                ?: Long.MAX_VALUE
            return if (grace <= SignalThresholds.STOP_DEPARTED_GRACE_SECONDS &&
                board.stopRole == StopRole.INTERMEDIATE
            ) {
                SignalLight(
                    phase = SignalPhase.STOP_DEPARTED,
                    colour = SignalColour.GREY,
                    flash = false,
                    minutes = null,
                    nextMinutes = null,
                    countdownSeconds = grace.toInt(),
                    isEstimate = isEstimate
                )
            } else {
                SignalLight(
                    phase = SignalPhase.SERVICE_ENDED,
                    colour = SignalColour.GREY,
                    flash = false,
                    minutes = null,
                    nextMinutes = null,
                    countdownSeconds = null,
                    isEstimate = false
                )
            }
        }

        val minutes = minutesBetween(now, current.eta)
        val seconds = secondsBetween(now, current.eta)
        val nextMinutes = minutesBetween(now, next?.eta)

        if (minutes == null || current.eta == null) {
            return SignalLight(
                phase = SignalPhase.NO_SERVICE,
                colour = SignalColour.GREY,
                flash = false,
                minutes = null,
                nextMinutes = nextMinutes,
                countdownSeconds = null,
                isEstimate = isEstimate
            )
        }

        return when (board.stopRole) {
            StopRole.ORIGIN -> evaluateOrigin(minutes, seconds, nextMinutes, isEstimate)
            StopRole.INTERMEDIATE -> evaluateIntermediate(
                minutes = minutes,
                seconds = seconds,
                nextMinutes = nextMinutes,
                justDepartedSeconds = justDeparted?.eta?.let { now.epochSecond - it.epochSecond }?.toInt(),
                isEstimate = isEstimate
            )
            StopRole.TERMINUS -> evaluateTerminus(minutes, seconds, isEstimate)
        }
    }

    private fun evaluateOrigin(
        minutes: Int,
        seconds: Int?,
        nextMinutes: Int?,
        isEstimate: Boolean
    ): SignalLight = when {
        minutes <= SignalThresholds.ORIGIN_DEPARTING_MINUTES -> SignalLight(
            phase = SignalPhase.ORIGIN_DEPARTING,
            colour = SignalColour.RED,
            flash = false,
            minutes = minutes,
            nextMinutes = nextMinutes,
            countdownSeconds = seconds,
            isEstimate = isEstimate
        )

        minutes in SignalThresholds.ORIGIN_FLASH_MIN_MINUTES..SignalThresholds.ORIGIN_FLASH_MAX_MINUTES -> SignalLight(
            phase = SignalPhase.ORIGIN_PREPARE,
            colour = SignalColour.AMBER,
            flash = true,
            minutes = minutes,
            nextMinutes = nextMinutes,
            countdownSeconds = seconds,
            isEstimate = isEstimate
        )

        else -> SignalLight(
            phase = SignalPhase.SCHEDULED,
            colour = SignalColour.GREEN,
            flash = false,
            minutes = minutes,
            nextMinutes = nextMinutes,
            countdownSeconds = seconds,
            isEstimate = isEstimate
        )
    }

    private fun evaluateIntermediate(
        minutes: Int,
        seconds: Int?,
        nextMinutes: Int?,
        justDepartedSeconds: Int?,
        isEstimate: Boolean
    ): SignalLight {
        // 剛離站：於寬限期內顯示「本班車離站中」，其後顯示下一班車時間
        if (justDepartedSeconds != null &&
            justDepartedSeconds <= SignalThresholds.STOP_DEPARTED_GRACE_SECONDS &&
            minutes > SignalThresholds.STOP_ARRIVING_MINUTES
        ) {
            return SignalLight(
                phase = SignalPhase.STOP_DEPARTED,
                colour = SignalColour.GREY,
                flash = false,
                minutes = minutes,
                nextMinutes = nextMinutes,
                countdownSeconds = seconds,
                isEstimate = isEstimate
            )
        }

        return when {
            minutes <= SignalThresholds.STOP_ARRIVING_MINUTES -> SignalLight(
                phase = SignalPhase.STOP_ARRIVING,
                colour = SignalColour.RED,
                flash = true,
                minutes = minutes,
                nextMinutes = nextMinutes,
                countdownSeconds = seconds,
                isEstimate = isEstimate
            )

            minutes <= SignalThresholds.AMBER_MAX_MINUTES -> SignalLight(
                phase = SignalPhase.SCHEDULED,
                colour = SignalColour.AMBER,
                flash = false,
                minutes = minutes,
                nextMinutes = nextMinutes,
                countdownSeconds = seconds,
                isEstimate = isEstimate
            )

            else -> SignalLight(
                phase = SignalPhase.SCHEDULED,
                colour = SignalColour.GREEN,
                flash = false,
                minutes = minutes,
                nextMinutes = nextMinutes,
                countdownSeconds = seconds,
                isEstimate = isEstimate
            )
        }
    }

    private fun evaluateTerminus(minutes: Int, seconds: Int?, isEstimate: Boolean): SignalLight = when {
        minutes <= SignalThresholds.TERMINUS_ARRIVED_MINUTES -> SignalLight(
            phase = SignalPhase.TERMINUS_ARRIVED,
            colour = SignalColour.RED,
            flash = true,
            minutes = minutes,
            nextMinutes = null,
            countdownSeconds = seconds,
            isEstimate = isEstimate
        )

        minutes <= SignalThresholds.AMBER_MAX_MINUTES -> SignalLight(
            phase = SignalPhase.SCHEDULED,
            colour = SignalColour.AMBER,
            flash = false,
            minutes = minutes,
            nextMinutes = null,
            countdownSeconds = seconds,
            isEstimate = isEstimate
        )

        else -> SignalLight(
            phase = SignalPhase.SCHEDULED,
            colour = SignalColour.GREEN,
            flash = false,
            minutes = minutes,
            nextMinutes = null,
            countdownSeconds = seconds,
            isEstimate = isEstimate
        )
    }
}

/**
 * 純文字版文案（供通知、小工具或非 Compose 環境使用）。
 * UI 內請優先使用 string resource 版本。
 */
object SignalTexts {
    fun headline(phase: SignalPhase, minutes: Int?): String = when (phase) {
        SignalPhase.ORIGIN_PREPARE -> "本班車即將開出"
        SignalPhase.ORIGIN_DEPARTING -> "本班車開出中"
        SignalPhase.STOP_ARRIVING -> "本班車即將到站"
        SignalPhase.STOP_DEPARTED -> "本班車離站中"
        SignalPhase.TERMINUS_ARRIVED -> "本班車已到達終點站，請所有乘客落車。"
        SignalPhase.NO_SERVICE -> "暫無班次"
        SignalPhase.SERVICE_ENDED -> "尾班車已過"
        SignalPhase.DATA_UNAVAILABLE -> "未能取得即時資料"
        SignalPhase.SCHEDULED -> scheduledText(minutes)
    }

    /**
     * SCHEDULED 階段的文案會隨車站角色而變，故由呼叫方傳入角色。
     */
    fun scheduledText(minutes: Int?, role: StopRole = StopRole.INTERMEDIATE): String {
        val m = minutes ?: return "班次資料整理中"
        return when (role) {
            StopRole.ORIGIN -> if (m <= 0) "即將開出" else "$m 分鐘後開出"
            StopRole.TERMINUS -> if (m <= 0) "即將到達終點站" else "$m 分鐘後到達終點站"
            StopRole.INTERMEDIATE -> if (m <= 0) "即將到站" else "$m 分鐘後到站"
        }
    }

    fun nextText(nextMinutes: Int?, nextEntry: EtaEntry?): String? {
        if (nextMinutes == null && nextEntry == null) return null
        val m = nextMinutes
        return if (m != null) "下一班：$m 分鐘" else "下一班：${nextEntry?.destTc ?: ""}"
    }
}
