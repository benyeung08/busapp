plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.google.devtools.ksp")
}

android {
    namespace = "hk.transit.eta"
    compileSdk = 34

    defaultConfig {
        applicationId = "hk.transit.eta"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables { useSupportLibrary = true }

        // 各資料源的基礎網址集中於 BuildConfig，方便日後切換鏡像／測試環境
        buildConfigField("String", "KMB_BASE", "\"https://data.etabus.gov.hk/\"")
        buildConfigField("String", "CTB_BASE", "\"https://rt.data.gov.hk/\"")
        buildConfigField("String", "GMB_BASE", "\"https://data.etagmb.gov.hk/\"")
        buildConfigField("String", "MTR_BASE", "\"https://rt.data.gov.hk/\"")
        buildConfigField("String", "HKO_BASE", "\"https://data.weather.gov.hk/weatherAPI/opendata/\"")
        buildConfigField("String", "TD_STATIC_BASE", "\"https://static.data.gov.hk/td/\"")
        buildConfigField("String", "TD_NEWS_BASE", "\"https://www.td.gov.hk/\"")
        buildConfigField("String", "MTR_OPEN_BASE", "\"https://opendata.mtr.com.hk/data/\"")

        // GitHub 後端資料集的來源倉庫。
        // 改成你自己的倉庫後，App 就會從那裡下載預處理好的資料集；
        // 資料集由 Build Dataset workflow 產生並提交到 data/ 目錄。
        buildConfigField("String", "DATASET_OWNER", "\"YOUR_GITHUB_USERNAME\"")
        buildConfigField("String", "DATASET_REPO", "\"hk-transit-eta\"")
        buildConfigField("String", "DATASET_BRANCH", "\"main\"")
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            applicationIdSuffix = ".debug"
            versionNameSuffix = "-debug"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
        freeCompilerArgs += listOf(
            "-opt-in=androidx.compose.material3.ExperimentalMaterial3Api",
            "-opt-in=androidx.compose.foundation.ExperimentalFoundationApi",
            "-opt-in=kotlinx.coroutines.ExperimentalCoroutinesApi",
            // DAO 介面內含 @Transaction 的預設方法，需以真正的 JVM default method 編譯，
            // 否則 Room 產生的 _Impl 會因找不到可繼承的實作而編譯失敗
            "-Xjvm-default=all"
        )
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.8"
    }

    packaging {
        resources {
            excludes += setOf(
                "/META-INF/{AL2.0,LGPL2.1}",
                "META-INF/DEPENDENCIES",
                "META-INF/LICENSE*"
            )
        }
    }

    androidResources {
        noCompress += listOf("json", "csv")
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.02.01")

    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.8.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.7.0")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.7.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.7.0")
    implementation("androidx.lifecycle:lifecycle-process:2.7.0")

    implementation(composeBom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.navigation:navigation-compose:2.7.7")

    // Room（每日路線／車站資料庫與每日變更記錄）
    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    ksp("androidx.room:room-compiler:2.6.1")

    // 網絡
    implementation("com.squareup.retrofit2:retrofit:2.11.0")
    implementation("com.squareup.retrofit2:converter-gson:2.11.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("com.squareup.okhttp3:logging-interceptor:4.12.0")
    implementation("com.google.code.gson:gson:2.11.0")

    //背景全自動更新
    implementation("androidx.work:work-runtime-ktx:2.9.0")

    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    debugImplementation("androidx.compose.ui:ui-tooling")
    debugImplementation("androidx.compose.ui:ui-test-manifest")
}
