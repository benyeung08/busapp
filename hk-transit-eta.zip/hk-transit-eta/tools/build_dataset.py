#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
後端資料集產生器（在 GitHub Actions 上執行）
==========================================

把各政府資料來源彙整成 App 可直接匯入的精簡 JSON，放到 `data/` 後由 workflow 提交回倉庫。

為什麼要搬到 GitHub
-------------------
1. 每日比對需要「昨日的快照」。放在裝置上會因清除資料、重裝、換機而遺失，
   導致變動偵測失效；放在 git 裡則有完整歷史，且可比對任意兩天。
2. 港鐵巴士的 busStopId 對照表必須逐條路線呼叫政府 API 才能建立。
   改在 CI 上做，不但節省裝置流量，失敗時也能直接從 workflow log 看出原因。
3. 裝置只需下載一份處理好的資料，不必在手機上解析數 MB 的 CSV
   （舊做法在慢速網絡下常逾時，也是同步失敗的主因之一）。

即時到站為什麼不一起放上 GitHub
-------------------------------
到站預報每 10 秒至 1 分鐘就會變動，放到靜態檔只會得到過期資料。
因此 ETA 仍由 App 直接呼叫政府 API；GitHub 只提供「查詢 ETA 所需的對照資訊」
（例如港鐵巴士的 busStopId）。

輸出檔案（全部放在 data/）
-------------------------
- manifest.json     版本與各檔資訊，App 先用它判斷是否需要更新
- routes.json       所有路線
- stops.json        所有車站
- route_stops.json  路線—車站關係（含站序），以索引陣列壓縮
- mtr_bus_map.json  港鐵巴士「站序 → busStopId」對照表
- changes.json      當日路線／車站變動（比對昨日快照）
- weather.json      天文台警告與推算的影響
- news.json         運輸署特別交通消息（改道／取消／恢復）

用法
----
    python3 tools/build_dataset.py                    # 產生到 data/
    python3 tools/build_dataset.py --skip-mtr-bus     # 略過港鐵巴士（除錯用）

只使用 Python 標準庫，CI 不需安裝任何套件。
"""

import argparse
import csv
import hashlib
import io
import json
import os
import re
import sys
import urllib.error
import urllib.request
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta, timezone

UA = "HKTransitETA-DatasetBuilder/1.0 (GitHub Actions)"
TIMEOUT = 120

HKT = timezone(timedelta(hours=8))

TD_STATIC = "https://static.data.gov.hk/td/"
MTR_BUS_API = "https://rt.data.gov.hk/v1/transport/mtr/bus/getSchedule"
KMB_BASE = "https://data.etabus.gov.hk/v1/transport/kmb"
CTB_BASE = "https://rt.data.gov.hk/v2/transport/citybus"
NLB_BASE = "https://rt.data.gov.hk/v2/transport/nlb"
GMB_BASE = "https://data.etagmb.gov.hk"
HKO_BASE = "https://data.weather.gov.hk/weatherAPI/opendata/weather.php"
TD_NEWS = "https://www.td.gov.hk/tc/special_news/trafficnews.xml"

MTR_BUS_COMPANY = "LRTFEEDER"
OUT_DIR = "data"
SNAP_DIR = os.path.join(OUT_DIR, "snapshots")

# 營辦商代碼，必須與 Kotlin 的 Operator enum 完全一致
OP_KMB, OP_CTB, OP_NLB, OP_GMB = "KMB", "CTB", "NLB", "GMB"
OP_MTR_HR, OP_MTR_LR, OP_MTR_BUS = "MTR", "LRT", "MTRBUS"
OP_TD_BUS, OP_TD_GMB = "TD", "TDG"


# ----------------------------------------------------------------------
# HTTP / 工具
# ----------------------------------------------------------------------

def http_get(url, encoding="utf-8-sig"):
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "*/*"})
    with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
        return resp.read().decode(encoding, errors="replace")


def get_json(url):
    return json.loads(http_get(url))


def post_json(url, payload):
    """委派給 [http_post_json]，讓測試能攔截 HTTP 層。"""
    return json.loads(http_post_json(url, payload))


def parse_csv(text):
    """解析 CSV；防禦性剝除 BOM，避免首欄名被污染導致比對全數落空。"""
    if not text.strip():
        return []
    return list(csv.DictReader(io.StringIO(text.lstrip("\ufeff"))))


def fingerprint(*parts):
    """與 Kotlin Fingerprint.of 對等：以 | 串接後取 SHA-1。"""
    joined = "|".join("" if p is None else str(p) for p in parts)
    return hashlib.sha1(joined.encode("utf-8")).hexdigest()


def today_hkt():
    return datetime.now(HKT).strftime("%Y-%m-%d")


def log(msg):
    print(msg, flush=True)


def warn(msg):
    """輸出 GitHub Actions 可辨識的警告標記。"""
    print(f"::warning::{msg}", flush=True)


# ----------------------------------------------------------------------
# 鍵值規則（必須與 Kotlin 端一致）
# ----------------------------------------------------------------------

def route_key(op, route_no, bound, service_type):
    return f"{op}|{route_no}|{bound}|{service_type}"


def stop_key(op, stop_id):
    return f"{op}|{stop_id}"


def td_route_key(op, route_id):
    return f"{op}|{route_id}"


def mtr_bus_route_key(route_id, route_seq):
    return f"{OP_MTR_BUS}|{route_id}|{route_seq}"


def mtr_bus_bound(route_seq):
    return "I" if route_seq.strip() == "2" else "O"


def company_to_operator(code, is_bus):
    """對應 TdStaticRepository.mapCompany。"""
    return OP_TD_GMB if code.strip().upper() == "GMB" else (OP_TD_BUS if is_bus else OP_TD_GMB)


# ----------------------------------------------------------------------
# 1. 運輸署靜態目錄
# ----------------------------------------------------------------------

def td_path(name):
    return TD_STATIC + "routes-and-fares/" + name


def build_td_catalogue():
    """下載運輸署路線／車站／站序，回傳 (routes, stops, route_stops)。"""
    log("下載運輸署路線及收費資料…")
    route_bus = parse_csv(http_get(td_path("ROUTE_BUS.csv")))
    route_gmb = parse_csv(http_get(td_path("ROUTE_GMB.csv")))
    stop_bus = parse_csv(http_get(td_path("STOP_BUS.csv")))
    stop_gmb = parse_csv(http_get(td_path("STOP_GMB.csv")))
    rstop_bus = parse_csv(http_get(td_path("RSTOP_BUS.csv")))
    rstop_gmb = parse_csv(http_get(td_path("RSTOP_GMB.csv")))
    log(f"  路線 {len(route_bus)+len(route_gmb)}、車站 {len(stop_bus)+len(stop_gmb)}、"
        f"站序 {len(rstop_bus)+len(rstop_gmb)} 列")

    routes, stops, route_stops = [], [], []

    # 巴士（排除 LRTFEEDER，港鐵巴士另有專屬處理）
    mtr_route_ids = {r.get("ROUTE_ID", "") for r in route_bus
                     if (r.get("COMPANY_CODE") or "").strip().upper() == MTR_BUS_COMPANY}
    for row in route_bus:
        company = row.get("COMPANY_CODE", "")
        if company.strip().upper() == MTR_BUS_COMPANY:
            continue
        route_id = row.get("ROUTE_ID", "").strip()
        if not route_id:
            continue
        op = company_to_operator(company, True)
        routes.append(make_route(td_route_key(op, route_id), op, company, row))

    # 小巴
    for row in route_gmb:
        route_id = row.get("ROUTE_ID", "").strip()
        if not route_id:
            continue
        op = company_to_operator(row.get("COMPANY_CODE", ""), False)
        routes.append(make_route(td_route_key(op, route_id), op,
                                 row.get("COMPANY_CODE", ""), row))

    # 車站
    for row, is_bus in ((stop_bus, True), (stop_gmb, False)):
        op = OP_TD_BUS if is_bus else OP_TD_GMB
        for r in row:
            sid = r.get("STOP_ID", "").strip()
            if not sid:
                continue
            stops.append(make_stop(stop_key(op, sid), op, sid, r))

    # 站序（排除港鐵巴士，其去回程需分開處理）
    for rows, is_bus in ((rstop_bus, True), (rstop_gmb, False)):
        op = OP_TD_BUS if is_bus else OP_TD_GMB
        for r in rows:
            rid = r.get("ROUTE_ID", "").strip()
            sid = r.get("STOP_ID", "").strip()
            if not rid or not sid or rid in mtr_route_ids:
                continue
            seq = to_int(r.get("STOP_SEQ"))
            if seq is None:
                continue
            route_stops.append({
                "routeKey": td_route_key(op, rid),
                "stopSeq": seq,
                "stopKey": stop_key(op, sid),
                "stopId": sid,
                "nameTc": r.get("STOP_NAMEC", ""),
                "nameEn": r.get("STOP_NAMEE", ""),
                "lat": 0.0, "lng": 0.0,
            })

    return routes, stops, route_stops, mtr_route_ids, route_bus, rstop_bus


def make_route(key, op, company, row):
    route_no = row.get("ROUTE_NAMEC", "").strip()
    return {
        "routeKey": key,
        "operatorCode": op,
        "companyCode": company,
        "routeNo": route_no,
        "bound": "O",
        "serviceType": to_int(row.get("SPECIAL_TYPE")) or 0,
        "nameTc": f"{route_no} {row.get('LOC_START_NAMEC','')}→{row.get('LOC_END_NAMEC','')}",
        "nameEn": f"{row.get('ROUTE_NAMEE','')} {row.get('LOC_START_NAMEE','')}→{row.get('LOC_END_NAMEE','')}",
        "originTc": row.get("LOC_START_NAMEC", ""),
        "originEn": row.get("LOC_START_NAMEE", ""),
        "destTc": row.get("LOC_END_NAMEC", ""),
        "destEn": row.get("LOC_END_NAMEE", ""),
        "fullFare": to_float(row.get("FULL_FARE")),
        "journeyTime": to_int(row.get("JOURNEY_TIME")) or 0,
        "specialType": to_int(row.get("SPECIAL_TYPE")) or 0,
        "serviceMode": row.get("SERVICE_MODE", ""),
        "hasRealtime": False,
    }


def make_stop(key, op, sid, row):
    return {
        "stopKey": key,
        "operatorCode": op,
        "stopId": sid,
        "nameTc": row.get("STOP_NAMEC", ""),
        "nameEn": row.get("STOP_NAMEE", ""),
        "lat": to_float(row.get("STOP_LAT")) or to_float(row.get("LATITUDE")) or 0.0,
        "lng": to_float(row.get("STOP_LONG")) or to_float(row.get("LONGITUDE")) or 0.0,
    }


def to_int(v):
    try:
        return int(str(v).strip())
    except (TypeError, ValueError):
        return None


def to_float(v):
    try:
        return float(str(v).strip())
    except (TypeError, ValueError):
        return None


# ----------------------------------------------------------------------
# 2. 港鐵巴士（含 busStopId 對照表）
# ----------------------------------------------------------------------

def build_mtr_bus(route_bus, rstop_bus):
    """
    港鐵巴士的目錄與對照表。

    routeKey 帶 ROUTE_SEQ，因為去程（1）與回程（2）各有自己的站序，
    混在一起會互相覆蓋，令燈號的角色判斷錯亂。

    對照表建立規則：政府 API 只接受 routeName、不帶方向，故只有當
    「恰好一個方向的車站數等於 API 回傳數量」時才認定為明確，
    否則寧可不建對照（App 會退回班次表並標示「推算」）。
    """
    master = {r.get("ROUTE_ID", ""): r for r in route_bus
              if (r.get("COMPANY_CODE") or "").strip().upper() == MTR_BUS_COMPANY}
    if not master:
        log("  找不到港鐵巴士路線，略過")
        return [], [], []

    rows = [r for r in rstop_bus if r.get("ROUTE_ID", "") in master]
    seq_counts = {}
    for r in rows:
        rid, seq = r.get("ROUTE_ID", ""), (r.get("ROUTE_SEQ") or "").strip()
        seq_counts.setdefault(rid, {})
        seq_counts[rid][seq] = seq_counts[rid].get(seq, 0) + 1

    routes, route_stops, mapping = [], [], []
    used_stops = set()

    for rid, row in master.items():
        route_no = (row.get("ROUTE_NAMEC") or "").strip()
        if not route_no:
            continue
        counts = seq_counts.get(rid, {})
        for seq in sorted(counts.keys() or ["1"]):
            key = mtr_bus_route_key(rid, seq)
            routes.append({
                "routeKey": key,
                "operatorCode": OP_MTR_BUS,
                "companyCode": MTR_BUS_COMPANY,
                "routeNo": route_no,
                "bound": mtr_bus_bound(seq),
                "serviceType": to_int(row.get("SPECIAL_TYPE")) or 0,
                "nameTc": f"{route_no} {row.get('LOC_START_NAMEC','')}→{row.get('LOC_END_NAMEC','')}",
                "nameEn": f"{row.get('ROUTE_NAMEE','')} {row.get('LOC_START_NAMEE','')}→{row.get('LOC_END_NAMEE','')}",
                "originTc": row.get("LOC_START_NAMEC", ""),
                "originEn": row.get("LOC_START_NAMEE", ""),
                "destTc": row.get("LOC_END_NAMEC", ""),
                "destEn": row.get("LOC_END_NAMEE", ""),
                "fullFare": to_float(row.get("FULL_FARE")),
                "journeyTime": to_int(row.get("JOURNEY_TIME")) or 0,
                "specialType": to_int(row.get("SPECIAL_TYPE")) or 0,
                "serviceMode": row.get("SERVICE_MODE", ""),
                "hasRealtime": False,
            })
            for r in rows:
                if r.get("ROUTE_ID", "") != rid or (r.get("ROUTE_SEQ") or "").strip() != seq:
                    continue
                sid = r.get("STOP_ID", "").strip()
                sseq = to_int(r.get("STOP_SEQ"))
                if not sid or sseq is None:
                    continue
                used_stops.add(sid)
                route_stops.append({
                    "routeKey": key, "stopSeq": sseq,
                    "stopKey": stop_key(OP_MTR_BUS, sid), "stopId": sid,
                    "nameTc": r.get("STOP_NAMEC", ""), "nameEn": r.get("STOP_NAMEE", ""),
                    "lat": 0.0, "lng": 0.0,
                })

    # 車站主檔：只取港鐵巴士實際停靠的車站
    stop_bus = parse_csv(http_get(td_path("STOP_BUS.csv")))
    stops = [make_stop(stop_key(OP_MTR_BUS, r.get("STOP_ID", "").strip()),
                       OP_MTR_BUS, r.get("STOP_ID", "").strip(), r)
             for r in stop_bus if r.get("STOP_ID", "").strip() in used_stops]

    return routes, stops, route_stops


def build_mtr_bus_mapping(routes, route_stops):
    """逐條路線呼叫政府 API，建立「站序 → busStopId」對照表。"""
    counts = {}
    for rs in route_stops:
        counts[rs["routeKey"]] = counts.get(rs["routeKey"], 0) + 1

    by_no = {}
    for r in routes:
        by_no.setdefault(r["routeNo"].strip().upper(), []).append(r)

    mapping, ok = [], 0
    total = len(by_no)
    log(f"建立港鐵巴士對照表（共 {total} 條路線）…")

    for route_no, candidates in sorted(by_no.items()):
        try:
            dto = post_json(MTR_BUS_API, {"language": "zh", "routeName": route_no})
        except urllib.error.HTTPError as e:
            warn(f"港鐵巴士 {route_no}: HTTP {e.code}")
            continue
        except Exception as e:  # noqa: BLE001
            warn(f"港鐵巴士 {route_no}: {type(e).__name__}: {e}")
            continue

        if dto.get("status") not in (None, "1"):
            warn(f"港鐵巴士 {route_no}: status={dto.get('status')}")
            continue
        api_stops = dto.get("busStop") or []
        if not api_stops:
            continue

        # 只有車站數唯一匹配某方向時才算明確
        exact = [c for c in candidates if counts.get(c["routeKey"]) == len(api_stops)]
        if len(exact) != 1:
            warn(f"港鐵巴士 {route_no}: 方向無法唯一判定"
                 f"（API {len(api_stops)} 站，候選 {len(exact)} 個）")
            continue
        route = exact[0]

        for i, st in enumerate(api_stops):
            bid = st.get("busStopId")
            if not bid:
                continue
            mapping.append({
                "routeKey": route["routeKey"],
                "stopSeq": i + 1,          # API 陣列從 0 起，STOP_SEQ 從 1 起
                "busStopId": bid,
                "routeName": route_no,
            })
        ok += 1

    log(f"  成功建立 {ok} / {total} 條路線的對照表（{len(mapping)} 筆）")
    if total and ok == 0:
        warn("港鐵巴士對照表全數失敗，請檢查 routeName 與 ROUTE_NAMEC 是否一致")
    return mapping, {m["routeKey"] for m in mapping}


# ----------------------------------------------------------------------
# 3. 各營辦商的即時路線（用來標記 hasRealtime）
# ----------------------------------------------------------------------

def fetch_realtime_route_numbers():
    """
    取得有即時到站服務的路線號集合（分營辦商）。

    失敗不中斷：某個營辦商掛掉時，只是該批路線標記為沒有即時資料，
    App 仍會對它們改用班次表推算。
    """
    result = {OP_KMB: set(), OP_CTB: set(), OP_NLB: set(), OP_GMB: set()}
    no_map = {}

    try:
        data = get_json(f"{KMB_BASE}/route/")["data"]
        for r in data:
            result[OP_KMB].add(r["route"].strip().upper())
        log(f"  九巴／龍運即時路線 {len(result[OP_KMB])} 條")
    except Exception as e:  # noqa: BLE001
        warn(f"九巴路線下載失敗：{e}")

    try:
        data = get_json(f"{CTB_BASE}/route/CTB")["data"]
        for r in data:
            result[OP_CTB].add(r["route"].strip().upper())
        log(f"  城巴即時路線 {len(result[OP_CTB])} 條")
    except Exception as e:  # noqa: BLE001
        warn(f"城巴路線下載失敗：{e}")

    try:
        data = get_json(f"{NLB_BASE}/route.php?action=list")["routes"]
        for r in data:
            result[OP_NLB].add(str(r.get("routeNo", "")).strip().upper())
            # 記下 routeNo → routeId，供 App 查詢 ETA 時使用
            if r.get("routeId") and r.get("routeNo"):
                no_map[str(r["routeNo"]).strip().upper()] = str(r["routeId"])
        log(f"  新大嶼山巴士即時路線 {len(result[OP_NLB])} 條")
    except Exception as e:  # noqa: BLE001
        warn(f"新大嶼山巴士路線下載失敗：{e}")

    for region in ("HKI", "KLN", "NT"):
        try:
            data = get_json(f"{GMB_BASE}/route/{region}")["data"]["routes"]
            for r in data:
                result[OP_GMB].add(str(r.get("route_code", "")).strip().upper())
        except Exception as e:  # noqa: BLE001
            warn(f"專線小巴 {region} 路線下載失敗：{e}")
    log(f"  專線小巴即時路線 {len(result[OP_GMB])} 條")

    return result, no_map


# ----------------------------------------------------------------------
# 4. 每日變動（比對昨日快照）
# ----------------------------------------------------------------------

def load_previous_snapshots():
    """讀取上一次產生的快照；不存在時回傳空（首次執行只建基準）。"""
    out = {"routes": {}, "stops": {}}
    for kind in ("routes", "stops"):
        path = os.path.join(SNAP_DIR, f"{kind}.json")
        if os.path.exists(path):
            try:
                with open(path, encoding="utf-8") as fh:
                    out[kind] = json.load(fh)
            except Exception as e:  # noqa: BLE001
                warn(f"快照 {path} 讀取失敗（視為首次執行）：{e}")
                out[kind] = {}
        else:
            log(f"  找不到 {path}，本次將建立基準快照")
    return out


def compute_changes(date, routes, stops, route_stops, prev):
    """比對快照，產生當日變動。首次執行不產生任何變動。"""
    counts, seqs = {}, {}
    for rs in route_stops:
        counts[rs["routeKey"]] = counts.get(rs["routeKey"], 0) + 1
        seqs.setdefault(rs["routeKey"], []).append((rs["stopSeq"], rs["stopId"]))

    def seq_fp(key):
        return fingerprint(*[f"{s}:{i}" for s, i in sorted(seqs.get(key, []))])

    cur_routes = {}
    for r in routes:
        key = r["routeKey"]
        cur_routes[key] = {
            "fingerprint": fingerprint(r["nameTc"], r["originTc"], r["destTc"],
                                       r["serviceType"], r["specialType"],
                                       r["serviceMode"], counts.get(key, 0), seq_fp(key)),
            "nameTc": r["nameTc"], "originTc": r["originTc"], "destTc": r["destTc"],
            "fullFare": r["fullFare"], "journeyTime": r["journeyTime"],
            "stopCount": counts.get(key, 0), "stopFingerprint": seq_fp(key),
        }

    cur_stops = {}
    for s in stops:
        cur_stops[s["stopKey"]] = {
            "fingerprint": fingerprint(s["nameTc"], s["nameEn"],
                                       f"{s['lat']:.6f}", f"{s['lng']:.6f}"),
            "nameTc": s["nameTc"], "nameEn": s["nameEn"],
            "lat": s["lat"], "lng": s["lng"],
        }

    changes = []
    prev_routes = prev.get("routes") or {}
    prev_stops = prev.get("stops") or {}

    # 首次建立基準時不視為變動，否則會把全港路線都報成「新增」
    if prev_routes:
        for key, cur in cur_routes.items():
            old = prev_routes.get(key)
            op = key.split("|")[0]
            route_no = key.split("|")[1] if "|" in key else None
            if old is None:
                changes.append(mk_change(date, "ROUTE", "ADDED", op, key, route_no,
                                         f"新增路線 {cur['nameTc']}",
                                         f"起點：{cur['originTc']}；終點：{cur['destTc']}"
                                         f"；車站 {cur['stopCount']} 個"))
            elif old.get("fingerprint") != cur["fingerprint"]:
                parts = []
                if old.get("nameTc") != cur["nameTc"]:
                    parts.append("路線名稱")
                if old.get("originTc") != cur["originTc"] or old.get("destTc") != cur["destTc"]:
                    parts.append("起訖點")
                if old.get("fullFare") != cur["fullFare"]:
                    parts.append("收費")
                if old.get("journeyTime") != cur["journeyTime"]:
                    parts.append("行車時間")
                if old.get("stopFingerprint") != cur["stopFingerprint"]:
                    parts.append("途經車站")
                if not parts:
                    parts = ["路線資料"]
                changes.append(mk_change(date, "ROUTE", "MODIFIED", op, key, route_no,
                                         f"修改路線 {cur['nameTc']}", "、".join(parts) + " 有變動"))

        for key in prev_routes:
            if key not in cur_routes:
                old = prev_routes[key]
                op = key.split("|")[0]
                route_no = key.split("|")[1] if "|" in key else None
                changes.append(mk_change(date, "ROUTE", "REMOVED", op, key, route_no,
                                         f"取消路線 {old.get('nameTc', route_no)}",
                                         "此路線已不在最新資料中"))

    if prev_stops:
        for key, cur in cur_stops.items():
            old = prev_stops.get(key)
            op = key.split("|")[0]
            sid = key.split("|")[1] if "|" in key else None
            if old is None:
                changes.append(mk_change(date, "STOP", "ADDED", op, None, None,
                                         f"新增車站 {cur['nameTc']}",
                                         f"站號 {sid}；位置 {cur['lat']:.5f}, {cur['lng']:.5f}",
                                         stop_key=key, stop_id=sid))
            elif old.get("fingerprint") != cur["fingerprint"]:
                moved = (abs(old.get("lat", 0) - cur["lat"]) > 0.00027 or
                         abs(old.get("lng", 0) - cur["lng"]) > 0.00027)
                kind = "移位" if moved else "改名"
                detail = (f"位置由 {old.get('lat'):.5f},{old.get('lng'):.5f} "
                          f"改為 {cur['lat']:.5f},{cur['lng']:.5f}") if moved \
                    else f"{old.get('nameTc','')} → {cur['nameTc']}"
                changes.append(mk_change(date, "STOP", "MODIFIED", op, None, None,
                                         f"{kind}：{cur['nameTc']}", detail,
                                         stop_key=key, stop_id=sid))
        for key in prev_stops:
            if key not in cur_stops:
                old = prev_stops[key]
                sid = key.split("|")[1] if "|" in key else None
                changes.append(mk_change(date, "STOP", "REMOVED", op=key.split("|")[0],
                                         route_key=None, route_no=None,
                                         title=f"取消車站 {old.get('nameTc', sid)}",
                                         detail=f"站號 {sid} 已不在最新資料中",
                                         stop_key=key, stop_id=sid))

    return changes, cur_routes, cur_stops


def mk_change(date, scope, ctype, op, route_key, route_no, title, detail,
              stop_key=None, stop_id=None):
    """產生一筆變動；dedupKey 與 Kotlin 端一致以便去重。"""
    dedup = fingerprint(date, scope, ctype, op, route_key or "", stop_key or "", title)
    return {
        "date": date, "scope": scope, "changeType": ctype, "operatorCode": op,
        "routeKey": route_key, "routeNo": route_no, "bound": None,
        "stopKey": stop_key, "stopId": stop_id,
        "title": title, "detail": detail,
        "affectedStops": [], "affectedStopIds": [],
        "weatherRelated": False, "source": "CATALOGUE_DIFF",
        "isEstimate": False, "dedupKey": dedup,
    }


# ----------------------------------------------------------------------
# 5. 天氣與交通消息
# ----------------------------------------------------------------------

def build_weather(date):
    try:
        data = get_json(f"{HKO_BASE}?dataType=warnsum&lang=tc")
    except Exception as e:  # noqa: BLE001
        warn(f"天文台警告下載失敗：{e}")
        return {"date": date, "events": [], "level": 0}

    events = []
    level = 0
    for code, name in (("WTCPRE8", "八號烈風或暴風信號"),
                       ("WTCPRE9", "九號烈風或暴風風力增強信號"),
                       ("WTCPRE10", "十號颶風信號"),
                       ("WRAINB", "黑色暴雨警告"),
                       ("WRAINR", "紅色暴雨警告"),
                       ("WRAINA", "黃色暴雨警告"),
                       ("WLNDSL", "山泥傾瀉警告"),
                       ("WTS", "雷暴警告")):
        if data.get(code) and str(data[code]).strip() not in ("", "0"):
            lvl = 3 if code in ("WTCPRE9", "WTCPRE10", "WRAINB") else \
                2 if code in ("WTCPRE8", "WRAINR", "WLNDSL") else 1
            events.append({
                "key": f"{date}-{code}", "date": date, "warningCode": code,
                "warningName": name, "actionCode": code, "level": lvl,
                "detail": str(data[code]),
            })
            level = max(level, lvl)
    log(f"  天文台生效警告 {len(events)} 項（最高級別 {level}）")
    return {"date": date, "events": events, "level": level}


def build_news(date):
    """解析運輸署特別交通消息，挑出改道／取消／恢復。"""
    try:
        xml_text = http_get(TD_NEWS)
        root = ET.fromstring(xml_text)
    except Exception as e:  # noqa: BLE001
        warn(f"運輸署交通消息下載或解析失敗：{e}")
        return []

    patterns = [
        ("DIVERSION", ("改道", "繞道", "改行", "臨時改")),
        ("REMOVED", ("取消", "停駛", "暫停服務", "停止服務")),
        ("RESTORED", ("恢復", "重開", "復常", "回復正常")),
    ]
    out = []
    for elem in root.iter():
        text = (elem.text or "").strip()
        if len(text) < 10:
            continue
        for ctype, keys in patterns:
            if any(k in text for k in keys):
                out.append({
                    "date": date, "scope": "ROUTE", "changeType": ctype,
                    "operatorCode": OP_TD_BUS, "routeKey": None, "routeNo": None,
                    "bound": None, "stopKey": None, "stopId": None,
                    "title": text[:40], "detail": text,
                    "affectedStops": [], "affectedStopIds": [],
                    "weatherRelated": False, "source": "TD_NEWS",
                    "isEstimate": False,
                    "dedupKey": fingerprint(date, "TD_NEWS", ctype, text[:60]),
                })
                break
    log(f"  運輸署交通消息 {len(out)} 則（改道／取消／恢復）")
    return out


# ----------------------------------------------------------------------
# 輸出
# ----------------------------------------------------------------------

def write_json(name, obj, compact=False):
    path = os.path.join(OUT_DIR, name)
    if compact:
        text = json.dumps(obj, ensure_ascii=False, separators=(",", ":"))
    else:
        text = json.dumps(obj, ensure_ascii=False, indent=1)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(text)
    size = os.path.getsize(path)
    log(f"  寫出 {name}（{size/1024:.0f} KB）")
    return size


def compress_route_stops(routes, stops, route_stops):
    """
    把 route_stops 由物件陣列壓成索引陣列，以縮減體積。

    站序是資料量最大者（逾十萬列），若每列都帶完整的 routeKey 與 stopKey
    字串，檔案會膨脹到數十 MB；改存索引後約可縮減一個數量級。
    """
    r_idx = {r["routeKey"]: i for i, r in enumerate(routes)}
    s_idx = {s["stopKey"]: i for i, s in enumerate(stops)}
    triples = []
    for rs in route_stops:
        r, s = r_idx.get(rs["routeKey"]), s_idx.get(rs["stopKey"])
        if r is None or s is None:
            continue
        triples.append([r, s, rs["stopSeq"]])
    return triples


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--skip-mtr-bus", action="store_true", help="略過港鐵巴士對照表")
    args = ap.parse_args()

    os.makedirs(OUT_DIR, exist_ok=True)
    os.makedirs(SNAP_DIR, exist_ok=True)
    date = today_hkt()
    log(f"產生 {date} 的資料集…\n")

    # 1. 運輸署目錄
    routes, stops, route_stops, _, route_bus, rstop_bus = build_td_catalogue()

    # 2. 港鐵巴士
    mtr_routes, mtr_stops, mtr_route_stops = build_mtr_bus(route_bus, rstop_bus)
    routes += mtr_routes
    stops += mtr_stops
    route_stops += mtr_route_stops
    log(f"  港鐵巴士路線 {len(mtr_routes)} 條、車站 {len(mtr_stops)} 個")

    mapping, mapped_keys = ([], set())
    if not args.skip_mtr_bus and mtr_routes:
        mapping, mapped_keys = build_mtr_bus_mapping(mtr_routes, mtr_route_stops)
    for r in routes:
        if r["routeKey"] in mapped_keys:
            r["hasRealtime"] = True

    # 3. 標記有即時到站的路線
    log("\n下載各營辦商即時路線清單…")
    rt_nos, nlb_ids = fetch_realtime_route_numbers()
    for r in routes:
        if r["operatorCode"] in (OP_TD_BUS, OP_TD_GMB):
            no = r["routeNo"].strip().upper()
            if r["operatorCode"] == OP_TD_BUS and no in rt_nos[OP_KMB] | rt_nos[OP_CTB]:
                r["hasRealtime"] = True
            elif r["operatorCode"] == OP_TD_GMB and no in rt_nos[OP_GMB]:
                r["hasRealtime"] = True

    # 4. 每日變動
    log("\n比對昨日快照…")
    prev = load_previous_snapshots()
    changes, cur_routes, cur_stops = compute_changes(
        date, routes, stops, route_stops, prev)
    log(f"  路線／車站變動 {len(changes)} 項")

    # 5. 天氣與交通消息
    log("\n下載天氣與交通消息…")
    weather = build_weather(date)
    news = build_news(date)
    changes += news

    # 6. 輸出
    log("\n寫出資料集…")
    triples = compress_route_stops(routes, stops, route_stops)
    sizes = {
        "routes": write_json("routes.json", routes, compact=True),
        "stops": write_json("stops.json", stops, compact=True),
        "route_stops": write_json("route_stops.json", triples, compact=True),
        "mtr_bus_map": write_json("mtr_bus_map.json", mapping, compact=True),
        "changes": write_json("changes.json", changes, compact=True),
        "weather": write_json("weather.json", weather, compact=True),
    }
    # 快照供明日比對（由 workflow 一併提交）
    write_json("snapshots/routes.json", cur_routes, compact=True)
    write_json("snapshots/stops.json", cur_stops, compact=True)

    manifest = {
        "date": date,
        "generatedAt": datetime.now(HKT).isoformat(),
        "version": int(datetime.now(HKT).timestamp()),
        "counts": {
            "routes": len(routes), "stops": len(stops),
            "routeStops": len(triples), "changes": len(changes),
            "mtrBusMap": len(mapping),
        },
        "sizes": sizes,
        "nlbRouteIds": nlb_ids,
        "schema": 1,
    }
    write_json("manifest.json", manifest)

    log(f"\n完成：路線 {len(routes)}、車站 {len(stops)}、站序 {len(triples)}、"
        f"變動 {len(changes)}、對照表 {len(mapping)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
