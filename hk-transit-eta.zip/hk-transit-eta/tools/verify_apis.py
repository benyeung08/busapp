#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
政府開放資料 API 實測腳本
=========================

目的
----
本專案開發時所在環境無法對外連線，所有 API 假設都只能靠文件推斷。
此腳本用於在 GitHub Actions（runner 有公網）實際呼叫各資料來源，
把「真實回傳結構」印出來，以驗證程式碼中的假設是否成立。

重點驗證項目（港鐵巴士）
------------------------
1. 端點是否為 POST、主體是否為 {"language":"zh","routeName":"..."}
2. 頂層是否真有 `status` 欄位（官方數據字典："1"=正常，"0"=錯誤）
3. `busStop` 陣列是否「依站序排列」——這是對照表的建立基礎
4. `busStopId` 的實際格式（官方未說明，本專案不猜測，直接記錄回傳值）
5. 每條路線編號能否唯一對應到某個方向（去／回程車站數是否相同）

其餘資料來源僅作煙霧測試（能否連線、回傳是否為預期格式）。

用法
----
    python3 tools/verify_apis.py             # 完整檢查
    python3 tools/verify_apis.py --quick     # 只做連線煙霧測試

輸出：標準輸出 + verify-report.md
結束碼：0＝全部通過；1＝有項目失敗（供 CI 判斷）
"""

import argparse
import csv
import io
import json
import sys
import urllib.error
import urllib.parse
import urllib.request
from collections import defaultdict

UA = "HKTransitETA-Verify/1.0 (GitHub Actions)"
TIMEOUT = 60

TD_STATIC = "https://static.data.gov.hk/td/"
MTR_BUS_API = "https://rt.data.gov.hk/v1/transport/mtr/bus/getSchedule"
MTR_HR_API = "https://rt.data.gov.hk/v1/transport/mtr/getSchedule.php"
MTR_LR_API = "https://rt.data.gov.hk/v1/transport/mtr/lrt/getSchedule"
KMB_BASE = "https://data.etabus.gov.hk/v1/transport/kmb"
CTB_BASE = "https://rt.data.gov.hk/v2/transport/citybus"
NLB_BASE = "https://rt.data.gov.hk/v2/transport/nlb"
GMB_BASE = "https://data.etagmb.gov.hk"
HKO_BASE = "https://data.weather.gov.hk/weatherAPI/opendata/weather.php"

MTR_BUS_COMPANY = "LRTFEEDER"

lines = []
failures = []


def out(text=""):
    """同時輸出到標準輸出與報告。"""
    print(text)
    lines.append(text)


# ----------------------------------------------------------------------
# HTTP 工具
# ----------------------------------------------------------------------

def http_get(url, encoding="utf-8-sig"):
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "*/*"})
    with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
        return resp.read().decode(encoding, errors="replace")


def http_post_json(url, payload):
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=data,
        headers={
            "User-Agent": UA,
            "Content-Type": "application/json",
            "Accept": "application/json",
        },
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
        return resp.read().decode("utf-8", errors="replace")


def get_json(url):
    return json.loads(http_get(url))


def parse_csv(text):
    """解析 CSV 成「欄名 → 值」陣列；自動處理 BOM 與雙引號。"""
    if not text.strip():
        return []
    # 防禦性剝除 BOM：若資料源的編碼路徑未使用 utf-8-sig，
    # 首個欄名會變成「\ufeffCOMPANY_CODE」，令所有欄位比對靜默落空。
    return list(csv.DictReader(io.StringIO(text.lstrip("\ufeff"))))


# ----------------------------------------------------------------------
# 煙霧測試：其餘資料來源
# ----------------------------------------------------------------------

def smoke(label, fn):
    """執行一個煙霧測試，回傳 (是否成功, 摘要)。"""
    try:
        summary = fn()
        out(f"| {label} | ✅ 通過 | {summary} |")
        return True
    except urllib.error.HTTPError as e:
        out(f"| {label} | ❌ 失敗 | HTTP {e.code} |")
        failures.append(f"{label}: HTTP {e.code}")
        return False
    except Exception as e:  # noqa: BLE001
        out(f"| {label} | ❌ 失敗 | {type(e).__name__}: {e} |")
        failures.append(f"{label}: {e}")
        return False


def smoke_tests():
    out("\n## 一、各資料來源連線煙霧測試\n")
    out("| 資料來源 | 結果 | 摘要 |")
    out("|---|---|---|")

    def kmb():
        routes = get_json(f"{KMB_BASE}/route/")["data"]
        route = routes[0]["route"]
        rs = get_json(
            f"{KMB_BASE}/route-stop/{route}/outbound/1"
        )["data"]
        stop = rs[0]["stop"]
        eta = get_json(f"{KMB_BASE}/stop-eta/{stop}")["data"]
        return f"路線 {len(routes)} 條；抽查 {route} 站 {stop}，到站 {len(eta)} 筆"

    def ctb():
        routes = get_json(f"{CTB_BASE}/route/CTB")["data"]
        route = routes[0]["route"]
        rs = get_json(f"{CTB_BASE}/route-stop/CTB/{route}/outbound")["data"]
        stop = rs[0]["stop"]
        eta = get_json(f"{CTB_BASE}/eta/CTB/{stop}/{route}")["data"]
        return f"路線 {len(routes)} 條；抽查 {route} 站 {stop}，到站 {len(eta)} 筆"

    def nlb():
        routes = get_json(f"{NLB_BASE}/route.php?action=list")["routes"]
        rid = routes[0]["routeId"]
        detail = get_json(f"{NLB_BASE}/route.php?action=detail&routeId={rid}")
        stops = detail.get("stops") or []
        if not stops:
            return f"路線 {len(routes)} 條；{rid} 無站序資料"
        sid = stops[0]["stopId"]
        eta = get_json(f"{NLB_BASE}/stop.php?action=estimatedArrivals&routeId={rid}&stopId={sid}")
        n = len(eta.get("estimatedArrivals") or [])
        return f"路線 {len(routes)} 條；抽查 {rid} 站 {sid}，到站 {n} 筆"

    def gmb():
        routes = get_json(f"{GMB_BASE}/route/HKI")["data"]["routes"]
        rid = routes[0]["route_id"]
        rs = get_json(f"{GMB_BASE}/route-stop/{rid}/1")["data"]["route_stops"]
        stop = rs[0]["stop_id"]
        eta = get_json(f"{GMB_BASE}/eta/route-stop/{rid}/1/{stop}")["data"]
        return f"港島路線 {len(routes)} 條；抽查 {rid} 站 {stop}，到站 {len(eta)} 筆"

    def mtr_hr():
        data = get_json(f"{MTR_HR_API}?line=TML&sta=TUM&lang=TC")
        n = len(data.get("data", {}).get("TML-TUM", {}).get("UP", []))
        return f"重鐵回應正常；屯門站上行 {n} 班"

    def mtr_lr():
        # 輕鐵 station_id 為數字，且官方未公布完整清單；
        # 故輪詢小範圍找出有效的車站，避免硬編單一 ID 造成假警報
        for sid in range(1, 21):
            try:
                data = get_json(f"{MTR_LR_API}?station_id={sid}")
            except urllib.error.HTTPError:
                continue
            if data.get("platform_list"):
                return f"車站 {sid} 回應正常；月台 {len(data['platform_list'])} 個"
        raise RuntimeError("輪詢 1–20 號車站皆無 platform_list")

    def hko():
        data = get_json(f"{HKO_BASE}?dataType=warnsum&lang=tc")
        keys = ",".join(sorted(data.keys()))
        return f"天文台回應正常；欄位：{keys}"

    def td_csv():
        text = http_get(TD_STATIC + "routes-and-fares/ROUTE_BUS.csv")
        rows = parse_csv(text)
        return f"運輸署路線檔 {len(rows)} 列"

    smoke("九巴／龍運 ETA", kmb)
    smoke("城巴 ETA", ctb)
    smoke("新大嶼山巴士 ETA", nlb)
    smoke("專線小巴 ETA", gmb)
    smoke("港鐵重鐵 Next Train", mtr_hr)
    smoke("輕鐵 Next Train", mtr_lr)
    smoke("天文台天氣警告", hko)
    smoke("運輸署路線收費 CSV", td_csv)


# ----------------------------------------------------------------------
# 深入驗證：港鐵巴士
# ----------------------------------------------------------------------

# ----------------------------------------------------------------------
# 端點探測：確認程式碼裡的 URL 真的存在
# ----------------------------------------------------------------------

# 港鐵巴士即時到站的端點，官方文件並未直接列出可引用的網址。
# 程式碼目前採用的是「與重鐵／輕鐵同構」的推測路徑，必須實測確認；
# 一旦路徑猜錯，查詢只會靜默落空、退回班次表推算，使用者完全看不出異常。
# 以下列出幾個合理候選，由 runner 逐一探測，以實證決定哪一個可用。
MTR_BUS_ENDPOINT_CANDIDATES = [
    ("程式碼現用（推測路徑）", "https://rt.data.gov.hk/v1/transport/mtr/bus/getSchedule"),
    ("加 .php 後綴（與重鐵一致）", "https://rt.data.gov.hk/v1/transport/mtr/bus/getSchedule.php"),
    ("v2 路徑（與城巴一致）", "https://rt.data.gov.hk/v2/transport/mtr/bus/getSchedule"),
    ("港鐵自有開放資料平台", "https://opendata.mtr.com.hk/data/bus/getSchedule"),
]


def probe_endpoint(url, route_name):
    """探測單一端點；回傳 (是否可用, 摘要)。

    先試 POST（官方數據字典指明為 POST），不通再試 GET，
    以便區分「端點不存在」與「只是方法用錯」這兩種情況。
    """
    query = urllib.parse.urlencode({"language": "zh", "routeName": route_name})

    try:
        raw = http_post_json(url, {"language": "zh", "routeName": route_name})
        dto = json.loads(raw)
        stops = dto.get("busStop")
        if isinstance(stops, list):
            return True, f"POST 成功，{len(stops)} 個車站"
        return False, f"POST 有回應但無 busStop 陣列（欄位：{sorted(dto.keys())}）"
    except urllib.error.HTTPError as e:
        post_err = f"POST HTTP {e.code}"
    except Exception as e:  # noqa: BLE001
        post_err = f"POST {type(e).__name__}"

    try:
        raw = http_get(f"{url}?{query}")
        dto = json.loads(raw)
        stops = dto.get("busStop")
        if isinstance(stops, list):
            return True, f"GET 成功，{len(stops)} 個車站（程式碼目前用 POST，需改）"
        return False, f"{post_err}；GET 有回應但無 busStop 陣列"
    except urllib.error.HTTPError as e:
        return False, f"{post_err}；GET HTTP {e.code}"
    except Exception as e:  # noqa: BLE001
        return False, f"{post_err}；GET {type(e).__name__}"


def probe_mtr_bus_endpoints(route_name):
    """逐一探測候選端點，回傳可用者的 URL；全數失敗則回傳 None。"""
    out("\n### 2.2 端點探測（確認程式碼裡的 URL 真的存在）\n")
    out(
        "港鐵巴士即時到站的端點，官方文件未直接列出可引用的網址；"
        "程式碼目前用的是「與重鐵／輕鐵同構」的**推測路徑**，必須實測。"
        f"以下以路線 `{route_name}` 逐一探測：\n"
    )
    out("| 候選 | URL | 結果 |")
    out("|---|---|---|")

    working = None
    for label, url in MTR_BUS_ENDPOINT_CANDIDATES:
        ok, detail = probe_endpoint(url, route_name)
        out(f"| {label} | `{url}` | {'✅' if ok else '❌'} {detail} |")
        if ok and working is None:
            working = url

    if working is None:
        out("\n⚠️ **所有候選端點都無法取得車站資料**，後續逐路線驗證已略過。")
        failures.append("港鐵巴士：所有候選端點皆失敗（端點可能已改版）")
        return None

    current = MTR_BUS_ENDPOINT_CANDIDATES[0][1]
    if working == current:
        out("\n✅ 程式碼使用的端點經實測可用。")
    else:
        out(f"\n⚠️ **程式碼使用的端點不可用，需改為：**\n\n```\n{working}\n```")
        failures.append(f"港鐵巴士端點需由 {current} 改為 {working}")

    return working


def verify_mtr_bus():
    out("\n## 二、港鐵巴士即時到站 — 深入驗證\n")

    out("### 2.1 運輸署目錄中的港鐵巴士路線\n")
    route_rows = parse_csv(http_get(TD_STATIC + "routes-and-fares/ROUTE_BUS.csv"))
    rstop_rows = parse_csv(http_get(TD_STATIC + "routes-and-fares/RSTOP_BUS.csv"))

    mtr_routes = [
        r for r in route_rows
        if (r.get("COMPANY_CODE") or "").strip().upper() == MTR_BUS_COMPANY
    ]
    out(f"- `COMPANY_CODE＝{MTR_BUS_COMPANY}` 的路線主檔：**{len(mtr_routes)}** 條")

    if not mtr_routes:
        out("\n⚠️ 找不到任何港鐵巴士路線，無法繼續驗證。")
        failures.append("運輸署目錄中找不到 LRTFEEDER 路線")
        return

    out("")
    out("| ROUTE_ID | ROUTE_NAMEC | 起點 | 終點 |")
    out("|---|---|---|---|")
    for r in mtr_routes[:40]:
        out(
            f"| {r.get('ROUTE_ID','')} | {r.get('ROUTE_NAMEC','')} "
            f"| {r.get('LOC_START_NAMEC','')} | {r.get('LOC_END_NAMEC','')} |"
        )
    if len(mtr_routes) > 40:
        out(f"| … | 其餘 {len(mtr_routes)-40} 條省略 | | |")

    # 端點探測：先確認要打哪個 URL，再往下做
    test_name = next(
        (r.get("ROUTE_NAMEC", "").strip() for r in mtr_routes
         if r.get("ROUTE_NAMEC", "").strip()),
        None,
    )
    if not test_name:
        out("\n⚠️ 找不到可用於探測的路線編號。")
        failures.append("港鐵巴士：無可用路線編號")
        return

    endpoint = probe_mtr_bus_endpoints(test_name)
    if endpoint is None:
        return

    # 依 ROUTE_ID 統計各方向的車站數
    mtr_route_ids = {r.get("ROUTE_ID", "") for r in mtr_routes}
    seq_counts = defaultdict(dict)  # route_id -> {route_seq: count}
    for row in rstop_rows:
        rid = row.get("ROUTE_ID", "")
        if rid in mtr_route_ids:
            seq = (row.get("ROUTE_SEQ") or "").strip()
            seq_counts[rid][seq] = seq_counts[rid].get(seq, 0) + 1

    out("\n### 2.3 去／回程車站數（運輸署 RSTOP_BUS.csv）\n")
    out("| ROUTE_NAMEC | ROUTE_SEQ=1 | ROUTE_SEQ=2 | 方向是否可區分 |")
    out("|---|---|---|---|")
    ambiguous = []
    for r in mtr_routes:
        rid = r.get("ROUTE_ID", "")
        c1 = seq_counts.get(rid, {}).get("1", 0)
        c2 = seq_counts.get(rid, {}).get("2", 0)
        # 程式碼的規則：只有「恰好一個方向的車站數等於 API 回傳數」才算明確
        distinguishable = "是" if c1 != c2 else "否（兩方向同數）"
        if c1 == c2:
            ambiguous.append(r.get("ROUTE_NAMEC", ""))
        out(f"| {r.get('ROUTE_NAMEC','')} | {c1} | {c2} | {distinguishable} |")

    out("\n### 2.4 逐路線呼叫政府即時到站 API\n")
    out(f"請求方式：`POST`，主體 `{{\"language\":\"zh\",\"routeName\":\"<路線編號>\"}}`")
    out(f"端點：`{endpoint}`\n")
    out("| 路線 | status | 車站數 | 首個 busStopId | 首站班次數 | 備註 |")
    out("|---|---|---|---|---|---|")

    ok_count = 0
    structure_seen = {}
    mapped = 0

    for r in mtr_routes:
        name = (r.get("ROUTE_NAMEC") or "").strip()
        if not name:
            continue
        try:
            dto = json.loads(http_post_json(endpoint, {"language": "zh", "routeName": name}))
        except urllib.error.HTTPError as e:
            out(f"| {name} | — | — | — | — | ❌ HTTP {e.code} |")
            failures.append(f"港鐵巴士 {name}: HTTP {e.code}")
            continue
        except Exception as e:  # noqa: BLE001
            out(f"| {name} | — | — | — | — | ❌ {type(e).__name__}: {e} |")
            failures.append(f"港鐵巴士 {name}: {e}")
            continue

        stops = dto.get("busStop") or []
        status = dto.get("status")
        first_id = (stops[0].get("busStopId") if stops else None) or "—"
        first_bus = len(stops[0].get("bus") or []) if stops else 0

        # 記錄第一個成功的回應結構，供人工核對
        if not structure_seen and stops:
            structure_seen = {
                "top_level_keys": sorted(dto.keys()),
                "busStop_keys": sorted(stops[0].keys()),
                "bus_keys": sorted((stops[0].get("bus") or [{}])[0].keys())
                if first_bus else [],
            }

        note = ""
        if status not in (None, "1"):
            note = f"⚠️ status={status}"
            failures.append(f"港鐵巴士 {name}: status={status}")
        elif not stops:
            note = "⚠️ 無車站資料"
        else:
            ok_count += 1
            # 判斷此路線能否建立對照（程式碼規則：車站數須唯一匹配某方向）
            rid = r.get("ROUTE_ID", "")
            matches = [s for s, c in seq_counts.get(rid, {}).items() if c == len(stops)]
            if len(matches) == 1:
                mapped += 1
            else:
                note = f"⚠️ 方向無法唯一判定（匹配 {len(matches)} 個）"

        out(
            f"| {name} | {status} | {len(stops)} | `{first_id}` "
            f"| {first_bus} | {note} |"
        )

    out(f"\n**成功回應：{ok_count} / {len(mtr_routes)} 條；"
        f"可建立對照表：{mapped} 條**")
    if ambiguous:
        out(f"\n去／回程車站數相同的路線（將退回班次表推算）："
            f" {'、'.join(ambiguous)}")

    if structure_seen:
        out("\n### 2.5 實際回傳結構（取第一個成功的路線）\n")
        out("```json")
        out(json.dumps(structure_seen, ensure_ascii=False, indent=2))
        out("```")
        out("\n請核對程式碼中的 DTO（`MtrBusScheduleDto`／`MtrBusStopDto`／`MtrBusDto`）"
            "是否涵蓋上述欄位。")


# ----------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--quick", action="store_true", help="只做連線煙霧測試")
    args = ap.parse_args()

    out("# 政府開放資料 API 實測報告\n")
    out("本報告由 GitHub Actions 於有公網的 runner 上實際呼叫各資料來源產生。\n")

    smoke_tests()
    if not args.quick:
        verify_mtr_bus()

    out("\n---\n")
    if failures:
        out(f"## ❌ 有 {len(failures)} 項需要跟進\n")
        for f in failures:
            out(f"- {f}")
    else:
        out("## ✅ 全部檢查通過")

    with open("verify-report.md", "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")

    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
