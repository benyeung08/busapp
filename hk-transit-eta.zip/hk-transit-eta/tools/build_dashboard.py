#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
數據源監控後台 — 靜態網站產生器
================================

由 GitHub Actions 排程執行：實際呼叫各政府開放資料來源，
把結果寫成靜態網站（`docs/`），再由 GitHub Pages 發佈。

重要界線
--------
這是「**資料源監控**」，不是「App 內部狀態監控」。
手機上的 Room 資料庫無法從 GitHub 讀取，故本後台是獨立於 App、
對同一批政府 API 進行交叉驗證的儀表板。

它的價值在於回答這些問題：
  - 各政府 API 現在是否活著？回應多久？回傳幾筆？
  - 港鐵巴士的 busStopId 對照表能否建立？（本專案最大的未驗證假設）
  - 運輸署官方更新記錄現在有多少筆 Add／Update／Delete？
  - 今天的特別交通消息有多少則？其中改道／暫停／恢復各多少？
  - 天文台現在有哪些生效中的警告？

設計原則
--------
**單一資料源故障不得中斷整份報告**。
監控頁的價值恰恰在於「哪裡壞了」，故所有探測都包在容錯裡，
失敗會被記錄並顯示，但不會讓腳本中止。

用法
----
    python3 tools/build_dashboard.py                # 完整檢查
    python3 tools/build_dashboard.py --quick        # 只做健康檢查
    python3 tools/build_dashboard.py --out docs     # 指定輸出目錄

結束碼：永遠回傳 0（故障已反映在網頁內容中，不應讓 CI 失敗）
"""

from __future__ import annotations

import argparse
import csv
import html
import io
import json
import sys
import time
import urllib.error
import urllib.request
import xml.etree.ElementTree as ET
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from pathlib import Path

try:
    from zoneinfo import ZoneInfo

    HKT = ZoneInfo("Asia/Hong_Kong")
except Exception:  # noqa: BLE001
    HKT = timezone(timedelta(hours=8))

UA = "HKTransitETA-Dashboard/1.0 (GitHub Actions)"
DEFAULT_TIMEOUT = 90

# ---------------------------------------------------------------- 端點
TD_STATIC = "https://static.data.gov.hk/td/"
TD_NEWS = "https://www.td.gov.hk/tc/special_news/trafficnews.xml"
MTR_BUS_API = "https://rt.data.gov.hk/v1/transport/mtr/bus/getSchedule"
MTR_HR = "https://rt.data.gov.hk/v1/transport/mtr/getSchedule.php"
MTR_LR = "https://rt.data.gov.hk/v1/transport/mtr/lrt/getSchedule"
KMB = "https://data.etabus.gov.hk/v1/transport/kmb"
CTB = "https://rt.data.gov.hk/v2/transport/citybus"
NLB = "https://rt.data.gov.hk/v2/transport/nlb"
GMB = "https://data.etagmb.gov.hk"
HKO = "https://data.weather.gov.hk/weatherAPI/opendata/weather.php"

MTR_BUS_COMPANY = "LRTFEEDER"

# 特別交通消息的分類關鍵字（與 App 內 NewsClassifier 的概念一致）
NEWS_CATEGORIES = {
    "改道": ("改道", "繞道", "改行", "改經"),
    "暫停": ("暫停", "停駛", "封閉", "封路", "中止"),
    "恢復": ("恢復", "重開", "復常", "解封"),
}

DELTA_FILES = [
    ("ROUTE_BUS_DELTA.csv", "巴士路線"),
    ("RSTOP_BUS_DELTA.csv", "巴士路線車站"),
    ("STOP_BUS_DELTA.csv", "巴士車站"),
    ("ROUTE_GMB_DELTA.csv", "小巴路線"),
    ("RSTOP_GMB_DELTA.csv", "小巴路線車站"),
    ("STOP_GMB_DELTA.csv", "小巴車站"),
]


# ---------------------------------------------------------------- HTTP

def http_get(url: str, encoding: str = "utf-8-sig") -> str:
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "*/*"})
    with urllib.request.urlopen(req, timeout=DEFAULT_TIMEOUT) as resp:
        return resp.read().decode(encoding, errors="replace")


def get_json(url: str):
    return json.loads(http_get(url))


def post_json(url: str, payload: dict):
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=data,
        headers={
            "User-Agent": UA,
            "Content-Type": "application/json",
            "Accept": "application/json",
        },
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=DEFAULT_TIMEOUT) as resp:
        return json.loads(resp.read().decode("utf-8", errors="replace"))


def csv_rows(text: str) -> list[dict]:
    """解析 CSV，欄名統一去 BOM、去空白、轉大寫，避免靜默比對失敗。"""
    if not text.strip():
        return []
    reader = csv.DictReader(io.StringIO(text.lstrip("\ufeff")))
    return [
        {(k or "").strip().lstrip("\ufeff").upper(): (v or "").strip() for k, v in row.items()}
        for row in reader
    ]


def now_hkt() -> datetime:
    return datetime.now(HKT)


def fmt_dt(dt: datetime | None) -> str:
    return dt.strftime("%Y-%m-%d %H:%M:%S") if dt else "—"


# ---------------------------------------------------------------- 探測

def probe(name: str, group: str, fn) -> dict:
    """
    執行單一探測，永遠不拋出例外。

    fn 需回傳 (筆數, 說明文字)；任何例外都會被轉成失敗記錄。
    """
    started = time.time()
    try:
        count, detail = fn()
        return {
            "name": name,
            "group": group,
            "ok": True,
            "latency_ms": int((time.time() - started) * 1000),
            "count": count,
            "detail": detail,
            "error": "",
        }
    except urllib.error.HTTPError as e:
        return _fail(name, group, started, f"HTTP {e.code}", e)
    except Exception as e:  # noqa: BLE001
        return _fail(name, group, started, f"{type(e).__name__}: {e}", e)


def _fail(name, group, started, message, exc) -> dict:
    return {
        "name": name,
        "group": group,
        "ok": False,
        "latency_ms": int((time.time() - started) * 1000),
        "count": 0,
        "detail": "",
        "error": message,
    }


# ---------------------------------------------------------------- 各資料源

def probe_kmb():
    routes = get_json(f"{KMB}/route/")["data"]
    route = routes[0]["route"]
    rs = get_json(f"{KMB}/route-stop/{route}/outbound/1")["data"]
    stop = rs[0]["stop"]
    eta = get_json(f"{KMB}/stop-eta/{stop}")["data"]
    return len(routes), f"抽查 {route} 站 {stop}，到站 {len(eta)} 筆"


def probe_ctb():
    routes = get_json(f"{CTB}/route/CTB")["data"]
    route = routes[0]["route"]
    rs = get_json(f"{CTB}/route-stop/CTB/{route}/outbound")["data"]
    stop = rs[0]["stop"]
    eta = get_json(f"{CTB}/eta/CTB/{stop}/{route}")["data"]
    return len(routes), f"抽查 {route} 站 {stop}，到站 {len(eta)} 筆"


def probe_nlb():
    routes = get_json(f"{NLB}/route.php?action=list")["routes"]
    rid = routes[0]["routeId"]
    detail = get_json(f"{NLB}/route.php?action=detail&routeId={rid}")
    stops = detail.get("stops") or []
    if not stops:
        return len(routes), f"{rid} 無站序資料"
    sid = stops[0]["stopId"]
    eta = get_json(
        f"{NLB}/stop.php?action=estimatedArrivals&routeId={rid}&stopId={sid}"
    )
    return len(routes), f"抽查 {rid} 站 {sid}，到站 {len(eta.get('estimatedArrivals') or [])} 筆"


def probe_gmb():
    routes = get_json(f"{GMB}/route/HKI")["data"]["routes"]
    rid = routes[0]["route_id"]
    rs = get_json(f"{GMB}/route-stop/{rid}/1")["data"]["route_stops"]
    stop = rs[0]["stop_id"]
    eta = get_json(f"{GMB}/eta/route-stop/{rid}/1/{stop}")["data"]
    return len(routes), f"港島 {len(routes)} 條；抽查 {rid} 站 {stop}，到站 {len(eta)} 筆"


def probe_mtr_hr():
    data = get_json(f"{MTR_HR}?line=TML&sta=TUM&lang=TC")
    n = len(data.get("data", {}).get("TML-TUM", {}).get("UP", []))
    return n, f"屯門站上行 {n} 班"


def probe_mtr_lr():
    # 輕鐵 station_id 為數字且官方未公布清單，故小範圍輪詢至首次成功
    for sid in range(1, 6):
        try:
            data = get_json(f"{MTR_LR}?station_id={sid}")
        except urllib.error.HTTPError:
            continue
        if data.get("platform_list"):
            return len(data["platform_list"]), f"車站 {sid}，月台 {len(data['platform_list'])} 個"
    raise RuntimeError("輪詢 1–5 號車站皆無 platform_list")


def probe_hko():
    data = get_json(f"{HKO}?dataType=warnsum&lang=tc")
    active = {k: v for k, v in data.items() if isinstance(v, dict) and v}
    return len(active), f"生效中警告 {len(active)} 項"


def probe_td_routes(text: str):
    def _f():
        rows = csv_rows(text)
        return len(rows), f"路線主檔 {len(rows)} 列"
    return _f


def probe_td_news():
    items = parse_traffic_news(http_get(TD_NEWS))
    return len(items), f"消息 {len(items)} 則"


# ---------------------------------------------------------------- 交通消息

def parse_traffic_news(xml_text: str) -> list[dict]:
    """寬鬆解析運輸署特別交通消息 XML：官方 XSD 會微調，故逐元素收集子節點文字。"""
    try:
        root = ET.fromstring(xml_text)
    except ET.ParseError:
        return []

    message_tags = {"message", "news", "item", "row"}
    items = []
    for el in root.iter():
        tag = el.tag.split("}")[-1].lower()
        if tag not in message_tags:
            continue
        fields = {}
        for child in el:
            if len(child):  # 跳過容器節點
                continue
            ctag = child.tag.split("}")[-1]
            fields[ctag] = (child.text or "").strip()
        if fields:
            items.append(fields)
    return items


def news_text(item: dict) -> str:
    for k in ("chinese_message", "message_tc", "CHINESE_MESSAGE", "chineseMessage"):
        for key, val in item.items():
            if key.lower() == k.lower() and val:
                return val
    return ""


def news_date(item: dict):
    raw = ""
    for key, val in item.items():
        if key.lower() in ("publication_date", "publish_date", "date"):
            raw = val
            break
    if not raw:
        return None
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d", "%d/%m/%Y %H:%M"):
        try:
            return datetime.strptime(raw.strip()[:19], fmt)
        except ValueError:
            continue
    return None


def summarise_news(items: list[dict]) -> dict:
    today = now_hkt().date()
    today_items = [i for i in items if (news_date(i) or now_hkt()).date() == today]

    counts = {k: 0 for k in NEWS_CATEGORIES}
    counts["其他"] = 0
    for item in items:
        text = news_text(item)
        matched = False
        for cat, keywords in NEWS_CATEGORIES.items():
            if any(kw in text for kw in keywords):
                counts[cat] += 1
                matched = True
                break
        if not matched:
            counts["其他"] += 1

    samples = []
    for item in today_items[:15]:
        text = news_text(item)
        if text:
            samples.append({"time": fmt_dt(news_date(item)), "text": text[:120]})

    return {
        "total": len(items),
        "today": len(today_items),
        "counts": counts,
        "samples": samples,
    }


# ---------------------------------------------------------------- 運輸署 Delta

def collect_deltas() -> list[dict]:
    """下載各類官方更新記錄（Delta），統計 Add／Update／Delete 筆數。"""
    out = []
    for filename, label in DELTA_FILES:
        try:
            rows = csv_rows(http_get(TD_STATIC + "routes-and-fares/" + filename))
        except Exception as e:  # noqa: BLE001
            out.append({"label": label, "file": filename, "ok": False, "error": str(e),
                        "add": 0, "update": 0, "delete": 0, "total": 0})
            continue

        tally = defaultdict(int)
        for row in rows:
            change = (row.get("CHANGE") or "").strip().upper()
            if not change:
                continue
            if change.startswith("ADD") or "新增" in change:
                tally["add"] += 1
            elif change.startswith("DEL") or "刪除" in change or "取消" in change:
                tally["delete"] += 1
            elif change.startswith("UPD") or "更新" in change or "修改" in change:
                tally["update"] += 1
            else:
                tally["other"] += 1

        out.append({
            "label": label,
            "file": filename,
            "ok": True,
            "error": "",
            "add": tally["add"],
            "update": tally["update"],
            "delete": tally["delete"],
            "total": len(rows),
        })
    return out


# ---------------------------------------------------------------- 港鐵巴士

def collect_mtr_bus(route_csv: str, rstop_csv: str) -> dict:
    """
    驗證港鐵巴士對照表能否建立——本專案最大的未驗證假設。

    對每條 LRTFEEDER 路線呼叫一次政府 API，比對：
      - 運輸署去程（ROUTE_SEQ=1）／回程（2）的車站數
      - API 回傳的車站數
    只有「恰好一個方向的車站數等於 API 回傳數」時，App 才會建立對照。
    """
    result = {
        "ok": bool(route_csv and rstop_csv),
        "error": "",
        "total": 0,
        "mapped": 0,
        "ambiguous": 0,
        "failed": 0,
        "routes": [],
    }
    if not result["ok"]:
        result["error"] = "運輸署 CSV 下載失敗"
        return result

    routes_master = [
        r for r in csv_rows(route_csv)
        if (r.get("COMPANY_CODE") or "").upper() == MTR_BUS_COMPANY
    ]
    result["total"] = len(routes_master)
    if not routes_master:
        result["error"] = f"找不到 COMPANY_CODE＝{MTR_BUS_COMPANY} 的路線"
        result["ok"] = False
        return result

    route_ids = {r.get("ROUTE_ID", "") for r in routes_master}

    # ROUTE_ID → {ROUTE_SEQ: 車站數}
    seq_counts: dict[str, dict[str, int]] = defaultdict(dict)
    for row in csv_rows(rstop_csv):
        rid = row.get("ROUTE_ID", "")
        if rid in route_ids:
            seq = (row.get("ROUTE_SEQ") or "").strip()
            seq_counts[rid][seq] = seq_counts[rid].get(seq, 0) + 1

    for r in routes_master:
        rid = r.get("ROUTE_ID", "")
        name = (r.get("ROUTE_NAMEC") or "").strip()
        counts = seq_counts.get(rid, {})
        c1 = counts.get("1", 0)
        c2 = counts.get("2", 0)

        entry = {
            "name": name,
            "route_id": rid,
            "seq1": c1,
            "seq2": c2,
            "api": 0,
            "status": "—",
            "mapped": False,
            "note": "",
            "first_id": "—",
        }

        if not name:
            entry["note"] = "路線編號空白"
            result["failed"] += 1
            result["routes"].append(entry)
            continue

        try:
            dto = post_json(MTR_BUS_API, {"language": "zh", "routeName": name})
        except Exception as e:  # noqa: BLE001
            entry["note"] = f"API 失敗：{type(e).__name__}"
            result["failed"] += 1
            result["routes"].append(entry)
            continue

        stops = dto.get("busStop") or []
        entry["api"] = len(stops)
        entry["status"] = str(dto.get("status") or "—")
        if stops:
            entry["first_id"] = str(stops[0].get("busStopId") or "—")

        if dto.get("status") not in (None, "1"):
            entry["note"] = f"status={dto.get('status')}"
            result["failed"] += 1
        elif not stops:
            entry["note"] = "無車站資料"
            result["failed"] += 1
        else:
            matches = [s for s, c in counts.items() if c == len(stops)]
            if len(matches) == 1:
                entry["mapped"] = True
                result["mapped"] += 1
            else:
                entry["note"] = f"方向無法唯一判定（匹配 {len(matches)} 個）"
                result["ambiguous"] += 1

        result["routes"].append(entry)

    return result


# ---------------------------------------------------------------- 天氣

def collect_weather() -> dict:
    out = {"ok": False, "error": "", "active": [], "details": ""}
    try:
        warnsum = get_json(f"{HKO}?dataType=warnsum&lang=tc")
    except Exception as e:  # noqa: BLE001
        out["error"] = str(e)
        return out

    out["ok"] = True
    for code, val in warnsum.items():
        if not isinstance(val, dict) or not val:
            continue
        name = val.get("warningName") or val.get("name") or code
        out["active"].append({"code": code, "name": str(name)})

    try:
        info = get_json(f"{HKO}?dataType=warningInfo&lang=tc")
        parts = info.get("details") or []
        if isinstance(parts, list):
            out["details"] = " ".join(str(p.get("contents") or "") for p in parts)[:400]
    except Exception:  # noqa: BLE001
        pass
    return out


# ---------------------------------------------------------------- 樣式

CSS = """
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI","PingFang TC",
 "Microsoft JhengHei",sans-serif;background:#f4f6f8;color:#1a1a1a;line-height:1.6;
 padding:24px 16px 60px}
.wrap{max-width:1080px;margin:0 auto}
header{margin-bottom:24px}
h1{font-size:24px;font-weight:700;margin-bottom:6px}
.sub{color:#666;font-size:13px}
h2{font-size:17px;margin:32px 0 12px;padding-bottom:8px;border-bottom:2px solid #e3e8ee}
.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px;margin-top:20px}
.card{background:#fff;border-radius:10px;padding:16px;box-shadow:0 1px 3px rgba(0,0,0,.07)}
.card .k{font-size:12px;color:#666;margin-bottom:6px}
.card .v{font-size:26px;font-weight:700;line-height:1.2}
.card .u{font-size:13px;color:#888;font-weight:400;margin-left:3px}
table{width:100%;border-collapse:collapse;background:#fff;border-radius:10px;
 overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,.07);font-size:13px}
th{background:#eef2f6;text-align:left;padding:10px 12px;font-weight:600;font-size:12px;color:#555}
td{padding:9px 12px;border-top:1px solid #eef2f6;vertical-align:top}
tr:hover td{background:#fafbfc}
.dot{display:inline-block;width:9px;height:9px;border-radius:50%;margin-right:7px}
.ok{background:#2e7d32}.bad{background:#d32f2f}.warn{background:#ed6c02}
.mono{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:12px}
.tag{display:inline-block;padding:2px 8px;border-radius:11px;font-size:11px;font-weight:600}
.tag-ok{background:#e8f5e9;color:#2e7d32}
.tag-bad{background:#ffebee;color:#c62828}
.tag-warn{background:#fff3e0;color:#e65100}
.note{background:#fff8e1;border-left:3px solid #ed6c02;padding:12px 14px;
 border-radius:6px;font-size:13px;margin:14px 0}
.empty{color:#888;font-size:13px;padding:14px;background:#fff;border-radius:8px}
footer{margin-top:40px;padding-top:18px;border-top:1px solid #e3e8ee;
 color:#888;font-size:12px}
code{background:#eef2f6;padding:1px 5px;border-radius:4px;font-size:12px}
"""


def esc(s) -> str:
    return html.escape(str(s), quote=True)


# ---------------------------------------------------------------- 渲染

def render(data: dict) -> str:
    s = data["summary"]
    parts = []
    a = parts.append

    a('<!DOCTYPE html><html lang="zh-Hant"><head><meta charset="utf-8">')
    a('<meta name="viewport" content="width=device-width,initial-scale=1">')
    # 監控頁每 5 分鐘自動重新載入，適合長期開著觀察
    a('<meta http-equiv="refresh" content="300">')
    a("<title>香港實時到站 — 數據源監控後台</title>")
    a(f"<style>{CSS}</style></head><body><div class='wrap'>")

    a("<header>")
    a("<h1>香港實時到站 — 數據源監控後台</h1>")
    a(f"<div class='sub'>產生時間：{esc(data['generated_at'])}（香港時間）"
      f" ・ 每 30 分鐘由 GitHub Actions 自動重建 ・ 本頁每 5 分鐘自動重新載入</div>")
    a("</header>")

    # ---- 摘要卡片 ----
    a("<div class='cards'>")
    a(_card("資料源健康", f"{s['ok']}<span class='u'>/ {s['total']}</span>", "個來源正常"))
    a(_card("平均回應", f"{s['avg_latency']}<span class='u'>ms</span>", "僅計成功請求"))
    a(_card("港鐵巴士對照", f"{s['mtr_mapped']}<span class='u'>/ {s['mtr_total']}</span>",
            "可建立對照之路線"))
    a(_card("今日交通消息", f"{s['news_today']}<span class='u'>則</span>",
            f"全部消息 {s['news_total']} 則"))
    a(_card("官方更新記錄", f"{s['delta_total']}<span class='u'>筆</span>", "Delta 檔合計"))
    a(_card("生效中警告", f"{s['weather']}<span class='u'>項</span>", "天文台"))
    a("</div>")

    # ---- 港鐵巴士（最需要關注的假設） ----
    a("<h2>港鐵巴士 busStopId 對照表</h2>")
    mb = data["mtr_bus"]
    if not mb["ok"]:
        a(f"<div class='note'>⚠️ 無法驗證：{esc(mb['error'])}</div>")
    else:
        rate = (mb["mapped"] / mb["total"] * 100) if mb["total"] else 0
        if rate == 0:
            a("<div class='note'><strong>⚠️ 對照成功率為 0</strong> —— "
              "代表 <code>routeName</code> 與運輸署的 <code>ROUTE_NAMEC</code> 對不上，"
              "或 API 回傳結構與預期不符。App 會全數退回班次表推算。"
              "請核對下方「API 車站數」與「status」欄。</div>")
        elif rate < 50:
            a(f"<div class='note'>⚠️ 對照成功率僅 {rate:.0f}%，"
              f"其中 {mb['ambiguous']} 條因去／回程車站數相同而無法判定方向。</div>")
        else:
            a(f"<div class='note'>✅ 對照成功率 {rate:.0f}%（{mb['mapped']}/{mb['total']}）；"
              f"無法判定方向 {mb['ambiguous']} 條，失敗 {mb['failed']} 條。</div>")

        a("<table><thead><tr><th>路線</th><th>去程站數</th><th>回程站數</th>"
          "<th>API 車站數</th><th>status</th><th>首個 busStopId</th><th>狀態</th></tr></thead><tbody>")
        for r in mb["routes"]:
            if r["mapped"]:
                badge = "<span class='tag tag-ok'>可建立</span>"
            elif r["note"]:
                badge = f"<span class='tag tag-warn'>{esc(r['note'])}</span>"
            else:
                badge = "<span class='tag tag-bad'>未處理</span>"
            a(f"<tr><td><strong>{esc(r['name'])}</strong></td>"
              f"<td>{r['seq1']}</td><td>{r['seq2']}</td><td>{r['api']}</td>"
              f"<td class='mono'>{esc(r['status'])}</td>"
              f"<td class='mono'>{esc(r['first_id'])}</td><td>{badge}</td></tr>")
        a("</tbody></table>")

    # ---- 資料源健康 ----
    a("<h2>資料源健康檢查</h2>")
    a("<table><thead><tr><th>來源</th><th>狀態</th><th>回應</th>"
      "<th>筆數</th><th>說明／錯誤</th></tr></thead><tbody>")
    for src in data["sources"]:
        if src["ok"]:
            dot, tag = "ok", "<span class='tag tag-ok'>正常</span>"
        else:
            dot, tag = "bad", "<span class='tag tag-bad'>失敗</span>"
        detail = src["detail"] if src["ok"] else esc(src["error"])
        a(f"<tr><td><span class='dot {dot}'></span>{esc(src['name'])}</td>"
          f"<td>{tag}</td><td class='mono'>{src['latency_ms']} ms</td>"
          f"<td>{src['count']}</td><td>{detail}</td></tr>")
    a("</tbody></table>")

    # ---- 官方更新記錄 ----
    a("<h2>運輸署官方更新記錄（Delta）</h2>")
    a("<table><thead><tr><th>類別</th><th>檔案</th><th>新增</th><th>更新</th>"
      "<th>刪除</th><th>總列數</th></tr></thead><tbody>")
    for d in data["deltas"]:
        if not d["ok"]:
            a(f"<tr><td>{esc(d['label'])}</td><td class='mono'>{esc(d['file'])}</td>"
              f"<td colspan='4'><span class='tag tag-bad'>{esc(d['error'])}</span></td></tr>")
            continue
        a(f"<tr><td>{esc(d['label'])}</td><td class='mono'>{esc(d['file'])}</td>"
          f"<td>{d['add']}</td><td>{d['update']}</td><td>{d['delete']}</td>"
          f"<td>{d['total']}</td></tr>")
    a("</tbody></table>")

    # ---- 交通消息 ----
    a("<h2>運輸署特別交通消息</h2>")
    news = data["news"]
    a("<div class='cards'>")
    for cat, n in news["counts"].items():
        a(_card(cat, f"{n}<span class='u'>則</span>", "全部消息"))
    a(_card("今日消息", f"{news['today']}<span class='u'>則</span>",
            f"共 {news['total']} 則"))
    a("</div>")
    if news["samples"]:
        a("<table><thead><tr><th>發布時間</th><th>內容（節錄）</th></tr></thead><tbody>")
        for s2 in news["samples"]:
            a(f"<tr><td class='mono'>{esc(s2['time'])}</td><td>{esc(s2['text'])}</td></tr>")
        a("</tbody></table>")
    else:
        a("<div class='empty'>今日沒有偵測到特別交通消息。</div>")

    # ---- 天氣 ----
    a("<h2>天文台警告</h2>")
    w = data["weather"]
    if not w["ok"]:
        a(f"<div class='note'>⚠️ 無法取得：{esc(w['error'])}</div>")
    elif not w["active"]:
        a("<div class='empty'>現時沒有生效中的警告。</div>")
    else:
        a("<table><thead><tr><th>代碼</th><th>警告名稱</th></tr></thead><tbody>")
        for item in w["active"]:
            a(f"<tr><td class='mono'>{esc(item['code'])}</td>"
              f"<td>{esc(item['name'])}</td></tr>")
        a("</tbody></table>")
        if w["details"]:
            a(f"<div class='note'>{esc(w['details'])}</div>")

    a("<footer>")
    a("資料來源：運輸署「公共交通資料」、九巴／龍運、城巴、新大嶼山巴士、"
      "專線小巴、香港鐵路有限公司、香港天文台。<br>")
    a("本頁由 GitHub Actions 自動產生，用於監控上述政府開放資料來源的可用性，"
      "與手機 App 的內部資料庫無關。所有資料的知識產權分屬各資料提供機構。</footer>")

    a("</div></body></html>")
    return "\n".join(parts)


def _card(k: str, v: str, unit: str) -> str:
    return (f"<div class='card'><div class='k'>{esc(k)}</div>"
            f"<div class='v'>{v}</div>"
            f"<div class='k' style='margin-top:4px;margin-bottom:0'>{esc(unit)}</div></div>")


# ---------------------------------------------------------------- 主流程

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="docs", help="輸出目錄（GitHub Pages 來源）")
    ap.add_argument("--quick", action="store_true", help="只做健康檢查，跳過港鐵巴士深入驗證")
    args = ap.parse_args()

    print("開始收集資料…")
    sources = [
        probe("九巴／龍運 ETA", "巴士", probe_kmb),
        probe("城巴 ETA", "巴士", probe_ctb),
        probe("新大嶼山巴士 ETA", "巴士", probe_nlb),
        probe("專線小巴 ETA", "小巴", probe_gmb),
        probe("港鐵重鐵 Next Train", "鐵路", probe_mtr_hr),
        probe("輕鐵 Next Train", "鐵路", probe_mtr_lr),
        probe("天文台天氣警告", "天氣", probe_hko),
        probe("運輸署特別交通消息", "運輸署", probe_td_news),
    ]

    route_csv = rstop_csv = ""
    if not args.quick:
        try:
            route_csv = http_get(TD_STATIC + "routes-and-fares/ROUTE_BUS.csv")
            rstop_csv = http_get(TD_STATIC + "routes-and-fares/RSTOP_BUS.csv")
            sources.append(probe("運輸署路線收費 CSV", "運輸署", probe_td_routes(route_csv)))
        except Exception as e:  # noqa: BLE001
            sources.append(_fail("運輸署路線收費 CSV", "運輸署", time.time(), str(e), e))

    print("檢查港鐵巴士對照表…")
    mtr_bus = {"ok": False, "error": "已略過（quick 模式）", "total": 0, "mapped": 0,
               "ambiguous": 0, "failed": 0, "routes": []}
    if not args.quick:
        mtr_bus = collect_mtr_bus(route_csv, rstop_csv)

    print("下載官方更新記錄…")
    deltas = collect_deltas()

    print("整理交通消息…")
    try:
        news = summarise_news(parse_traffic_news(http_get(TD_NEWS)))
    except Exception as e:  # noqa: BLE001
        news = {"total": 0, "today": 0, "counts": {k: 0 for k in NEWS_CATEGORIES} | {"其他": 0},
                "samples": [], "error": str(e)}

    print("取得天氣警告…")
    weather = collect_weather()

    ok_sources = [s for s in sources if s["ok"]]
    latency = (
        sum(s["latency_ms"] for s in ok_sources) // len(ok_sources) if ok_sources else 0
    )

    data = {
        "generated_at": fmt_dt(now_hkt()),
        "sources": sources,
        "mtr_bus": mtr_bus,
        "deltas": deltas,
        "news": news,
        "weather": weather,
        "summary": {
            "total": len(sources),
            "ok": len(ok_sources),
            "avg_latency": latency,
            "mtr_total": mtr_bus["total"],
            "mtr_mapped": mtr_bus["mapped"],
            "news_total": news["total"],
            "news_today": news["today"],
            "delta_total": sum(d["total"] for d in deltas),
            "weather": len(weather["active"]),
        },
    }

    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)
    # 避免 GitHub Pages 以 Jekyll 處理（會忽略底線開頭的檔案）
    (out_dir / ".nojekyll").write_text("", encoding="utf-8")
    (out_dir / "index.html").write_text(render(data), encoding="utf-8")
    (out_dir / "data.json").write_text(
        json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    print(f"✅ 已產生 {out_dir}/index.html 與 {out_dir}/data.json")
    print(f"   資料源 {data['summary']['ok']}/{data['summary']['total']} 正常；"
          f"港鐵巴士對照 {data['summary']['mtr_mapped']}/{data['summary']['mtr_total']}")

    # 永遠回傳 0：故障已反映在網頁內容中，不應讓 CI 失敗
    return 0


if __name__ == "__main__":
    sys.exit(main())
