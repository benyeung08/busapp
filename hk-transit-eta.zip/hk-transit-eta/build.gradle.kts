// 根專案設定：僅宣告外掛 ID，實際版本集中在 gradle/libs.versions.toml 以外的地方避免多重來源。
// 此專案刻意不使用 version catalog，改以 build.gradle.kts 內的常數管理，方便單檔調整。
plugins {
    id("com.android.application") version "8.2.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.22" apply false
    id("com.google.devtools.ksp") version "1.9.22-1.0.17" apply false
}

tasks.register<Delete>("clean") {
    delete(rootProject.layout.buildDirectory)
}
